import React, { useState } from 'react';
import { X, Upload, CheckCircle, Database, Loader2, AlertCircle } from 'lucide-react';
import { read, utils } from 'xlsx';
import { supabase } from '../../../utils/supabase';
import { resolveCurrentTenant } from '../../../utils/tenantResolver';
import { showToast } from '../../../utils/toast';

const PROGRAM_OPTIONS = [
  "BLT Dana Desa",
  "Program Keluarga Harapan (PKH)",
  "Bantuan Pangan Non-Tunai (BPNT)",
  "Bantuan Sosial Tunai (BST)",
  "Bantuan Lansia (Lansia Terlantar)",
  "Bantuan Disabilitas",
  "Bantuan Yatim & Dhuafa",
  "Bantuan Ibu Hamil & Balita (Gizi Buruk)",
  "Bantuan Pendidikan Anak Usia Dini (PAUD)",
  "Bantuan Beasiswa SMA/SMK",
  "Bantuan KIP (Kartu Indonesia Pintar)",
  "Bantuan KIS (Kartu Indonesia Sehat)",
  "Bantuan Pangan Beras / Sembako",
  "Bantuan Gas LPG 3kg",
  "Bantuan Listrik Gratis / Subsidi",
  "Bantuan UMKM (Modal Usaha)",
  "Bantuan Stimulan Perumahan RTLH",
  "Bantuan Air Bersih / Sumur Bor",
  "Bantuan MCK Komunal",
  "Bantuan Jalan Usaha Tani",
  "Bantuan Irigasi Pertanian",
  "Bantuan Alat & Mesin Pertanian",
  "Bantuan Bibit Tanaman",
  "Bantuan Bibit Ternak / Pakan",
  "Bantuan Peralatan Nelayan",
  "Bantuan Koperasi & Pemasaran",
  "Bantuan Pelatihan Kerja / Skills",
  "Bantuan Bencana Alam (Banjir/Gempa)",
  "Bantuan Sembako Pasca Bencana",
  "Bantuan Santunan Kematian",
  "Bantuan Lubang Livestock",
  "Bantuan Pemanfaatan Lahan Pekarangan",
  "Bantuan Penerangan Jalan Umum (PJU)",
  "Bantuan Panel Surya / Listrik Desa",
  "Bantuan WIFI / Internet Desa",
  "Bantuan Peningkatan Jalan Desa",
  "Bantuan Jembatan Desa",
  "Bantuan Fasilitas Olahraga",
  "Bantuan Fasilitas Ibadah (Masjid/Gereja)",
  "Bantuan Posyandu / Kesehatan Desa"
];

interface AdminBantuanImportProps {
  onClose: () => void;
  onRefresh: () => void;
  existingResidents: any[];
}

export default function AdminBantuanImport({ onClose, onRefresh, existingResidents }: AdminBantuanImportProps) {
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<any[]>([]);
  const [program, setProgram] = useState('BLT Dana Desa');
  const [showProgramDropdown, setShowProgramDropdown] = useState(false);
  const [year, setYear] = useState(new Date().getFullYear().toString());
  const [step, setStep] = useState(1);
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState<{ success: number; newResidents: number; failed: number } | null>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;
    setFile(selectedFile);

    try {
      const data = await selectedFile.arrayBuffer();
      const workbook = read(data, { type: 'array' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const json = utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
      
      if (json.length < 2) throw new Error("File kosong atau tidak memiliki data");

      const headers = json[0].map(h => String(h).toLowerCase().trim());
      const nikIdx = headers.findIndex(h => h.includes('nik') || h.includes('ktp'));
      const nameIdx = headers.findIndex(h => h.includes('nama') || h.includes('name'));

      if (nikIdx === -1 || nameIdx === -1) {
        throw new Error("Kolom NIK dan Nama wajib ada di file Excel/CSV Anda.");
      }

      const rows: { nik: string; name: string }[] = [];
      const seenNiks = new Set<string>();
      for (let i = 1; i < json.length; i++) {
        const row = json[i];
        if (!row || row.length === 0) continue;
        const nik = String(row[nikIdx] || '').trim();
        const name = String(row[nameIdx] || '').trim();
        if (nik && name && !seenNiks.has(nik)) {
          seenNiks.add(nik);
          rows.push({ nik, name });
        }
      }

      setParsedData(rows);
      setStep(2);
    } catch (err: any) {
      showToast(err.message || 'Gagal membaca file', 'error');
      setFile(null);
    }
  };

  const handleImport = async () => {
    setProcessing(true);
    let successCount = 0;
    let newResidentCount = 0;
    let failedCount = 0;
    
    try {
      const tenantId = await resolveCurrentTenant();
      if (!tenantId) throw new Error("Gagal mengidentifikasi tenant.");

      const aidToSave = `${program} (${year})`;

      const seenNiks = new Set<string>();

      for (const row of parsedData) {
        try {
          if (seenNiks.has(row.nik)) {
            failedCount++;
            continue;
          }
          seenNiks.add(row.nik);

          const existing = existingResidents.find(r => r.nik === row.nik);
          
          if (existing) {
            const currentAids = typeof existing.activeAids === 'string' ? JSON.parse(existing.activeAids) : (existing.activeAids || []);
            if (!currentAids.includes(aidToSave)) {
              const updatedAids = [...currentAids, aidToSave];
              await supabase.from('residents').update({ active_aids: updatedAids }).eq('nik', row.nik).eq('tenant_id', tenantId);
            }
          } else {
            const newResident = {
              tenant_id: tenantId,
              nik: row.nik,
              name: row.name,
              gender: 'Laki-laki',
              active_aids: [aidToSave]
            };
            const { error: insertErr } = await supabase.from('residents').insert([newResident]);
            if (insertErr) {
              console.error(`Gagal insert residents NIK ${row.nik}:`, insertErr.message);
            } else {
              newResidentCount++;
            }
          }

          const { data: existingBan } = await supabase
            .from('bansos_recipients')
            .select('id')
            .eq('resident_id', row.nik)
            .eq('program_id', program)
            .eq('tenant_id', tenantId)
            .eq('tahun', Number(year))
            .maybeSingle();

          if (!existingBan) {
            const { error: banErr } = await supabase.from('bansos_recipients').insert({
              tenant_id: tenantId,
              program_id: program,
              resident_id: row.nik,
              nama: row.name,
              tahun: Number(year),
              tahun_mulai: Number(year),
              status: 'aktif',
              source: 'import',
              created_at: new Date().toISOString()
            });
            if (banErr) throw banErr;
            successCount++;
          } else {
            failedCount++;
          }
        } catch (e) {
          console.error("Gagal memproses NIK:", row.nik, e);
          failedCount++;
        }
      }
      
      setResult({ success: successCount, newResidents: newResidentCount, failed: failedCount });
      setStep(3);
      onRefresh();
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm font-sans">
      <div className="bg-white dark:bg-slate-800 rounded-3xl shadow-2xl w-full max-w-4xl flex flex-col max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-800/50">
          <h2 className="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <Database className="text-emerald-600" /> Import Massal Bantuan Sosial
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full text-slate-500 transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8">
          {step === 1 && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="relative">
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Program Bantuan</label>
                  <input
                    type="text"
                    value={program}
                    onChange={(e) => { setProgram(e.target.value); setShowProgramDropdown(true); }}
                    onFocus={() => setShowProgramDropdown(true)}
                    onBlur={() => setTimeout(() => setShowProgramDropdown(false), 200)}
                    placeholder="Ketik atau pilih program..."
                    className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                  {showProgramDropdown && (
                    <div className="absolute z-30 top-full mt-1 left-0 right-0 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl shadow-xl max-h-56 overflow-y-auto">
                      {PROGRAM_OPTIONS.filter(p => p.toLowerCase().includes(program.toLowerCase())).length === 0 ? (
                        <div className="px-3.5 py-2.5 text-xs text-gray-400 italic">Tidak ada yang cocok — ketik manual</div>
                      ) : (
                        PROGRAM_OPTIONS.filter(p => p.toLowerCase().includes(program.toLowerCase())).map(p => (
                          <button key={p} onMouseDown={() => { setProgram(p); setShowProgramDropdown(false); }}
                            className={`w-full text-left px-3.5 py-2.5 text-xs font-medium hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-gray-700 dark:text-slate-300 first:rounded-t-xl last:rounded-b-xl transition-colors ${p === program ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-bold' : ''}`}>
                            {p}
                          </button>
                        ))
                      )}
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Tahun Penyaluran</label>
                  <input 
                    type="number"
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>
              </div>

              <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-2xl p-10 text-center hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors relative cursor-pointer">
                <input 
                  type="file" 
                  accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
                  onChange={handleFileUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Upload size={32} />
                </div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-2">Klik atau Tarik File Excel/CSV Kesini</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm max-w-md mx-auto">
                  Pastikan file Anda memiliki header baris pertama yang memuat kolom <span className="font-bold">NIK</span> dan <span className="font-bold">Nama</span>.
                </p>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div className="bg-blue-50 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 p-4 rounded-xl flex gap-3">
                <AlertCircle className="shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Verifikasi Data</p>
                  <p className="text-sm mt-1">Ditemukan <strong>{parsedData.length}</strong> data penerima {program} tahun {year}. NIK yang belum ada di database akan otomatis ditambahkan sebagai penduduk baru.</p>
                </div>
              </div>

              <div className="border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden max-h-64 overflow-y-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 dark:bg-slate-800 sticky top-0">
                    <tr>
                      <th className="px-4 py-3 font-bold text-slate-700 dark:text-slate-300">No</th>
                      <th className="px-4 py-3 font-bold text-slate-700 dark:text-slate-300">NIK</th>
                      <th className="px-4 py-3 font-bold text-slate-700 dark:text-slate-300">Nama</th>
                      <th className="px-4 py-3 font-bold text-slate-700 dark:text-slate-300">Status Penduduk</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-700/50">
                    {parsedData.map((row, idx) => {
                      const isExisting = existingResidents.some(r => r.nik === row.nik);
                      return (
                        <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/30">
                          <td className="px-4 py-3 text-slate-500">{idx + 1}</td>
                          <td className="px-4 py-3 font-mono text-slate-700 dark:text-slate-300">{row.nik}</td>
                          <td className="px-4 py-3 font-medium text-slate-800 dark:text-white">{row.name}</td>
                          <td className="px-4 py-3">
                            {isExisting ? (
                              <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400">Terdaftar</span>
                            ) : (
                              <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400">Baru (Akan Ditambahkan)</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-700">
                <button 
                  onClick={() => setStep(1)}
                  className="px-6 py-2.5 rounded-xl font-bold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
                >
                  Batal
                </button>
                <button 
                  onClick={handleImport}
                  disabled={processing}
                  className="px-8 py-2.5 rounded-xl font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200 dark:shadow-none flex items-center gap-2 disabled:opacity-50"
                >
                  {processing ? <Loader2 className="animate-spin w-5 h-5" /> : <Database className="w-5 h-5" />}
                  {processing ? 'Memproses...' : 'Mulai Sinkronisasi'}
                </button>
              </div>
            </div>
          )}

          {step === 3 && result && (
            <div className="text-center py-10">
              <div className="w-24 h-24 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle size={48} />
              </div>
              <h2 className="text-3xl font-bold text-slate-800 dark:text-white mb-4">Import Selesai!</h2>
              <p className="text-lg text-slate-600 dark:text-slate-300 mb-8 max-w-lg mx-auto">
                Berhasil mensinkronkan <strong>{result.success}</strong> data penerima {program} tahun {year}.
                {result.newResidents > 0 && <span> Termasuk <strong>{result.newResidents}</strong> penduduk baru yang ditambahkan otomatis.</span>}
                {result.failed > 0 && <span className="text-amber-600 block mt-2">{result.failed} data sudah ada sebelumnya (duplikat, tidak ditambahkan ulang).</span>}
              </p>
              <button 
                onClick={onClose}
                className="px-8 py-3 rounded-xl font-bold text-white bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 transition-colors"
              >
                Tutup & Kembali
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
