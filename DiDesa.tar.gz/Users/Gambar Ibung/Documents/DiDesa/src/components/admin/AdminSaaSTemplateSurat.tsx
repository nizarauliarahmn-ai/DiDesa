import React, { useState, useEffect } from 'react';
import { FileText, Plus, Search, Edit2, Trash2, CheckCircle2, X } from 'lucide-react';
import { showToast } from '../../utils/toast';
import { supabase } from '../../utils/supabase';
import { resolveCurrentTenant } from '../../utils/tenantResolver';
import { INITIAL_CLASSIFICATIONS } from '../../utils/letterClassifications';

export default function AdminSaaSTemplateSurat() {
  const [templates, setTemplates] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Delete confirmation modal state
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  
  // SaaS requests state
  const [requests, setRequests] = useState<any[]>([]);
  
  const [formData, setFormData] = useState({
    jenis: '',
    klasifikasi: '',
    kodeKlasifikasi: '',
    deskripsi: '',
    noUrutTerakhir: 0
  });

  useEffect(() => {
    // SUPABASE-FIRST LOAD: selalu fetch dari Supabase, localStorage hanya fallback sementara
    const loadTemplates = async () => {
      Promise.resolve().then(async () => {
        const initial = INITIAL_CLASSIFICATIONS;

        // 1. Coba ambil dari Supabase dulu (sumber kebenaran)
        let supabaseData: any[] | null = null;
        try {
          const { data, error } = await supabase
            .from('saas_settings')
            .select('value')
            .eq('key', 'saas_global_letter_catalog')
            .maybeSingle();
          if (!error && data?.value) {
            supabaseData = JSON.parse(data.value);
          }
        } catch (e) {
          console.warn('[SaaSTemplateSurat] Gagal fetch dari Supabase, gunakan localStorage fallback:', e);
        }

        // 2. Jika Supabase berhasil, update localStorage cache
        if (supabaseData && Array.isArray(supabaseData)) {
          localStorage.setItem('saas_global_letter_catalog', JSON.stringify(supabaseData));
        }

        // 3. Gunakan data dari Supabase / localStorage. Hanya fallback ke initial jika belum pernah ada konfigurasi sama sekali
        const source = (supabaseData && Array.isArray(supabaseData) && supabaseData.length > 0)
          ? supabaseData 
          : (() => {
              const stored = localStorage.getItem('saas_global_letter_catalog');
              if (stored) {
                try {
                  const p = JSON.parse(stored);
                  if (Array.isArray(p) && p.length > 0) return p;
                } catch (e) {}
              }
              return null;
            })() || initial;

        // Deduplicate by klasifikasi
        const uniqueTemplatesMap = new Map();
        source.forEach((item: any) => {
          if (!uniqueTemplatesMap.has(item.klasifikasi)) {
            uniqueTemplatesMap.set(item.klasifikasi, item);
          }
        });
        const deduplicatedTemplates = Array.from(uniqueTemplatesMap.values());

        setTemplates(deduplicatedTemplates);
      });
    };
    loadTemplates();

    const fetchRequestsFromSupabase = async () => {
      try {
        const { data } = await supabase
          .from('saas_settings')
          .select('value')
          .eq('key', 'saas_letter_requests')
          .limit(1)
          .maybeSingle();

        if (data?.value) {
          const parsed = JSON.parse(data.value);
          setRequests(parsed);
          localStorage.setItem('saas_letter_requests', data.value);
          return;
        }
      } catch (e) {
        console.error('Error fetching letter requests:', e);
      }

      const storedReqs = localStorage.getItem('saas_letter_requests');
      if (storedReqs) {
        setRequests(JSON.parse(storedReqs));
      }
    };

    fetchRequestsFromSupabase();

    const channel = supabase
      .channel('public:saas_letter_requests_channel')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'saas_settings' },
        (payload: any) => {
          if (payload.new && payload.new.key === 'saas_letter_requests') {
            fetchRequestsFromSupabase();
          }
        }
      )
      .on('broadcast', { event: 'new_letter_request' }, (payload: any) => {
        if (payload?.payload?.requests) {
          localStorage.setItem('saas_letter_requests', JSON.stringify(payload.payload.requests));
          setRequests(payload.payload.requests);
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

    const generateKodeKlasifikasi = (jenisSurat: string) => {
    const j = jenisSurat.toLowerCase();
    if (j.includes('lahir') || j.includes('kelahiran')) return '474.1';
    if (j.includes('mati') || j.includes('kematian')) return '474.3';
    if (j.includes('pindah')) return '475';
    if (j.includes('nikah') || j.includes('kawin') || j.includes('perawan') || j.includes('belum kawin')) return '474.2';
    if (j.includes('tanah') || j.includes('agraria') || j.includes('jual beli')) return '593';
    if (j.includes('usaha') || j.includes('dagang') || j.includes('ekonomi')) return '500';
    if (j.includes('keuangan') || j.includes('penghasilan') || j.includes('gaji')) return '900';
    if (j.includes('hilang') || j.includes('kehilangan') || j.includes('skck') || j.includes('kelakuan baik') || j.includes('skkb')) return '331';
    if (j.includes('domisili') || j.includes('tinggal') || j.includes('penduduk')) return '470';
    if (j.includes('kuasa') || j.includes('rekomendasi') || j.includes('perjanjian')) return '100';
    if (j.includes('pegawai') || j.includes('undur')) return '800';
    if (j.includes('miskin') || j.includes('sktm') || j.includes('bantuan')) return '460';
    if (j.includes('ahli waris') || j.includes('waris')) return '474';
    if (j.includes('umum') || j.includes('keterangan') || j.includes('pengantar')) return '400';
    if (j.includes('undangan')) return '005';
    return '140';
  };

  const generateSingkatan = (jenisSurat: string, existingSingkatan: string[]) => {
    if (!jenisSurat) return '';
    let words = jenisSurat.toUpperCase().replace(/[^A-Z\s]/g, '').trim().split(/\s+/);
    if (words.length === 0 || words[0] === '') return '';
    
    let baseSingkatan = '';
    
    if (words[0] === 'SURAT' && words[1] === 'KETERANGAN' && words.length > 2) {
      baseSingkatan = 'SK' + words.slice(2).map(w => w[0]).join('');
    } else if (words[0] === 'SURAT' && words.length > 1) {
      baseSingkatan = 'S' + words.slice(1).map(w => w[0]).join('');
    } else {
      baseSingkatan = words.map(w => w[0]).join('');
    }

    if (baseSingkatan.length < 2 && words.length === 1) {
      baseSingkatan = words[0].substring(0, 3).toUpperCase();
    }
    
    baseSingkatan = baseSingkatan.substring(0, 5);
    
    let attempt = baseSingkatan;
    let counter = 1;
    while (existingSingkatan.includes(attempt)) {
        if (counter < 10 && baseSingkatan.length < 5) {
            attempt = baseSingkatan + counter;
        } else if (counter < 10) {
            attempt = baseSingkatan.substring(0, 4) + counter;
        } else {
            attempt = baseSingkatan.substring(0, 3) + counter;
        }
        counter++;
    }
    
    return attempt;
  };

  const handleJenisChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const jenis = e.target.value.toUpperCase();
    const existing = templates.filter(t => t.id !== editingId).map(t => t.klasifikasi);
    const singkatan = generateSingkatan(jenis, existing);
    const kode = generateKodeKlasifikasi(jenis);
    
    setFormData({
      ...formData,
      jenis,
      klasifikasi: singkatan,
      kodeKlasifikasi: kode
    });
  };

  const toggleVisibility = async (id: string) => {
    const updated = templates.map(t => {
      if (t.id === id) {
        return { ...t, isVisible: t.isVisible === false ? true : false };
      }
      return t;
    });
    const success = await saveTemplates(updated);
    if (success) {
      showToast('Visibilitas template berhasil diubah', 'success');
    }
  };

  // SUPABASE-FIRST SAVE: Simpan ke Supabase dahulu, baru update localStorage sebagai cache
  const saveTemplates = async (newTemplates: any[]): Promise<boolean> => {
    const jsonStr = JSON.stringify(newTemplates);
    try {
      let tenantId = await resolveCurrentTenant();
      if (!tenantId) {
        tenantId = '11111111-1111-1111-1111-111111111111'; // Master default tenant UUID
      }

      // 1. Update/Insert for current tenant
      const { data: existing } = await supabase
        .from('saas_settings')
        .select('key')
        .eq('key', 'saas_global_letter_catalog')
        .eq('tenant_id', tenantId)
        .maybeSingle();

      let opError = null;
      if (existing) {
        const { error } = await supabase
          .from('saas_settings')
          .update({ value: jsonStr })
          .eq('key', 'saas_global_letter_catalog')
          .eq('tenant_id', tenantId);
        opError = error;
      } else {
        const { error } = await supabase
          .from('saas_settings')
          .insert({ key: 'saas_global_letter_catalog', value: jsonStr, tenant_id: tenantId });
        opError = error;
      }

      // 2. Broadcast/Sync update to ALL other tenant rows with saas_global_letter_catalog
      const { data: allRows } = await supabase
        .from('saas_settings')
        .select('tenant_id')
        .eq('key', 'saas_global_letter_catalog');

      if (allRows && allRows.length > 0) {
        for (const row of allRows) {
          if (row.tenant_id !== tenantId) {
            await supabase
              .from('saas_settings')
              .update({ value: jsonStr })
              .eq('key', 'saas_global_letter_catalog')
              .eq('tenant_id', row.tenant_id);
          }
        }
      }

      if (opError) {
        console.error('[SaaSTemplateSurat] Gagal simpan ke Supabase:', opError.message);
        showToast('Gagal menyimpan ke server: ' + opError.message, 'error');
        return false;
      }
      // Hanya update state & localStorage SETELAH Supabase berhasil
      setTemplates(newTemplates);
      localStorage.setItem('saas_global_letter_catalog', jsonStr);
      window.dispatchEvent(new Event('letter_classifications_updated'));
      window.dispatchEvent(new Event('village_settings_updated'));
      return true;
    } catch (e: any) {
      console.error('[SaaSTemplateSurat] Exception saat simpan:', e);
      showToast('Gagal menyimpan: ' + String(e), 'error');
      return false;
    }
  };

  const handleSave = async () => {
    if (!formData.jenis || !formData.klasifikasi || !formData.kodeKlasifikasi) {
      showToast('Harap lengkapi semua field', 'error');
      return;
    }

    if (editingId) {
      const updated = templates.map(t => 
        t.id === editingId ? { ...t, ...formData } : t
      );
      const ok = await saveTemplates(updated);
      if (ok) showToast('Template berhasil diperbarui', 'success');
    } else {
      const newTemplate = {
        id: 'global_' + Date.now().toString(),
        ...formData,
        isVisible: true
      };
      const ok = await saveTemplates([...templates, newTemplate]);
      if (ok) showToast('Template berhasil ditambahkan', 'success');
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    setDeleteConfirmId(id);
  };

  const confirmDelete = async () => {
    if (deleteConfirmId) {
      const updated = templates.filter(t => t.id !== deleteConfirmId);
      const ok = await saveTemplates(updated);
      if (ok) showToast('Template berhasil dihapus', 'success');
      setDeleteConfirmId(null);
    }
  };

  const openAddModal = () => {
    setEditingId(null);
    setFormData({
      jenis: '',
      klasifikasi: '',
      kodeKlasifikasi: '',
      deskripsi: '',
      noUrutTerakhir: 0
    });
    setIsModalOpen(true);
  };

  const openEditModal = (item: any) => {
    setEditingId(item.id);
    setFormData({
      jenis: item.jenis,
      klasifikasi: item.klasifikasi,
      kodeKlasifikasi: item.kodeKlasifikasi,
      deskripsi: item.deskripsi || '',
      noUrutTerakhir: item.noUrutTerakhir
    });
    setIsModalOpen(true);
  };

  const filtered = templates.filter(t => 
    t.jenis.toLowerCase().includes(searchQuery.toLowerCase()) || 
    t.klasifikasi.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="pb-24 space-y-6">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-sm dark:shadow-none border border-slate-100 dark:border-slate-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <FileText size={120} />
        </div>
        <div className="relative z-10">
          <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-2">Manajemen Template Surat</h2>
          <p className="text-slate-500 dark:text-slate-400 max-w-2xl leading-relaxed">
            Kelola katalog jenis surat secara global. Semua desa akan mewarisi daftar jenis surat yang dibuat di sini. Admin Desa dapat memilih untuk menampilkan atau menyembunyikan jenis surat di akun mereka.
          </p>
        </div>
      </div>

      {requests.length > 0 && (
        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-900/50 rounded-3xl p-6">
          <h3 className="font-bold text-blue-900 dark:text-blue-400 mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5" /> Pengajuan Tambah Surat ({requests.length})
          </h3>
          <div className="space-y-3">
            {requests.map(req => (
              <div key={req.id} className="bg-white dark:bg-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-blue-50 dark:border-blue-900/30 shadow-sm">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-sm text-gray-900 dark:text-white">{req.letterName}</span>
                    <span className="text-[10px] bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 px-2 py-0.5 rounded-full font-bold">Dari: {req.villageName}</span>
                  </div>
                  <div className="text-xs text-gray-500 dark:text-slate-400">
                    Lampiran: {req.fileData ? (
                      <a href={req.fileData} download={req.fileName} className="font-medium text-blue-600 dark:text-blue-400 hover:text-blue-800 underline cursor-pointer" title="Download Lampiran">
                        {req.fileName}
                      </a>
                    ) : (
                      <span className="font-medium text-slate-500">{req.fileName}</span>
                    )} • {new Date(req.timestamp).toLocaleString('id-ID')}
                  </div>
                </div>
                <button 
                  onClick={async () => {
                     setFormData({
                       jenis: req.letterName,
                       klasifikasi: '',
                       kodeKlasifikasi: '',
                       deskripsi: '',
                       noUrutTerakhir: 0
                     });
                     // Mark as resolved in Supabase
                     const newReqs = requests.filter((r: any) => r.id !== req.id);
                     setRequests(newReqs);
                     const jsonStr = JSON.stringify(newReqs);
                     localStorage.setItem("saas_letter_requests", jsonStr);

                     try {
                       await supabase
                         .from('saas_settings')
                         .update({ value: jsonStr })
                         .eq('key', 'saas_letter_requests');
                     } catch (e) {}

                     setIsModalOpen(true);
                  }}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-bold transition-colors shrink-0"
                >
                  Tinjau & Tambahkan
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-sm dark:shadow-none border border-slate-100 dark:border-slate-800 overflow-hidden">
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex flex-col md:flex-row gap-4 items-center justify-between bg-slate-50/50">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input 
              type="text" 
              placeholder="Cari nama atau singkatan surat..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all text-sm font-medium bg-white dark:bg-slate-900"
            />
          </div>
          <button 
            onClick={openAddModal}
            className="w-full md:w-auto px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
          >
            <Plus className="w-5 h-5" /> Tambah Template
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-800">
                <th className="p-4 pl-6 text-left">Jenis Surat</th>
                <th className="p-4 text-left">Singkatan</th>
                <th className="p-4 text-left">Kode Klasifikasi</th>
                <th className="p-4 text-center">Status</th>
                <th className="p-4 text-center">Tindakan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                  <td className="p-4 pl-6">
                    <span className="font-bold text-slate-900 dark:text-white">{item.jenis}</span>
                  </td>
                  <td className="p-4">
                    <span className="px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-bold">{item.klasifikasi}</span>
                  </td>
                  <td className="p-4 font-mono text-sm text-slate-600 dark:text-slate-400">
                    {item.kodeKlasifikasi}
                  </td>
                  <td className="p-4 text-center">
                    <button
                      onClick={() => toggleVisibility(item.id)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                        item.isVisible !== false ? 'bg-emerald-500' : 'bg-gray-300'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          item.isVisible !== false ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center justify-center gap-2">
                      <button 
                        onClick={() => openEditModal(item)}
                        className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 flex items-center justify-center transition-colors"
                        title="Edit Template"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDelete(item.id)}
                        className="w-8 h-8 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 flex items-center justify-center transition-colors"
                        title="Hapus Template"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={4} className="p-8 text-center text-slate-500 dark:text-slate-400 font-medium">
                    Tidak ada template surat yang ditemukan
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Tambah/Edit */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                {editingId ? 'Edit Template Surat' : 'Tambah Template Surat'}
              </h3>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:text-rose-500 hover:bg-rose-50 hover:border-rose-100 transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider ml-1">Jenis Surat Lengkap</label>
                <input 
                  type="text" 
                  value={formData.jenis}
                  onChange={handleJenisChange}
                  placeholder="Contoh: SURAT KETERANGAN USAHA"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none text-sm font-semibold"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider ml-1">Deskripsi / Subjudul (Kecil)</label>
                <input 
                  type="text" 
                  value={formData.deskripsi}
                  onChange={e => setFormData({ ...formData, deskripsi: e.target.value })}
                  placeholder="Contoh: Surat Keterangan Kehilangan / Miskin"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none text-sm font-semibold"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider ml-1">Singkatan (Dibuat Otomatis)</label>
                <input 
                  type="text" 
                  value={formData.klasifikasi}
                  readOnly
                  placeholder="Akan dibuat otomatis"
                  className="w-full px-4 py-3 rounded-xl border border-emerald-100 bg-emerald-50/50 focus:ring-0 outline-none text-sm font-bold text-emerald-700 cursor-not-allowed"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider ml-1">Kode Klasifikasi Arsip (Dibuat Otomatis)</label>
                <input 
                  type="text" 
                  value={formData.kodeKlasifikasi}
                  readOnly
                  placeholder="Akan dibuat otomatis"
                  className="w-full px-4 py-3 rounded-xl border border-emerald-100 bg-emerald-50/50 focus:ring-0 outline-none text-sm font-mono text-emerald-700 cursor-not-allowed"
                />
              </div>
            </div>
            
            <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 flex gap-3">
              <button 
                onClick={() => setIsModalOpen(false)}
                className="flex-1 px-6 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-xl font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
              >
                Batal
              </button>
              <button 
                onClick={handleSave}
                className="flex-1 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 flex items-center justify-center gap-2 shadow-sm dark:shadow-none transition-all"
              >
                <CheckCircle2 className="w-5 h-5" /> {editingId ? 'Simpan' : 'Tambahkan'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Konfirmasi Hapus */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="p-6 text-center space-y-4">
              <div className="w-16 h-16 bg-rose-100 dark:bg-rose-900/30 rounded-full flex items-center justify-center mx-auto text-rose-600">
                <Trash2 size={32} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Hapus Template?</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm">
                  Apakah Anda yakin ingin menghapus template ini? Tindakan ini tidak dapat dibatalkan.
                </p>
              </div>
            </div>
            <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 flex gap-3">
              <button 
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-xl font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
              >
                Batal
              </button>
              <button 
                onClick={confirmDelete}
                className="flex-1 px-4 py-2.5 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 shadow-sm dark:shadow-none transition-all"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
