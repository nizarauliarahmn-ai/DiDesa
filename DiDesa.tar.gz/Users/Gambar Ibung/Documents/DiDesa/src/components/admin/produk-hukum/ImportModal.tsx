import { useState, useCallback, useRef } from 'react';
import { Upload, X, FileSpreadsheet, FileText, CheckCircle2, AlertTriangle, ArrowRight, ArrowLeft, Eye } from 'lucide-react';
import * as XLSX from 'xlsx';
import { showToast } from '../../../utils/toast';

interface ParsedRow {
  [key: string]: any;
}

interface MappedData {
  no: number;
  tahun: string;
  uraian: string;
  tanggal: string;
  tanggalDiundangkan: string;
  jenisDokumen: string;
  arsip: boolean;
  ketArsip: string;
  ketLain: string;
  linkFile: string;
  [key: string]: any;
}

interface ColumnMapping {
  no: string;
  tahun: string;
  uraian: string;
  tanggal: string;
  tanggalDiundangkan: string;
  jenisDokumen: string;
  arsip: string;
  ketArsip: string;
  ketLain: string;
  linkFile: string;
}

const DEFAULT_MAPPING: ColumnMapping = {
  no: '',
  tahun: '',
  uraian: '',
  tanggal: '',
  tanggalDiundangkan: '',
  jenisDokumen: '',
  arsip: '',
  ketArsip: '',
  ketLain: '',
  linkFile: '',
};

const FIELD_LABELS: Record<keyof ColumnMapping, string> = {
  no: 'Nomor Urut',
  tahun: 'Tahun',
  uraian: 'Uraian',
  tanggal: 'Tanggal',
  tanggalDiundangkan: 'Tgl Diundangkan',
  jenisDokumen: 'Jenis Dokumen',
  arsip: 'Arsip (TRUE/FALSE)',
  ketArsip: 'Ket Arsip',
  ketLain: 'Ket Lain',
  linkFile: 'Link File (URL)',
};

const REQUIRED_FIELDS = ['uraian'];

function guessMapping(headers: string[]): ColumnMapping {
  const mapping = { ...DEFAULT_MAPPING };
  const lowerHeaders = headers.map(h => h.toLowerCase().trim());

  const findHeader = (patterns: string[]): string => {
    for (const pattern of patterns) {
      const idx = lowerHeaders.findIndex(h => h === pattern || h.includes(pattern));
      if (idx !== -1) return headers[idx];
    }
    return '';
  };

  mapping.no = findHeader(['no', 'nomor', 'urut', 'no.']);
  mapping.tahun = findHeader(['tahun', 'year', 'thn', 'th']);
  mapping.uraian = findHeader(['uraian', 'judul', 'deskripsi', 'description', 'title', 'nama', 'produk', 'keterangan uraian']);
  mapping.tanggal = findHeader(['tanggal', 'date', 'tgl', 'tmt']);
  mapping.tanggalDiundangkan = findHeader(['tanggal diundangkan', 'diundangkan', 'undang', 'publish', 'terbit', 'tgl undang', 'waktu', 'penetapan']);
  mapping.jenisDokumen = findHeader(['jenis dokumen', 'jenis', 'type', 'kategori', 'category', 'tipe']);
  mapping.arsip = findHeader(['arsip', 'archive']);
  mapping.ketArsip = findHeader(['ket arsip', 'keterangan arsip', 'status arsip', 'status']);
  mapping.ketLain = findHeader(['ket lain', 'keterangan lain', 'catatan', 'note', 'remark', 'keterangan', 'dasar', 'tentang', 'ref']);
  mapping.linkFile = findHeader(['link file', 'link', 'url', 'google drive', 'gdrive', 'file link', 'file']);

  return mapping;
}

function parseArsipValue(val: any): boolean {
  if (typeof val === 'boolean') return val;
  if (typeof val === 'number') return val !== 0;
  const str = String(val).toUpperCase().trim();
  return str === 'TRUE' || str === 'YA' || str === '1' || str === 'BENAR';
}

function formatPreviewDate(val: any): string {
  if (!val) return '';
  if (typeof val === 'number' && val > 30000 && val < 60000) {
    const d = new Date((val - 25569) * 86400 * 1000);
    return d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
  }
  if (typeof val === 'string' && /^\d{4}-\d{2}-\d{2}/.test(val)) {
    const d = new Date(val);
    return d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
  }
  return String(val);
}

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (data: MappedData[]) => void;
  kategoriLabel: string;
  kategori?: string;
}

export default function ImportModal({ isOpen, onClose, onImport, kategoriLabel, kategori }: ImportModalProps) {
  const [step, setStep] = useState<'upload' | 'mapping' | 'preview'>('upload');
  const [fileName, setFileName] = useState('');
  const [rawHeaders, setRawHeaders] = useState<string[]>([]);
  const [rawRows, setRawRows] = useState<ParsedRow[]>([]);
  const [mapping, setMapping] = useState<ColumnMapping>(DEFAULT_MAPPING);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropRef = useRef<HTMLDivElement>(null);

  const reset = () => {
    setStep('upload');
    setFileName('');
    setRawHeaders([]);
    setRawRows([]);
    setMapping(DEFAULT_MAPPING);
    setIsProcessing(false);
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const parseRawText = (text: string): { headers: string[]; rows: ParsedRow[] } => {
    const lines = text.split(/\r?\n/).filter(l => l.trim());
    if (lines.length < 2) return { headers: [], rows: [] };

    const sep = lines[0].split(';').length > lines[0].split(',').length ? ';' : ',';

    const parseLine = (line: string): string[] => {
      const result: string[] = [];
      let current = '';
      let inQuote = false;
      for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') { inQuote = !inQuote; continue; }
        if (ch === sep && !inQuote) { result.push(current.trim()); current = ''; continue; }
        current += ch;
      }
      result.push(current.trim());
      return result;
    };

    const headerKeywords = ['tahun', 'uraian', 'tanggal', 'jenis', 'arsip', 'link', 'keterangan', 'no'];
    let headerIdx = -1;
    for (let i = 0; i < Math.min(lines.length, 20); i++) {
      const lower = lines[i].toLowerCase();
      const matchCount = headerKeywords.filter(kw => lower.includes(kw)).length;
      if (matchCount >= 2) { headerIdx = i; break; }
    }
    if (headerIdx === -1) return { headers: [], rows: [] };

    const headers = parseLine(lines[headerIdx]).filter(h => h);
    const rows: ParsedRow[] = [];
    for (let i = headerIdx + 1; i < lines.length; i++) {
      const cells = parseLine(lines[i]);
      if (cells.every(c => !c)) continue;
      const obj: ParsedRow = {};
      headers.forEach((h, j) => { obj[h] = cells[j] ?? ''; });
      rows.push(obj);
    }
    return { headers, rows };
  };

  const processFile = useCallback((file: File) => {
    setIsProcessing(true);
    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const result = e.target?.result;

        let headers: string[] = [];
        let rows: ParsedRow[] = [];

        if (file.name.endsWith('.csv')) {
          const text = typeof result === 'string' ? result : new TextDecoder().decode(result as ArrayBuffer);
          const textResult = parseRawText(text);
          headers = textResult.headers;
          rows = textResult.rows;
        }

        if (rows.length === 0) {
          const data = new Uint8Array(result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          let jsonData: any[][] = [];

          let bestSheet = workbook.Sheets[workbook.SheetNames[0]];
          let bestCount = 0;
          for (const sheetName of workbook.SheetNames) {
            const sheet = workbook.Sheets[sheetName];
            const sheetData = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' }) as any[][];
            const nonEmptyRows = sheetData.filter(r => r && r.some(c => String(c || '').trim() !== ''));
            if (nonEmptyRows.length > bestCount) {
              bestCount = nonEmptyRows.length;
              bestSheet = sheet;
            }
          }

          jsonData = XLSX.utils.sheet_to_json(bestSheet, { header: 1, defval: '' }) as any[][];

          const range = XLSX.utils.decode_range(bestSheet['!ref'] || 'A1');
          for (let r = range.s.r; r <= range.e.r; r++) {
            for (let c = range.s.c; c <= range.e.c; c++) {
              const addr = XLSX.utils.encode_cell({ r, c });
              const cell = bestSheet[addr];
              if (cell && cell.l && cell.l.Target) {
                if (jsonData[r]) {
                  jsonData[r][c] = cell.l.Target;
                }
              }
            }
          }

          if (jsonData.length < 2) {
            for (const sn of workbook.SheetNames) {
              const sd = XLSX.utils.sheet_to_json(workbook.Sheets[sn], { header: 1, defval: '' }) as any[][];
              jsonData.push(...sd);
            }
          }

          if (jsonData.length < 2) {
            showToast('File kosong atau tidak ada data!', 'error');
            setIsProcessing(false);
            return;
          }

          const headerKeywords = ['tahun', 'year', 'uraian', 'deskripsi', 'tanggal', 'date', 'jenis', 'type', 'arsip', 'archive', 'link', 'keterangan', 'note', 'no', 'nomor'];
          let headerRowIndex = -1;

          for (let i = 0; i < Math.min(jsonData.length, 50); i++) {
            const row = jsonData[i] as any[];
            if (!row) continue;
            const rowText = row.map(c => String(c || '').toLowerCase().trim()).join(' ');
            const matchCount = headerKeywords.filter(kw => rowText.includes(kw)).length;
            if (matchCount >= 2) {
              headerRowIndex = i;
              break;
            }
          }

          if (headerRowIndex === -1) {
            for (let i = 0; i < Math.min(jsonData.length, 20); i++) {
              const row = jsonData[i] as any[];
              if (!row) continue;
              const nonEmpty = row.filter((c: any) => String(c || '').trim() !== '').length;
              if (nonEmpty >= 2) {
                headerRowIndex = i;
                break;
              }
            }
          }

          if (headerRowIndex === -1) {
            headerRowIndex = 0;
          }

          const rawHeaders = (jsonData[headerRowIndex] as any[]).map((h, i) => {
            const val = String(h || '').trim();
            return val || `Kolom ${i + 1}`;
          });
          let lastNonEmpty = rawHeaders.length - 1;
          while (lastNonEmpty >= 0 && !rawHeaders[lastNonEmpty] || rawHeaders[lastNonEmpty]?.startsWith('Kolom ')) lastNonEmpty--;
          if (lastNonEmpty < 0) lastNonEmpty = rawHeaders.length - 1;
          headers = rawHeaders.slice(0, lastNonEmpty + 1);

          rows = jsonData.slice(headerRowIndex + 1)
            .filter((row: any) => {
              return row && row.some((cell: any) => cell !== null && cell !== undefined && String(cell).trim() !== '');
            })
            .map((row: any) => {
              const obj: ParsedRow = {};
              headers.forEach((h, i) => { obj[h] = row[i] ?? ''; });
              return obj;
            });
        }

        if (headers.length === 0 || rows.length === 0) {
          showToast('Tidak dapat menemukan baris header di file!', 'error');
          setIsProcessing(false);
          return;
        }

        setRawHeaders(headers);
        setRawRows(rows);
        setMapping(guessMapping(headers));
        setStep('mapping');
      } catch (err) {
        showToast('Gagal membaca file! Pastikan format file benar.', 'error');
      } finally {
        setIsProcessing(false);
      }
    };
    reader.readAsArrayBuffer(file);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dropRef.current?.classList.remove('border-emerald-500', 'bg-emerald-50');

    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  }, [processFile]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dropRef.current?.classList.add('border-emerald-500', 'bg-emerald-50');
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dropRef.current?.classList.remove('border-emerald-500', 'bg-emerald-50');
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
    e.target.value = '';
  };

  const extractYear = (val: any): string => {
    if (!val) return '';
    if (val instanceof Date) return val.getFullYear().toString();
    const str = String(val).trim();
    if (!str) return '';
    const yearMatch = str.match(/(\d{4})/);
    return yearMatch ? yearMatch[1] : '';
  };

  const normalizeDate = (val: any): string => {
    if (!val) return '';
    if (val instanceof Date) return val.toISOString().slice(0, 10);
    const str = String(val).trim();
    if (!str) return '';
    const numVal = Number(str);
    if (!isNaN(numVal) && numVal > 30000 && numVal < 60000 && String(numVal) === str) {
      const utcDays = Math.floor(numVal - 25569);
      const d = new Date(utcDays * 86400 * 1000);
      return d.toISOString().slice(0, 10);
    }
    return str;
  };

  const mapRow = (row: ParsedRow, idx: number): MappedData => ({
    no: mapping.no ? (parseInt(String(row[mapping.no])) || 0) : 0,
    tahun: mapping.tahun ? extractYear(row[mapping.tahun]) : '',
    uraian: mapping.uraian ? String(row[mapping.uraian] || '') : '',
    tanggal: mapping.tanggal ? normalizeDate(row[mapping.tanggal]) : '',
    tanggalDiundangkan: mapping.tanggalDiundangkan ? normalizeDate(row[mapping.tanggalDiundangkan]) : '',
    jenisDokumen: mapping.jenisDokumen ? String(row[mapping.jenisDokumen] || '') : '',
    arsip: mapping.arsip ? parseArsipValue(row[mapping.arsip]) : true,
    ketArsip: mapping.ketArsip ? String(row[mapping.ketArsip] || '') : '',
    ketLain: mapping.ketLain ? String(row[mapping.ketLain] || '') : '',
    linkFile: mapping.linkFile ? String(row[mapping.linkFile] || '').trim() : '',
  });

  const getMappedPreview = (): MappedData[] => {
    return rawRows.slice(0, 100).map((row, idx) => mapRow(row, idx)).filter(item => item.uraian.trim() !== '');
  };

  const getAllMappedData = (): MappedData[] => {
    return rawRows.map((row, idx) => mapRow(row, idx)).filter(item => item.uraian.trim() !== '');
  };

  const getFilteredRowCount = (): number => {
    return rawRows.filter(row => {
      const uraianVal = mapping.uraian ? String(row[mapping.uraian] || '').trim() : '';
      return uraianVal !== '';
    }).length;
  };

  const handleImport = () => {
    const data = getAllMappedData();
    if (data.length === 0) {
      showToast('Tidak ada data untuk diimport!', 'error');
      return;
    }
    onImport(data);
    showToast(`${data.length} data berhasil diimport!`, 'success');
    handleClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-start justify-center pt-[5vh] sm:pt-[8vh] p-4 overflow-y-auto" onClick={handleClose}>
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-gray-100 dark:border-slate-800 w-full max-w-4xl" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 dark:border-slate-800">
          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white">Import {kategoriLabel}</h3>
            <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">
              {step === 'upload' && 'Upload file CSV atau Excel'}
              {step === 'mapping' && 'Mapping kolom file ke field aplikasi'}
              {step === 'preview' && 'Preview data sebelum diimport'}
            </p>
          </div>
          <button onClick={handleClose} className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-400 hover:text-gray-600 transition-colors">
            <X size={18} />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="px-6 py-3 border-b border-gray-100 dark:border-slate-800 flex items-center gap-2">
          {['upload', 'mapping', 'preview'].map((s, idx) => (
            <div key={s} className="flex items-center gap-2">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                step === s ? 'bg-emerald-600 text-white' :
                ['upload', 'mapping', 'preview'].indexOf(step) > idx ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600' :
                'bg-gray-100 dark:bg-slate-800 text-gray-400'
              }`}>
                {['upload', 'mapping', 'preview'].indexOf(step) > idx ? <CheckCircle2 size={14} /> : idx + 1}
              </div>
              <span className={`text-xs font-semibold hidden sm:inline ${
                step === s ? 'text-emerald-600' : 'text-gray-400'
              }`}>
                {s === 'upload' ? 'Upload' : s === 'mapping' ? 'Mapping' : 'Preview'}
              </span>
              {idx < 2 && <ArrowRight size={12} className="text-gray-300 mx-1" />}
            </div>
          ))}
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Step 1: Upload */}
          {step === 'upload' && (
            <div className="space-y-4">
              <div
                ref={dropRef}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-gray-200 dark:border-slate-700 rounded-2xl p-12 text-center cursor-pointer hover:border-emerald-400 hover:bg-emerald-50/30 dark:hover:bg-emerald-900/10 transition-all"
              >
                {isProcessing ? (
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mb-4" />
                    <p className="text-sm font-semibold text-gray-600 dark:text-slate-400">Memproses file...</p>
                  </div>
                ) : (
                  <>
                    <div className="w-16 h-16 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Upload size={28} />
                    </div>
                    <p className="text-sm font-bold text-gray-900 dark:text-white mb-1">Klik atau seret file ke sini</p>
                    <p className="text-xs text-gray-500 dark:text-slate-400 mb-4">Mendukung format CSV, Excel (.xlsx, .xls)</p>
                    <div className="flex items-center justify-center gap-4 text-[10px] text-gray-400">
                      <span className="flex items-center gap-1"><FileText size={12} /> .csv</span>
                      <span className="flex items-center gap-1"><FileSpreadsheet size={12} /> .xlsx</span>
                      <span className="flex items-center gap-1"><FileSpreadsheet size={12} /> .xls</span>
                    </div>
                  </>
                )}
              </div>
              <input ref={fileInputRef} type="file" accept=".csv,.xlsx,.xls" className="hidden" onChange={handleFileSelect} />
            </div>
          )}

          {/* Step 2: Mapping */}
          {step === 'mapping' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-blue-50 dark:bg-blue-900/20 rounded-xl p-3">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet size={16} className="text-blue-600" />
                  <span className="text-sm font-semibold text-blue-700 dark:text-blue-300">{fileName}</span>
                </div>
                <span className="text-xs text-blue-600 dark:text-blue-400">{rawRows.length} baris ditemukan</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(Object.keys(FIELD_LABELS) as (keyof ColumnMapping)[]).map((field) => {
                  const hideFields = kategori === 'berita_acara' 
                    ? ['tanggalDiundangkan', 'jenisDokumen', 'arsip', 'ketArsip'] 
                    : [];
                  if (hideFields.includes(field)) return null;
                  return (
                    <div key={field}>
                      <label className="block text-xs font-bold text-gray-600 dark:text-slate-400 mb-1">
                        {FIELD_LABELS[field]}
                        {REQUIRED_FIELDS.includes(field) && <span className="text-red-500 ml-0.5">*</span>}
                      </label>
                      <select
                        value={mapping[field]}
                        onChange={(e) => setMapping(prev => ({ ...prev, [field]: e.target.value }))}
                        className="w-full px-3 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-sm dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
                      >
                        <option value="">-- Pilih Kolom --</option>
                        {rawHeaders.map(h => (
                          <option key={h} value={h}>{h}</option>
                        ))}
                      </select>
                    </div>
                  );
                })}
              </div>

              {/* Preview Mapping Result */}
              <div className="bg-gray-50 dark:bg-slate-800/50 rounded-xl p-4">
                <p className="text-xs font-bold text-gray-500 dark:text-slate-400 mb-2">Preview (5 baris pertama):</p>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-gray-200 dark:border-slate-700">
                        {rawHeaders.slice(0, 6).map(h => (
                          <th key={h} className="px-2 py-1 text-left font-bold text-gray-500 dark:text-slate-400">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {rawRows.slice(0, 5).map((row, i) => (
                        <tr key={i} className="border-b border-gray-100 dark:border-slate-800">
                          {rawHeaders.slice(0, 6).map(h => {
                            const isDateCol = ['tanggal', 'tgl', 'date', 'diundangkan', 'undang', 'waktu', 'penetapan'].some(k => h.toLowerCase().includes(k));
                            return <td key={h} className="px-2 py-1 text-gray-700 dark:text-slate-300 max-w-[120px] truncate">{isDateCol ? formatPreviewDate(row[h]) : String(row[h] || '')}</td>;
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Preview */}
          {step === 'preview' && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl p-3">
                <CheckCircle2 size={16} className="text-emerald-600" />
                <span className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">
                  {getAllMappedData().length} data valid siap diimport
                  {rawRows.length > getAllMappedData().length && (
                    <span className="text-xs font-normal text-emerald-600/70 dark:text-emerald-400/70 ml-1">
                      (dari {rawRows.length} baris, {rawRows.length - getAllMappedData().length} baris kosong/tanpa uraian dibuang)
                    </span>
                  )}
                  {getAllMappedData().length > 100 && (
                    <span className="text-xs font-normal text-emerald-600/70 dark:text-emerald-400/70 ml-1">
                      (menampilkan 100 dari {getAllMappedData().length})
                    </span>
                  )}
                </span>
              </div>

              <div className="overflow-x-auto max-h-[300px] overflow-y-auto border border-gray-100 dark:border-slate-800 rounded-xl">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 bg-gray-50 dark:bg-slate-800">
                    <tr className="border-b border-gray-200 dark:border-slate-700">
                      <th className="px-3 py-2 text-left font-bold text-gray-500 dark:text-slate-400">No</th>
                      <th className="px-3 py-2 text-left font-bold text-gray-500 dark:text-slate-400">Tahun</th>
                      <th className="px-3 py-2 text-left font-bold text-gray-500 dark:text-slate-400">Uraian</th>
                      <th className="px-3 py-2 text-left font-bold text-gray-500 dark:text-slate-400">Tanggal</th>
                      {kategori !== 'berita_acara' && (
                        <>
                          <th className="px-3 py-2 text-left font-bold text-gray-500 dark:text-slate-400">Jenis</th>
                          <th className="px-3 py-2 text-left font-bold text-gray-500 dark:text-slate-400">Arsip</th>
                          <th className="px-3 py-2 text-left font-bold text-gray-500 dark:text-slate-400">Ket Arsip</th>
                        </>
                      )}
                      <th className="px-3 py-2 text-left font-bold text-gray-500 dark:text-slate-400">{kategori === 'berita_acara' ? 'Keterangan' : 'Ket Lain'}</th>
                      <th className="px-3 py-2 text-left font-bold text-gray-500 dark:text-slate-400">Link File</th>
                    </tr>
                  </thead>
                  <tbody>
                    {getMappedPreview().map((item, i) => {
                      const needsReview = (!item.no && kategori === 'berita_acara') || !item.tahun;
                      return (
                      <tr key={i} className={`border-b border-gray-50 dark:border-slate-800/50 hover:bg-gray-50/50 dark:hover:bg-slate-800/30 ${needsReview ? 'bg-amber-50/60 dark:bg-amber-900/10' : ''}`}>
                        <td className="px-3 py-2 font-bold text-gray-900 dark:text-white">
                          {item.no || <span className="text-amber-600 font-semibold">Perlu diisi</span>}
                        </td>
                        <td className="px-3 py-2 text-gray-700 dark:text-slate-300">
                          {item.tahun || <span className="text-amber-600 font-semibold">Perlu diisi</span>}
                        </td>
                        <td className="px-3 py-2 text-gray-900 dark:text-white max-w-[200px] truncate">{item.uraian || '-'}</td>
                        <td className="px-3 py-2 text-gray-600 dark:text-slate-400 whitespace-nowrap">{item.tanggal || '-'}</td>
                        {kategori !== 'berita_acara' && (
                          <>
                            <td className="px-3 py-2">
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300">
                                {item.jenisDokumen || '-'}
                              </span>
                            </td>
                            <td className="px-3 py-2">
                              {item.arsip ? (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300">Ya</span>
                              ) : (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-gray-100 dark:bg-slate-800 text-gray-500">Tidak</span>
                              )}
                            </td>
                            <td className="px-3 py-2 text-gray-500 dark:text-slate-400">{item.ketArsip || '-'}</td>
                          </>
                        )}
                        <td className="px-3 py-2 text-gray-500 dark:text-slate-400">{item.ketLain || '-'}</td>
                        <td className="px-3 py-2 text-gray-500 dark:text-slate-400 max-w-[150px] truncate">{item.linkFile ? <a href={item.linkFile} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{item.linkFile}</a> : '-'}</td>
                      </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-100 dark:border-slate-800 flex justify-between">
          <button
            onClick={step === 'upload' ? handleClose : () => setStep(step === 'preview' ? 'mapping' : 'upload')}
            className="flex items-center gap-2 px-4 py-2.5 bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-slate-300 font-bold rounded-xl hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors text-sm"
          >
            <ArrowLeft size={14} />
            {step === 'upload' ? 'Batal' : 'Kembali'}
          </button>

          {step === 'mapping' && (
            <button
              onClick={() => {
                if (!mapping.uraian) {
                  showToast('Field "Uraian" wajib di-map!', 'error');
                  return;
                }
                setStep('preview');
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition-colors text-sm"
            >
              Lanjut Preview
              <ArrowRight size={14} />
            </button>
          )}

          {step === 'preview' && (
            <button
              onClick={handleImport}
              className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition-colors text-sm"
            >
              <CheckCircle2 size={14} />
              Import {getAllMappedData().length} Data
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
