import NumberCounter from '../common/NumberCounter';
import React, { useState, useEffect } from 'react';
import { supabase } from '../../utils/supabase';
import { 
  Database, Plus, Search, Server, Activity, MoreVertical, 
  Globe, ShieldCheck, X, Megaphone, Building2, MessageSquare, 
  Trash2, CheckCircle, ExternalLink, Edit2, Key, Copy, Check, 
  Lock, Mail, Eye, EyeOff, AlertTriangle, Printer, RefreshCw
} from 'lucide-react';
import AdminGlobalUpdates from './AdminGlobalUpdates';
import { getFeedbacks, fetchFeedbacksAsync, markFeedbacksAsRead, updateFeedbackStatus, deleteFeedback, Feedback } from '../../utils/feedbackData';
import { addSaaSLog } from '../../utils/saasLogs';
import { showToast } from '../../utils/toast';

export default function AdminTenants() {
  const [activeTab, setActiveTab] = useState<'tenants' | 'updates' | 'feedback'>('tenants');
  const [tenants, setTenants] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modals state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedTenant, setSelectedTenant] = useState<any>(null);
  
  // Forms state
  const [formData, setFormData] = useState({ 
    nama_desa: '', 
    kode_desa: '', 
    domain: '',
    admin_email: '',
    admin_password: '',
    kades_email: '',
    kades_password: ''
  });
  
  const [editFormData, setEditFormData] = useState({
    id: '',
    nama_desa: '',
    kode_desa: '',
    domain: '',
    status: 'active',
    admin_email: '',
    admin_password: '',
    kades_email: '',
    kades_password: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [authUser, setAuthUser] = useState<{ name: string; email: string; role: string } | null>(null);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  
  // UI States
  const [showRowPasswords, setShowRowPasswords] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeDropdownId, setActiveDropdownId] = useState<string | null>(null);

  // Reset password state
  const [resetTenant, setResetTenant] = useState<any>(null);
  const [resetAccount, setResetAccount] = useState<'kades' | 'admin'>('admin');
  const [resetPassword, setResetPassword] = useState('');
  const [showResetPassword, setShowResetPassword] = useState(true);
  const [resetCopied, setResetCopied] = useState(false);

  const handleLoginAs = (tenant: any) => {
    if (!authUser) return;
    
    // Save current SaaS admin for recovery
    localStorage.setItem('didesa_impersonator', JSON.stringify(authUser));
    
    // Create temporary session for the selected tenant
    const impersonatedUser = {
      name: `Admin ${tenant.nama_desa}`,
      email: tenant.admin_email || `admin@${tenant.domain || 'desa.id'}`,
      role: 'admin',
      tenantId: tenant.id,
      isImpersonated: true
    };
    
    // ── Inject SEMUA data kop surat dari tenant ke localStorage ──
    // Ini memastikan pratinjau kop di Pengaturan selalu sesuai
    // dengan konfigurasi yang super admin atur per tenant
    const rawNamaDesa = tenant.nama_desa || '';
    localStorage.setItem('kop_desa',       rawNamaDesa.toLowerCase().startsWith('desa') || rawNamaDesa.toLowerCase().startsWith('didesa') ? rawNamaDesa : `DiDesa ${rawNamaDesa}`);
    localStorage.setItem('village_name',   tenant.nama_desa || '');
    localStorage.setItem('kop_kecamatan',  tenant.kecamatan || tenant.nama_kecamatan || '');
    localStorage.setItem('village_kecamatan', tenant.kecamatan || tenant.nama_kecamatan || '');
    localStorage.setItem('kop_kabupaten',  tenant.kabupaten || tenant.nama_kabupaten || '');
    localStorage.setItem('village_kabupaten', tenant.kabupaten || tenant.nama_kabupaten || '');
    localStorage.setItem('kop_alamat',     tenant.alamat || '');
    localStorage.setItem('village_alamat', tenant.alamat || '');
    localStorage.setItem('kop_kontak',     tenant.kontak || tenant.telepon || '');
    if (tenant.logo_url) {
      localStorage.setItem('kop_logo_url', tenant.logo_url);
    }
    if (tenant.kode_desa) {
      localStorage.setItem('village_id', tenant.kode_desa);
    }
    if (tenant.domain) {
      localStorage.setItem('village_domain', tenant.domain);
    }
    
    localStorage.setItem('didesa_auth_user', JSON.stringify(impersonatedUser));
    
    addSaaSLog({
      admin: authUser.name,
      aksi: 'Impersonasi Login',
      target: tenant.nama_desa,
      status: 'Berhasil'
    });

    showToast(`Berhasil masuk sebagai Admin ${tenant.nama_desa}!`, 'success');
    window.location.reload();
  };


  useEffect(() => {
    const handleFeedbackUpdate = () => {
      setFeedbacks(getFeedbacks());
    };
    handleFeedbackUpdate();
    window.addEventListener('feedback_updated', handleFeedbackUpdate);
    return () => window.removeEventListener('feedback_updated', handleFeedbackUpdate);
  }, []);

  useEffect(() => {
    fetchFeedbacksAsync().then(list => markFeedbacksAsRead((list || []).map(f => f.id)));
  }, []);

  useEffect(() => {
    const savedUser = localStorage.getItem('didesa_auth_user');
    if (savedUser) {
      setAuthUser(JSON.parse(savedUser));
    }
  }, []);

  const fetchTenants = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tenants')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      setTenants(data || []);
    } catch (err) {
      console.error("Error fetching tenants from Supabase:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTenants();
  }, []);

  // Update suggestions based on village name or domain
  useEffect(() => {
    if (formData.domain && !formData.admin_email) {
      setFormData(prev => ({
        ...prev,
        admin_email: `admin@${prev.domain}`,
        kades_email: `kades@${prev.domain}`,
        admin_password: 'admin123',
        kades_password: 'kades123'
      }));
    }
  }, [formData.domain]);

  const handleAddTenant = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const cleanDomain = (formData.domain || formData.nama_desa || '').toLowerCase().trim().replace(/\s+/g, '').replace(/[^a-z0-9]/g, '').replace(/^https?:\/\//, '').split('.')[0];
      const payload = {
        ...formData,
        domain: cleanDomain,
        admin_email: formData.admin_email || `admin@${cleanDomain || 'desa.id'}`,
        admin_password: formData.admin_password || 'admin123',
        kades_email: formData.kades_email || `kades@${cleanDomain || 'desa.id'}`,
        kades_password: formData.kades_password || 'kades123'
      };

      const { data, error } = await supabase
        .from('tenants')
        .insert([payload])
        .select();

      if (!error && data) {
        setIsModalOpen(false);
        setFormData({ 
          nama_desa: '', 
          kode_desa: '', 
          domain: '',
          admin_email: '',
          admin_password: '',
          kades_email: '',
          kades_password: ''
        });
        showToast('Klien desa berhasil didaftarkan!', 'success');
        fetchTenants();
        
        addSaaSLog({
          admin: authUser?.name || 'SaaS Admin',
          aksi: 'Tambah Klien Baru',
          target: payload.nama_desa,
          status: 'Berhasil'
        });
      } else {
        showToast(`Gagal: ${error?.message || 'Error Supabase'}`, 'error');
      }
    } catch (err) {
      console.error("Error adding tenant", err);
      showToast('Gagal mendaftarkan klien baru', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePrint = (singleVillageName?: string) => {
    if (singleVillageName) setSearchQuery(singleVillageName);

    setTimeout(() => {
      const table = document.getElementById('tenants-table');
      if (!table) return;
      
      const clone = table.cloneNode(true) as HTMLTableElement;
      
      const rows = clone.querySelectorAll('tr');
      rows.forEach(row => {
        if (row.children.length > 0) {
          row.removeChild(row.lastElementChild!);
        }
      });

      const printContent = clone.outerHTML;
      const win = window.open('', '', 'height=700,width=1000');
      if (win) {
        win.document.write(`
          <html>
            <head>
              <title>Cetak Data Kredensial</title>
              <style>
                body { font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; padding: 30px; color: #111; }
                .print-header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
                h1 { margin: 0 0 10px 0; text-transform: uppercase; font-size: 24px; letter-spacing: 1px; }
                p { margin: 0; color: #555; font-size: 14px; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 13px; }
                th, td { border: 1px solid #ddd; padding: 12px 15px; text-align: left; vertical-align: middle; }
                th { background-color: #f4f6f8; font-weight: 700; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; color: #333; }
                tr:nth-child(even) td { background-color: #fafafa; }
                .hidden { display: none !important; }
                span { display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
                .bg-emerald-100 { background: #d1fae5; color: #047857; }
                .bg-amber-100 { background: #fef3c7; color: #b45309; }
                .bg-gray-100 { background: #f3f4f6; color: #374151; }
                .text-blue-600 { color: #2563eb; }
                .flex { display: flex; align-items: center; gap: 4px; }
                .print-hide { display: none !important; }
                .print-show { display: block !important; }
                .print-show-inline { display: inline-block !important; }
                svg { width: 14px; height: 14px; display: inline-block; vertical-align: middle; flex-shrink: 0; }
              </style>
            </head>
            <body>
              <div class="print-header">
                <h1>Data Kredensial Klien DiDesa</h1>
                <p>Dicetak pada: ${new Date().toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
                ${singleVillageName ? `<p style="margin-top:5px; font-weight:bold; color:#059669;">Filter: ${singleVillageName}</p>` : ''}
              </div>
              ${printContent}
            </body>
          </html>
        `);
        win.document.close();
        win.focus();
        setTimeout(() => {
          win.print();
          win.close();
          if (singleVillageName) setSearchQuery('');
        }, 500);
      }
    }, 100);
  };

  const handleOpenEditModal = (tenant: any) => {
    setEditFormData({
      id: tenant.id,
      nama_desa: tenant.nama_desa,
      kode_desa: tenant.kode_desa,
      domain: tenant.domain || '',
      status: tenant.status || 'active',
      admin_email: tenant.admin_email || `admin@${tenant.domain || 'desa.id'}`,
      admin_password: tenant.admin_password || 'admin123',
      kades_email: tenant.kades_email || `kades@${tenant.domain || 'desa.id'}`,
      kades_password: tenant.kades_password || 'kades123'
    });
    setIsEditModalOpen(true);
    setActiveDropdownId(null);
  };

  const handleEditTenant = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const { error } = await supabase
        .from('tenants')
        .update({
          nama_desa: editFormData.nama_desa,
          kode_desa: editFormData.kode_desa,
          domain: editFormData.domain,
          status: editFormData.status,
          admin_email: editFormData.admin_email,
          admin_password: editFormData.admin_password,
          kades_email: editFormData.kades_email,
          kades_password: editFormData.kades_password
        })
        .eq('id', editFormData.id);

      if (!error) {
        setIsEditModalOpen(false);
        showToast('Kredensial & data klien berhasil diperbarui!', 'success');
        fetchTenants();
        
        addSaaSLog({
          admin: authUser?.name || 'SaaS Admin',
          aksi: 'Update Klien & Kredensial',
          target: editFormData.nama_desa,
          status: 'Berhasil'
        });
      } else {
        showToast(`Gagal memperbarui: ${error.message}`, 'error');
      }
    } catch (err) {
      console.error("Error updating tenant", err);
      showToast('Gagal memperbarui data klien', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteTenant = async (tenant: any) => {
    const isConfirmed = window.confirm(`Apakah Anda yakin ingin menghapus klien "${tenant.nama_desa}"? Semua data di-isolasi tidak akan dapat diakses.`);
    if (!isConfirmed) return;

    try {
      const { error } = await supabase
        .from('tenants')
        .delete()
        .eq('id', tenant.id);
        
      if (!error) {
        showToast(`Klien "${tenant.nama_desa}" berhasil dihapus dari sistem!`, 'success');
        fetchTenants();
        
        addSaaSLog({
          admin: authUser?.name || 'SaaS Admin',
          aksi: 'Hapus Klien Desa',
          target: tenant.nama_desa,
          status: 'Berhasil'
        });
      } else {
        showToast(`Gagal menghapus: ${error.message}`, 'error');
      }
    } catch (err) {
      console.error("Error deleting tenant", err);
      showToast('Terjadi kesalahan saat menghapus klien', 'error');
    }
    setActiveDropdownId(null);
  };

  const handleCopyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    showToast('Kredensial disalin ke clipboard!', 'success');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const generateSecurePassword = () => {
    const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%';
    const cryptoObj = window.crypto || (window as any).msCrypto;
    const getRand = () => {
      if (cryptoObj && cryptoObj.getRandomValues) {
        const buf = new Uint32Array(1);
        cryptoObj.getRandomValues(buf);
        return buf[0] / 4294967296;
      }
      return Math.random();
    };
    let pass = '';
    for (let i = 0; i < 12; i++) {
      pass += chars[Math.floor(getRand() * chars.length)];
    }
    return pass;
  };

  const openResetModal = (tenant: any) => {
    setResetTenant(tenant);
    setResetAccount('admin');
    setResetPassword(generateSecurePassword());
    setShowResetPassword(true);
    setResetCopied(false);
    setActiveDropdownId(null);
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetTenant || !resetPassword.trim()) return;

    if (!authUser || authUser.role !== 'saas_admin' || (authUser as any).isImpersonated) {
      showToast('Akses ditolak: hanya Pengelola Platform (SaaS Admin) yang dapat mereset kata sandi.', 'error');
      return;
    }

    const accountLabel = resetAccount === 'kades' ? 'Super Admin' : 'Admin';
    setIsSubmitting(true);
    try {
      const updates = resetAccount === 'kades'
        ? { kades_password: resetPassword }
        : { admin_password: resetPassword };

      const { error } = await supabase
        .from('tenants')
        .update(updates)
        .eq('id', resetTenant.id);

      if (error) {
        showToast(`Gagal mereset kata sandi: ${error.message}`, 'error');
        setIsSubmitting(false);
        return;
      }

      setResetTenant(null);
      showToast(`Kata sandi ${accountLabel} ${resetTenant.nama_desa} berhasil diganti!`, 'success');
      fetchTenants();

      addSaaSLog({
        admin: authUser?.name || 'SaaS Admin',
        aksi: 'Reset Kata Sandi',
        target: `${resetTenant.nama_desa} (${accountLabel})`,
        status: 'Berhasil'
      });
    } catch (err) {
      console.error("Error resetting password", err);
      showToast('Terjadi kesalahan saat mereset kata sandi', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyResetPassword = () => {
    if (!resetPassword) return;
    navigator.clipboard.writeText(resetPassword);
    setResetCopied(true);
    showToast('Kata sandi baru disalin ke clipboard!', 'success');
    setTimeout(() => setResetCopied(false), 2000);
  };

  const filteredTenants = tenants.filter(tenant => {
    const query = searchQuery.toLowerCase();
    return (
      tenant.nama_desa.toLowerCase().includes(query) ||
      (tenant.domain || '').toLowerCase().includes(query) ||
      tenant.kode_desa.toLowerCase().includes(query)
    );
  });

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex justify-between items-center border-b border-gray-200 dark:border-slate-700">
        <div className="flex">
          <button
            onClick={() => setActiveTab('tenants')}
            className={`px-6 py-3 text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'tenants' 
                ? 'border-emerald-600 text-emerald-700' 
                : 'border-transparent text-gray-400 hover:text-gray-600'
            }`}
          >
            <Server size={18} />
            Manajemen Klien & Kredensial
          </button>
          <button
            onClick={() => setActiveTab('updates')}
            className={`px-6 py-3 text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'updates' 
                ? 'border-emerald-600 text-emerald-700' 
                : 'border-transparent text-gray-400 hover:text-gray-600'
            }`}
          >
            <Megaphone size={18} />
            Update Global
          </button>
          <button
            onClick={() => setActiveTab('feedback')}
            className={`px-6 py-3 text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'feedback' 
                ? 'border-emerald-600 text-emerald-700' 
                : 'border-transparent text-gray-400 hover:text-gray-600'
            }`}
          >
            <MessageSquare size={18} />
            Feedback Pengguna
            {feedbacks.filter(f => f.status === 'Baru').length > 0 && (
              <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full ml-1 animate-pulse">
                {feedbacks.filter(f => f.status === 'Baru').length}
              </span>
            )}
          </button>
        </div>
        
        <button
          onClick={async () => {
            if (window.confirm('Yakin ingin memaksa seluruh layar Kios & Admin se-Indonesia memuat ulang secara otomatis sekarang? Pastikan Anda baru saja merilis pembaruan baru.')) {
              try {
                const channel = supabase.channel('global-broadcast');
                channel.subscribe(async (status) => {
                  if (status === 'SUBSCRIBED') {
                    await channel.send({
                      type: 'broadcast',
                      event: 'force-reload',
                      payload: { timestamp: Date.now() }
                    });
                    showToast('Perintah muat ulang berhasil dikirim ke semua perangkat!', 'success');
                    setTimeout(() => { supabase.removeChannel(channel); }, 1000);
                  }
                });
              } catch (e) {
                showToast('Gagal mengirim perintah', 'error');
              }
            }
          }}
          className="flex items-center gap-2 px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-lg text-xs font-bold transition-all shadow-sm active:scale-95"
          title="Paksa seluruh layar memuat ulang versi terbaru"
        >
          <Activity size={14} className="animate-pulse" />
          Paksa Refresh Global
        </button>
      </div>

      {activeTab === 'updates' ? (
        <AdminGlobalUpdates />
      ) : activeTab === 'feedback' ? (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-gray-100 dark:border-slate-800 shadow-sm dark:shadow-none overflow-hidden">
          <div className="p-6 border-b border-gray-100 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-800/50 flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <MessageSquare className="text-emerald-600" />
                Daftar Saran & Kritik Pengguna
              </h2>
              <p className="text-gray-500 dark:text-slate-400 text-sm mt-1">Kumpulan masukan dari seluruh desa yang menggunakan platform.</p>
            </div>
            <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold">
              {feedbacks.length} Total Feedback
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50/50 dark:bg-slate-800/50 text-gray-500 dark:text-slate-400 font-medium border-b border-gray-100 dark:border-slate-800">
                <tr>
                  <th className="px-6 py-4">Pengirim</th>
                  <th className="px-6 py-4">Kategori</th>
                  <th className="px-6 py-4">Pesan</th>
                  <th className="px-6 py-4">Tanggal</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {feedbacks.map(f => (
                  <tr key={f.id} className="hover:bg-gray-50/50 dark:bg-slate-800/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-bold text-gray-900 dark:text-white">{f.nama}</div>
                      <div className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider">{f.desa}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest ${
                        f.kategori === 'Bug' ? 'bg-rose-100 text-rose-700' : f.kategori === 'Saran' ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                        {f.kategori}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-600 dark:text-slate-400 max-w-xs truncate" title={f.pesan}>{f.pesan}</p>
                    </td>
                    <td className="px-6 py-4 text-gray-500 dark:text-slate-400 font-medium">
                      {f.tanggal}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        f.status === 'Baru' ? 'bg-emerald-100 text-emerald-700 animate-pulse' : f.status === 'Dibaca' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-slate-400'
                      }`}>
                        {f.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2">
                        {f.status !== 'Selesai' && (
                          <button 
                            onClick={() => updateFeedbackStatus(f.id, f.status === 'Baru' ? 'Dibaca' : 'Selesai')}
                            className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg"
                            title="Tandai Selesai"
                          >
                            <CheckCircle size={16} />
                          </button>
                        )}
                        <button 
                          onClick={() => deleteFeedback(f.id)}
                          className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg"
                          title="Hapus"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <>
          {/* Print Header */}
          <div className="hidden print:block mb-8 text-center border-b pb-4">
            <h1 className="text-2xl font-bold text-black uppercase tracking-wider">Data Kredensial Klien DiDesa</h1>
            <p className="text-sm text-gray-600 mt-1">Dicetak pada: {new Date().toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
          </div>

          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 print:hidden">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight flex items-center gap-2">
                <Server className="w-6 h-6 text-emerald-600" />
                Manajemen Klien & Kredensial Multi-Tenant
              </h2>
              <p className="text-gray-500 dark:text-slate-400 text-sm mt-1">Kelola desa klien, status berlangganan, serta kredensial akses pimpinan dan operator secara mandiri.</p>
            </div>
            <button 
              onClick={() => handlePrint()}
              className="print:hidden flex items-center gap-2 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-slate-300 px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors shadow-sm active:scale-95 shrink-0"
            >
              <Printer size={16} />
              Cetak Laporan
            </button>
            <button 
              onClick={() => {
                setFormData({
                  nama_desa: '',
                  kode_desa: '',
                  domain: '',
                  admin_email: '',
                  admin_password: '',
                  kades_email: '',
                  kades_password: ''
                });
                setIsModalOpen(true);
              }} 
              className="print:hidden flex items-center gap-2 bg-emerald-600 text-white px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-emerald-700 transition-colors shadow-md dark:shadow-none hover:shadow-lg active:scale-95 shrink-0"
            >
              <Plus size={16} />
              Tambah Desa Klien
            </button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 print:hidden">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-gray-100 dark:border-slate-800 shadow-sm dark:shadow-none flex items-center gap-4">
              <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600 shrink-0 animate-pulse">
                <Database size={24} />
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Total Klien Desa</p>
                <p className="text-2xl font-extrabold text-gray-900 dark:text-white"><NumberCounter end={tenants.length} /></p>
              </div>
            </div>
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-gray-100 dark:border-slate-800 shadow-sm dark:shadow-none flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center text-blue-600 shrink-0">
                <Activity size={24} />
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Klien Aktif</p>
                <p className="text-2xl font-extrabold text-gray-900 dark:text-white"><NumberCounter end={tenants.filter(t => t.status === 'active' || !t.status).length} /></p>
              </div>
            </div>
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-gray-100 dark:border-slate-800 shadow-sm dark:shadow-none flex items-center gap-4">
              <div className="w-12 h-12 bg-purple-50 rounded-full flex items-center justify-center text-purple-600 shrink-0">
                <ShieldCheck size={24} />
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Arsitektur Database</p>
                <p className="text-base font-extrabold text-gray-900 dark:text-white">RLS Isolated Multi-Tenant</p>
              </div>
            </div>
          </div>

          {/* Vercel Subdomain Info */}
          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-2xl border border-blue-100 dark:border-blue-800/50 flex items-start gap-3 print:hidden mt-4 mb-4">
            <Globe className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="space-y-1 text-sm">
              <p className="font-bold text-blue-900 dark:text-blue-300">Konfigurasi Akses Subdomain (Vercel / Hosting)</p>
              <p className="text-blue-700 dark:text-blue-400 leading-relaxed text-xs">
                Secara default, portal web klien dapat diakses via URL fallback <code className="bg-blue-100 dark:bg-blue-800/50 px-1.5 py-0.5 rounded font-mono text-[11px] text-blue-800 dark:text-blue-200">/?tenant=namadesa</code>. 
                Namun, jika Anda ingin menggunakan format subdomain seperti <code className="bg-blue-100 dark:bg-blue-800/50 px-1.5 py-0.5 rounded font-mono text-[11px] text-blue-800 dark:text-blue-200">namadesa.domainanda.com</code>, 
                Anda <strong>WAJIB</strong> menambahkan <strong>Wildcard Domain</strong> (<code className="font-mono">*.domainanda.com</code>) pada tab <i>Settings &gt; Domains</i> di dashboard Vercel. 
                Tanpa pengaturan tersebut di sisi server Vercel, peramban Anda akan mendapatkan halaman error <strong className="text-rose-600">404: DEPLOYMENT_NOT_FOUND</strong>.
              </p>
            </div>
          </div>

          {/* Tenant List */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-gray-100 dark:border-slate-800 shadow-sm dark:shadow-none overflow-hidden print:border-none print:shadow-none print:overflow-visible">
            <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex flex-col sm:flex-row justify-between items-center bg-gray-50/50 dark:bg-slate-800/50 gap-4 print:hidden">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input 
                  type="text" 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari desa, domain, atau kode unik..." 
                  className="w-full pl-9 pr-4 py-2 text-sm border border-gray-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white dark:bg-slate-900"
                />
              </div>
              
              <div className="flex items-center gap-2 text-xs font-bold text-gray-500 dark:text-slate-400">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span>Tabel Terenkripsi Otomatis</span>
              </div>
            </div>
            
            <div className="overflow-x-auto print:overflow-visible">
              <table id="tenants-table" className="w-full text-left text-sm print:text-xs">
                <thead className="bg-gray-50/50 dark:bg-slate-800/50 text-gray-500 dark:text-slate-400 font-bold border-b border-gray-100 dark:border-slate-800 uppercase text-[11px] tracking-wider print:bg-white print:text-black">
                  <tr>
                    <th className="px-6 py-4">Instansi Klien</th>
                    <th className="px-6 py-4">Domain / Subdomain</th>
                    <th className="px-6 py-4">Kredensial Super Admin</th>
                    <th className="px-6 py-4">Kredensial Admin</th>
                    <th className="px-6 py-4 text-center">Status</th>
                    <th className="px-6 py-4 text-right print:hidden">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {loading ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-gray-400 font-medium">
                        <div className="flex flex-col items-center justify-center gap-2">
                          <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
                          <span>Menghubungkan ke database RLS...</span>
                        </div>
                      </td>
                    </tr>
                  ) : filteredTenants.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-gray-400">
                        <div className="flex flex-col items-center justify-center gap-2">
                          <AlertTriangle className="text-amber-500 w-8 h-8" />
                          <span className="font-bold text-gray-700 dark:text-slate-300">Tidak ada hasil cocok</span>
                          <span className="text-xs text-gray-400">Coba ubah kata kunci pencarian Anda</span>
                        </div>
                      </td>
                    </tr>
                  ) : filteredTenants.map(tenant => {
                    const isVisible = showRowPasswords[tenant.id] || false;
                    const admEmail = tenant.admin_email || `admin@${tenant.domain || 'desa.id'}`;
                    const admPass = tenant.admin_password || 'admin123';
                    const kadEmail = tenant.kades_email || `kades@${tenant.domain || 'desa.id'}`;
                    const kadPass = tenant.kades_password || 'kades123';

                    return (
                      <tr key={tenant.id} className="hover:bg-gray-50/50 dark:bg-slate-800/50 transition-colors group">
                        {/* Tenant Info */}
                        <td className="px-6 py-4">
                          <div className="flex items-start gap-2.5">
                            <div className="w-9 h-9 bg-emerald-50 text-emerald-700 rounded-lg flex items-center justify-center shrink-0 border border-emerald-100 font-bold text-xs mt-0.5">
                              <Building2 size={16} />
                            </div>
                            <div>
                              <div className="font-extrabold text-gray-900 dark:text-white group-hover:text-emerald-700 transition-colors">
                                {tenant.nama_desa}
                              </div>
                              <div className="text-[11px] text-gray-400 font-semibold font-mono mt-0.5 uppercase tracking-wide flex items-center gap-1.5">
                                <span>ID: {tenant.id.split('-')[0]}</span>
                                <span className="text-gray-300">•</span>
                                <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-1.5 py-0.5 rounded text-[9px] font-bold">KODE: {tenant.kode_desa}</span>
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Domain / Subdomain */}
                        <td className="px-6 py-4">
                          <div className="space-y-2">
                            <div className="space-y-1">
                              <div className="flex items-center gap-1.5 text-xs font-bold text-gray-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800 px-2 py-1 rounded-md border border-slate-100 dark:border-slate-800 w-fit">
                                <Globe size={13} className="text-emerald-600 shrink-0" />
                                <span className="truncate">{tenant.domain || 'Belum diatur'}</span>
                              </div>
                              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1">
                                <Database size={9} /> Single DB / Supabase RLS
                              </span>
                            </div>
                            
                            <div className="hidden print-show mt-2">
                              <span className="text-[10px] text-gray-500 block mb-0.5">URL Akses Portal:</span>
                              <span className="font-mono text-xs font-bold text-emerald-700 break-all">https://{tenant.domain}.sistemdidesa.id/?tenant={tenant.domain}</span>
                            </div>

                            {tenant.domain && (
                              <a 
                                href={`/?tenant=${tenant.domain}&preview=true`} 
                                target="_blank" 
                                rel="noreferrer"
                                className="print-hide flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-2 py-1.5 rounded-lg border border-emerald-200 transition-colors w-fit group/link"
                              >
                                <ExternalLink size={13} className="group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-transform" />
                                Buka Portal Web
                              </a>
                            )}
                          </div>
                        </td>

                        {/* Super Admin Creds */}
                        <td className="px-6 py-4">
                          <div className="space-y-1.5 max-w-[200px]">
                            {/* Email */}
                            <div className="flex items-center justify-between gap-2 text-xs font-semibold text-gray-600 dark:text-slate-400 bg-gray-50 dark:bg-slate-800 hover:bg-gray-100 dark:hover:bg-slate-700 p-1 rounded-md border border-gray-100 dark:border-slate-800 transition-all">
                              <span className="truncate flex items-center gap-1">
                                <Mail size={11} className="text-amber-500 shrink-0" />
                                <span className="font-mono text-[11px]">{kadEmail}</span>
                              </span>
                              <button 
                                onClick={() => handleCopyToClipboard(kadEmail, `${tenant.id}-kademail`)}
                                className="print-hide p-0.5 text-gray-400 hover:text-emerald-600"
                                title="Salin Email"
                              >
                                {copiedId === `${tenant.id}-kademail` ? <Check size={12} className="text-emerald-600" /> : <Copy size={11} />}
                              </button>
                            </div>
                            {/* Password */}
                            <div className="flex items-center justify-between gap-2 text-xs font-semibold text-gray-600 dark:text-slate-400 bg-gray-50 dark:bg-slate-800 hover:bg-gray-100 dark:hover:bg-slate-700 p-1 rounded-md border border-gray-100 dark:border-slate-800 transition-all">
                              <span className="truncate flex items-center gap-1">
                                <Lock size={11} className="text-amber-500 shrink-0" />
                                <span className="font-mono text-[11px]">
                                  {isVisible ? kadPass : '••••••••'}
                                </span>
                              </span>
                              <button 
                                onClick={() => handleCopyToClipboard(kadPass, `${tenant.id}-kadpass`)}
                                className="print-hide p-0.5 text-gray-400 hover:text-emerald-600"
                                title="Salin Password"
                              >
                                {copiedId === `${tenant.id}-kadpass` ? <Check size={12} className="text-emerald-600" /> : <Copy size={11} />}
                              </button>
                            </div>
                          </div>
                        </td>

                        {/* Operator Creds */}
                        <td className="px-6 py-4">
                          <div className="space-y-1.5 max-w-[200px]">
                            {/* Email */}
                            <div className="flex items-center justify-between gap-2 text-xs font-semibold text-gray-600 dark:text-slate-400 bg-gray-50 dark:bg-slate-800 hover:bg-gray-100 dark:hover:bg-slate-700 p-1 rounded-md border border-gray-100 dark:border-slate-800 transition-all">
                              <span className="truncate flex items-center gap-1">
                                <Mail size={11} className="text-blue-500 shrink-0" />
                                <span className="font-mono text-[11px]">{admEmail}</span>
                              </span>
                              <button 
                                onClick={() => handleCopyToClipboard(admEmail, `${tenant.id}-admemail`)}
                                className="print-hide p-0.5 text-gray-400 hover:text-emerald-600"
                                title="Salin Email"
                              >
                                {copiedId === `${tenant.id}-admemail` ? <Check size={12} className="text-emerald-600" /> : <Copy size={11} />}
                              </button>
                            </div>
                            {/* Password */}
                            <div className="flex items-center justify-between gap-2 text-xs font-semibold text-gray-600 dark:text-slate-400 bg-gray-50 dark:bg-slate-800 hover:bg-gray-100 dark:hover:bg-slate-700 p-1 rounded-md border border-gray-100 dark:border-slate-800 transition-all">
                              <span className="truncate flex items-center gap-1">
                                <Lock size={11} className="text-blue-500 shrink-0" />
                                <span className="font-mono text-[11px]">
                                  {isVisible ? admPass : '••••••••'}
                                </span>
                              </span>
                              <button 
                                onClick={() => handleCopyToClipboard(admPass, `${tenant.id}-admpass`)}
                                className="print-hide p-0.5 text-gray-400 hover:text-emerald-600"
                                title="Salin Password"
                              >
                                {copiedId === `${tenant.id}-admpass` ? <Check size={12} className="text-emerald-600" /> : <Copy size={11} />}
                              </button>
                            </div>
                          </div>
                        </td>

                        {/* Status */}
                        <td className="px-6 py-4 text-center">
                          <div className="flex flex-col items-center justify-center gap-1.5">
                            {tenant.status !== 'inactive' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold tracking-wide uppercase">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                Aktif
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold tracking-wide uppercase">
                                Suspend
                              </span>
                            )}
                            {tenant.trial_end && (
                              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold tracking-wide ${
                                new Date(tenant.trial_end) > new Date() 
                                  ? 'bg-blue-100 text-blue-700' 
                                  : 'bg-red-100 text-red-600'
                              }`}>
                                {new Date(tenant.trial_end) > new Date() 
                                  ? `Trial sisa ${Math.ceil((new Date(tenant.trial_end).getTime() - Date.now()) / 86400000)}h`
                                  : 'Trial expired'
                                }
                              </span>
                            )}
                          </div>
                        </td>

                        {/* Action Buttons */}
                        <td className="px-6 py-4 text-right print:hidden">
                          <div className="flex justify-end items-center gap-2 relative">
                            {/* Lihat Sandi Button */}
                            <button
                              onClick={() => setShowRowPasswords(prev => ({ ...prev, [tenant.id]: !prev[tenant.id] }))}
                              className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 shadow-sm dark:shadow-none active:scale-95 border ${
                                isVisible 
                                  ? 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100' 
                                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                              }`}
                              title={isVisible ? "Sembunyikan Sandi" : "Lihat Sandi"}
                            >
                              {isVisible ? <EyeOff size={13} /> : <Eye size={13} />}
                              <span>{isVisible ? 'Tutup' : 'Sandi'}</span>
                            </button>

                            {/* Impersonate Login Button */}
                            <button 
                              onClick={() => handleLoginAs(tenant)}
                              className="px-2.5 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-bold hover:bg-emerald-700 transition-colors flex items-center gap-1 shadow-sm dark:shadow-none active:scale-95"
                              title="Login instan ke dasbor desa klien ini"
                            >
                              <ExternalLink size={13} />
                              <span>Login</span>
                            </button>

                            {/* Dropdown Toggle */}
                            <div className="relative">
                              <button 
                                onClick={() => setActiveDropdownId(activeDropdownId === tenant.id ? null : tenant.id)}
                                className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                              >
                                <MoreVertical size={14} />
                              </button>

                              {activeDropdownId === tenant.id && (
                                <div className="absolute right-full mr-2 top-1/2 -translate-y-1/2 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl shadow-xl z-50 py-1 px-1.5 flex items-center gap-1 animate-in fade-in slide-in-from-right-2 duration-150">
                                  <button
                                    onClick={() => handleOpenEditModal(tenant)}
                                    className="px-2.5 py-1.5 text-xs font-bold text-gray-700 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-800 hover:text-emerald-600 flex items-center gap-1.5 rounded-lg whitespace-nowrap"
                                  >
                                    <Edit2 size={13} className="text-gray-400" />
                                    <span>Edit</span>
                                  </button>
                                  <div className="w-[1px] h-4 bg-gray-100 dark:bg-slate-800"></div>
                                  <button
                                    onClick={() => handlePrint(tenant.nama_desa)}
                                    className="px-2.5 py-1.5 text-xs font-bold text-gray-700 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-800 hover:text-blue-600 flex items-center gap-1.5 rounded-lg whitespace-nowrap"
                                  >
                                    <Printer size={13} className="text-gray-400" />
                                    <span>Cetak Kredensial</span>
                                  </button>
                                  <div className="w-[1px] h-4 bg-gray-100 dark:bg-slate-800"></div>
                                  <button
                                    onClick={() => openResetModal(tenant)}
                                    className="px-2.5 py-1.5 text-xs font-bold text-gray-700 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-800 hover:text-rose-600 flex items-center gap-1.5 rounded-lg whitespace-nowrap"
                                  >
                                    <Key size={13} className="text-gray-400" />
                                    <span>Reset Sandi</span>
                                  </button>
                                  <div className="w-[1px] h-4 bg-gray-100 dark:bg-slate-800"></div>
                                  <button
                                    onClick={() => handleDeleteTenant(tenant)}
                                    className="px-2.5 py-1.5 text-xs font-bold text-rose-600 hover:bg-rose-50 flex items-center gap-1.5 rounded-lg whitespace-nowrap"
                                  >
                                    <Trash2 size={13} />
                                    <span>Hapus</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* CREATE MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200">
            <div className="px-6 py-4 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-800/50">
              <div>
                <h3 className="font-extrabold text-gray-900 dark:text-white text-lg flex items-center gap-2">
                  <Building2 className="text-emerald-600" />
                  Tambah Klien Desa Baru
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">Sistem akan secara otomatis menyarankan alamat email & password instan.</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600 transition-colors">
                <X size={20} />
              </button>
            </div>
            
            <form onSubmit={handleAddTenant} className="overflow-y-auto p-6 space-y-5 flex-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Village Details */}
                <div className="space-y-4">
                  <h4 className="text-xs font-black text-emerald-800 uppercase tracking-widest border-b pb-1">Detail Instansi Desa</h4>
                  <div>
                    <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 mb-1">Nama Desa</label>
                    <input 
                      required 
                      type="text" 
                      value={formData.nama_desa} 
                      onChange={e => setFormData({...formData, nama_desa: e.target.value})} 
                      className="w-full px-3.5 py-2 text-sm border border-gray-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" 
                      placeholder="Contoh: Desa Ketupat" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 mb-1">Kode Desa (Unik / Rujukan Pusat)</label>
                    <input 
                      required 
                      type="text" 
                      value={formData.kode_desa} 
                      onChange={e => setFormData({...formData, kode_desa: e.target.value})} 
                      className="w-full px-3.5 py-2 text-sm border border-gray-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" 
                      placeholder="Contoh: 1234WHI" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 mb-1">Domain / Subdomain Utama</label>
                    <input 
                      required 
                      type="text" 
                      value={formData.domain} 
                      onChange={e => setFormData({...formData, domain: e.target.value})} 
                      className="w-full px-3.5 py-2 text-sm border border-gray-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" 
                      placeholder="Contoh: Ketupat.sistemdidesa.id" 
                    />
                  </div>
                </div>

                {/* Initial Custom Credentials */}
                <div className="space-y-4 bg-gray-50 dark:bg-slate-800 p-4 rounded-2xl border border-gray-100 dark:border-slate-800">
                  <h4 className="text-xs font-black text-emerald-800 uppercase tracking-widest border-b pb-1">Kredensial Login Pertama</h4>
                  
                  {/* Super Admin */}
                  <div className="space-y-2">
                    <span className="text-[10px] bg-amber-100 text-amber-800 font-black px-2 py-0.5 rounded uppercase tracking-wider">Super Admin</span>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400">Email Super Admin</label>
                      <input 
                        type="email" 
                        value={formData.kades_email} 
                        onChange={e => setFormData({...formData, kades_email: e.target.value})}
                        className="w-full px-3 py-1.5 text-xs border border-gray-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900" 
                        placeholder="Masukkan email kades" 
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400">Password</label>
                      <input 
                        type="text" 
                        value={formData.kades_password} 
                        onChange={e => setFormData({...formData, kades_password: e.target.value})}
                        className="w-full px-3 py-1.5 text-xs border border-gray-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900" 
                        placeholder="kades123" 
                      />
                    </div>
                  </div>

                  {/* Admin */}
                  <div className="space-y-2 pt-2 border-t border-dashed">
                    <span className="text-[10px] bg-blue-100 text-blue-800 font-black px-2 py-0.5 rounded uppercase tracking-wider">Admin</span>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400">Email Operator</label>
                      <input 
                        type="email" 
                        value={formData.admin_email} 
                        onChange={e => setFormData({...formData, admin_email: e.target.value})}
                        className="w-full px-3 py-1.5 text-xs border border-gray-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900" 
                        placeholder="Masukkan email admin" 
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400">Password</label>
                      <input 
                        type="text" 
                        value={formData.admin_password} 
                        onChange={e => setFormData({...formData, admin_password: e.target.value})}
                        className="w-full px-3 py-1.5 text-xs border border-gray-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900" 
                        placeholder="admin123" 
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-100 dark:border-slate-800 flex gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2 bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-slate-300 font-bold text-xs rounded-xl hover:bg-gray-200 transition-colors">Batal</button>
                <button type="submit" disabled={isSubmitting} className="flex-1 px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl hover:bg-emerald-700 transition-colors disabled:opacity-70 disabled:cursor-not-allowed">
                  {isSubmitting ? 'Menyimpan...' : 'Simpan & Daftarkan Klien'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT CREDENTIALS / DETAILS MODAL */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200">
            <div className="px-6 py-4 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-800/50">
              <div>
                <h3 className="font-extrabold text-gray-900 dark:text-white text-lg flex items-center gap-2">
                  <Key className="text-emerald-600" />
                  Kelola Klien & Atur Kredensial Akses
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">Ubah rincian domain, setel ulang password admin utama, atau suspend akun klien desa.</p>
              </div>
              <button onClick={() => setIsEditModalOpen(false)} className="text-gray-400 hover:text-gray-600 transition-colors">
                <X size={20} />
              </button>
            </div>
            
            <form onSubmit={handleEditTenant} className="overflow-y-auto p-6 space-y-5 flex-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Client properties */}
                <div className="space-y-4">
                  <h4 className="text-xs font-black text-emerald-800 uppercase tracking-widest border-b pb-1">Detail Registrasi Instansi</h4>
                  <div>
                    <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 mb-1">Nama Instansi Desa</label>
                    <input 
                      required 
                      type="text" 
                      value={editFormData.nama_desa} 
                      onChange={e => setEditFormData({...editFormData, nama_desa: e.target.value})} 
                      className="w-full px-3.5 py-2 text-sm border border-gray-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 mb-1">Kode Desa (Unik)</label>
                    <input 
                      required 
                      type="text" 
                      value={editFormData.kode_desa} 
                      onChange={e => setEditFormData({...editFormData, kode_desa: e.target.value})} 
                      className="w-full px-3.5 py-2 text-sm border border-gray-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 mb-1">Domain / Subdomain</label>
                    <input 
                      required 
                      type="text" 
                      value={editFormData.domain} 
                      onChange={e => setEditFormData({...editFormData, domain: e.target.value})} 
                      className="w-full px-3.5 py-2 text-sm border border-gray-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 mb-1">Status Klien</label>
                    <select 
                      value={editFormData.status} 
                      onChange={e => setEditFormData({...editFormData, status: e.target.value})} 
                      className="w-full px-3.5 py-2 text-sm border border-gray-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    >
                      <option value="active">Aktif / Berlangganan</option>
                      <option value="inactive">Suspend / Non-aktif</option>
                    </select>
                  </div>
                </div>

                {/* Edit Credentials */}
                <div className="space-y-4 bg-emerald-50/30 p-4 rounded-2xl border border-emerald-100/40">
                  <h4 className="text-xs font-black text-emerald-800 uppercase tracking-widest border-b pb-1">Atur Kredensial Autentikasi</h4>
                  
                  {/* Super Admin */}
                  <div className="space-y-2">
                    <span className="text-[10px] bg-amber-100 text-amber-800 font-black px-2 py-0.5 rounded uppercase tracking-wider">Super Admin</span>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400">Email Utama</label>
                      <input 
                        type="email" 
                        value={editFormData.kades_email} 
                        onChange={e => setEditFormData({...editFormData, kades_email: e.target.value})}
                        className="w-full px-3 py-1.5 text-xs border border-gray-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900" 
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400">Kata Sandi Baru</label>
                      <input 
                        type="text" 
                        value={editFormData.kades_password} 
                        onChange={e => setEditFormData({...editFormData, kades_password: e.target.value})}
                        className="w-full px-3 py-1.5 text-xs border border-gray-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 font-mono" 
                      />
                    </div>
                  </div>

                  {/* Admin */}
                  <div className="space-y-2 pt-2 border-t border-dashed border-emerald-100">
                    <span className="text-[10px] bg-blue-100 text-blue-800 font-black px-2 py-0.5 rounded uppercase tracking-wider">Admin</span>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400">Email Utama</label>
                      <input 
                        type="email" 
                        value={editFormData.admin_email} 
                        onChange={e => setEditFormData({...editFormData, admin_email: e.target.value})}
                        className="w-full px-3 py-1.5 text-xs border border-gray-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900" 
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400">Kata Sandi Baru</label>
                      <input 
                        type="text" 
                        value={editFormData.admin_password} 
                        onChange={e => setEditFormData({...editFormData, admin_password: e.target.value})}
                        className="w-full px-3 py-1.5 text-xs border border-gray-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 font-mono" 
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-100 dark:border-slate-800 flex gap-3">
                <button type="button" onClick={() => setIsEditModalOpen(false)} className="flex-1 px-4 py-2 bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-slate-300 font-bold text-xs rounded-xl hover:bg-gray-200 transition-colors">Batal</button>
                <button type="submit" disabled={isSubmitting} className="flex-1 px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl hover:bg-emerald-700 transition-colors">
                  {isSubmitting ? 'Menyimpan...' : 'Simpan Perubahan Kredensial'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RESET PASSWORD MODAL */}
      {resetTenant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-6 py-4 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-800/50">
              <div>
                <h3 className="font-extrabold text-gray-900 dark:text-white text-lg flex items-center gap-2">
                  <Key className="text-rose-600" />
                  Reset Kata Sandi
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">{resetTenant.nama_desa} &mdash; setel ulang kata sandi akses portal desa</p>
              </div>
              <button onClick={() => setResetTenant(null)} className="text-gray-400 hover:text-gray-600 transition-colors">
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleResetPassword} className="p-6 space-y-5">
              <div>
                <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 mb-1">Akun yang Direset</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setResetAccount('admin')}
                    className={`px-3 py-2.5 rounded-xl border text-left transition-all ${
                      resetAccount === 'admin'
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700'
                        : 'border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-gray-500'
                    }`}
                  >
                    <span className="block text-[10px] font-black uppercase tracking-wider mb-0.5">Admin</span>
                    <span className="block text-[11px] font-mono truncate">{resetTenant.admin_email || `admin@${resetTenant.domain || 'desa.id'}`}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setResetAccount('kades')}
                    className={`px-3 py-2.5 rounded-xl border text-left transition-all ${
                      resetAccount === 'kades'
                        ? 'border-amber-500 bg-amber-50 dark:bg-amber-900/20 text-amber-700'
                        : 'border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-gray-500'
                    }`}
                  >
                    <span className="block text-[10px] font-black uppercase tracking-wider mb-0.5">Super Admin</span>
                    <span className="block text-[11px] font-mono truncate">{resetTenant.kades_email || `kades@${resetTenant.domain || 'desa.id'}`}</span>
                  </button>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs font-bold text-gray-500 dark:text-slate-400">Kata Sandi Baru</label>
                  <button
                    type="button"
                    onClick={() => { setResetPassword(generateSecurePassword()); setResetCopied(false); }}
                    className="text-[10px] font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
                  >
                    <RefreshCw size={11} />
                    Acak Ulang
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <input
                      required
                      type={showResetPassword ? 'text' : 'password'}
                      value={resetPassword}
                      onChange={e => setResetPassword(e.target.value)}
                      className="w-full px-3.5 pr-10 py-2.5 text-sm font-mono border border-gray-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowResetPassword(!showResetPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      title={showResetPassword ? 'Sembunyikan' : 'Tampilkan'}
                    >
                      {showResetPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyResetPassword}
                    className="px-3 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 text-gray-500 hover:text-emerald-600 hover:border-emerald-300 transition-colors"
                    title="Salin kata sandi"
                  >
                    {resetCopied ? <Check size={15} className="text-emerald-600" /> : <Copy size={15} />}
                  </button>
                </div>
                <p className="text-[10px] text-gray-400 mt-1.5">
                  Kata sandi otomatis dibuat dengan kombinasi huruf, angka, dan simbol. Bagikan kata sandi baru ini secara aman kepada petugas desa.
                </p>
              </div>

              <div className="flex items-start gap-2 bg-amber-50 dark:bg-amber-900/20 border border-amber-100 dark:border-amber-800/50 rounded-xl p-3">
                <AlertTriangle size={14} className="text-amber-600 mt-0.5 flex-shrink-0" />
                <p className="text-[11px] text-amber-700 dark:text-amber-400 leading-relaxed">
                  Mereset kata sandi akan segera menonaktifkan kata sandi lama. Pastikan Anda mengirimkan kata sandi baru kepada {resetAccount === 'admin' ? 'Admin' : 'Super Admin'} {resetTenant.nama_desa} melalui saluran yang aman.
                </p>
              </div>

              <div className="pt-2 flex gap-3">
                <button type="button" onClick={() => setResetTenant(null)} className="flex-1 px-4 py-2 bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-slate-300 font-bold text-xs rounded-xl hover:bg-gray-200 transition-colors">Batal</button>
                <button type="submit" disabled={isSubmitting} className="flex-1 px-4 py-2 bg-rose-600 text-white font-bold text-xs rounded-xl hover:bg-rose-700 transition-colors disabled:opacity-70 disabled:cursor-not-allowed">
                  {isSubmitting ? 'Mereset...' : 'Konfirmasi Reset'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
