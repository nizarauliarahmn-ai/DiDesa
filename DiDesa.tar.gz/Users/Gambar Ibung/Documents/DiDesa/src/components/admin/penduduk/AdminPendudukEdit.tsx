import React, { useState, useRef, useEffect, useMemo } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { 
  Info, MapPin, Users, User, 
  Check, Save, GraduationCap, Heart, Trash2, 
  ChevronDown, Search, PenLine, UserCheck, ListFilter,
  FileText, HandHeart, Phone, BookOpen, X, ShieldCheck, Eye
} from 'lucide-react';
import { showToast } from '../../../utils/toast';
import { capitalizeWords, parseAddressString } from '../../../utils/textUtils';
import { supabase } from '../../../utils/supabase';
import { resolveCurrentTenant } from '../../../utils/tenantResolver';
import { fetchResidentLettersAsync, getLetterFullData } from '../../../utils/letterHistory';
import { getLetterClassifications } from '../../../utils/letterClassifications';
import { STATUS_KEBERADAAN_OPTIONS, normalizeStatusKeberadaan } from '../../../utils/statusKeberadaan';

interface AdminPendudukEditProps {
  onBack: () => void;
  data: any;
  onSave?: (savedData: any) => void;
}

const getFullLetterName = (jenis: string): string => {
  const classifications = getLetterClassifications();
  const clean = (jenis || '').trim();
  const cleanUpper = clean.toUpperCase();
  const found = classifications.find(c => c.klasifikasi.toUpperCase() === cleanUpper || c.jenis.toUpperCase() === cleanUpper);
  if (found) {
    return `${found.klasifikasi} - ${found.jenis}`;
  }
  return clean;
};

const PEKERJAAN_OPTIONS = [
  'Belum / Tidak Bekerja',
  'Mengurus Rumah Tangga',
  'Pelajar / Mahasiswa',
  'Pensiunan',
  'Pegawai Negeri Sipil (PNS)',
  'Tentara Nasional Indonesia (TNI)',
  'Kepolisian RI (POLRI)',
  'Karyawan Swasta',
  'Karyawan BUMN / BUMD',
  'Wiraswasta',
  'Buruh Harian Lepas',
  'Petani / Pekebun',
  'Nelayan / Perikanan',
  'Lainnya'
];

const PENDIDIKAN_OPTIONS = [
  'Tidak/Belum Sekolah',
  'SD / Sederajat',
  'SMP / Sederajat',
  'SMA / Sederajat',
  'Diploma (D1/D2/D3)',
  'Sarjana (S1)',
  'Pascasarjana (S2/S3)'
];

// Searchable dropdown to pick a family member (parent) from the same KK
function KkParentCombobox({
  label,
  members,
  value,
  onChange,
  onToggleManual,
  isManual,
  genderFilter,
  placeholder
}: {
  label: string;
  members: any[];
  value: string;
  onChange: (name: string) => void;
  onToggleManual: (manual: boolean) => void;
  isManual: boolean;
  genderFilter: 'Laki-laki' | 'Perempuan';
  placeholder: string;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const base = members.filter((m: any) => {
      const g = String(m.gender || '').toLowerCase();
      const want = genderFilter === 'Laki-laki' ? ['laki-laki', 'l', 'laki'] : ['perempuan', 'p', 'wanita'];
      return want.includes(g);
    });
    if (!q) return base;
    return base.filter((m: any) =>
      String(m.name || '').toLowerCase().includes(q) ||
      String(m.nik || '').includes(q)
    );
  }, [members, query, genderFilter]);

  const selectedMember = members.find((m: any) => String(m.name || '').toLowerCase() === String(value || '').toLowerCase());

  return (
    <div className="space-y-1" ref={boxRef}>
      <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">
        {label} <span className="text-gray-400 font-normal text-[10px] lowercase tracking-normal ml-1.5">(Opsional)</span>
      </label>

      {!isManual ? (
        <div className="relative">
          <button
            type="button"
            onClick={() => setOpen(o => !o)}
            className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-left text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 flex items-center justify-between gap-2"
          >
            <span className={`truncate ${value ? '' : 'text-gray-400'}`}>
              {selectedMember
                ? `${selectedMember.name}${selectedMember.familyRelation ? ` (${selectedMember.familyRelation})` : ''}`
                : value || placeholder}
            </span>
            <ChevronDown className={`w-4 h-4 text-gray-400 flex-none transition-transform ${open ? 'rotate-180' : ''}`} />
          </button>

          {open && (
            <div className="absolute z-30 left-0 right-0 mt-1 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl shadow-xl overflow-hidden">
              <div className="flex items-center gap-2 px-3 py-2 border-b border-gray-100 dark:border-slate-800">
                <Search className="w-4 h-4 text-gray-400 flex-none" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Cari nama / NIK..."
                  className="w-full text-sm outline-none bg-transparent"
                />
              </div>
              <div className="max-h-52 overflow-y-auto">
                {filtered.length === 0 ? (
                  <div className="px-4 py-6 text-center">
                    <p className="text-xs text-gray-500">Tidak ada anggota KK berjenis kelamin {genderFilter === 'Laki-laki' ? 'laki-laki' : 'perempuan'} ditemukan.</p>
                    <button
                      type="button"
                      onClick={() => { setOpen(false); onToggleManual(true); }}
                      className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 hover:text-emerald-800"
                    >
                      <PenLine className="w-3.5 h-3.5" /> Ketik manual
                    </button>
                  </div>
                ) : (
                  filtered.map((m: any) => (
                    <button
                      key={m.nik || m.id}
                      type="button"
                      onClick={() => { onChange(m.name); setOpen(false); setQuery(''); }}
                      className="w-full text-left px-4 py-2.5 hover:bg-emerald-50 dark:hover:bg-slate-800 flex items-start justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-gray-900 dark:text-white truncate uppercase">{m.name}</p>
                        <p className="text-[10px] text-gray-500">{m.nik || '-'}</p>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 dark:bg-emerald-900/30 px-1.5 py-0.5 rounded flex-none mt-0.5">
                        {m.familyRelation || 'Anggota KK'}
                      </span>
                    </button>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      ) : (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value.toUpperCase())}
          className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900"
          placeholder="Masukkan nama secara manual..."
        />
      )}

      <div className="flex items-center justify-between">
        <p className="text-[10px] text-gray-400">
          {!isManual
            ? 'Diambil dari anggota KK yang sama'
            : 'Nama di luar KK (mis. sudah meninggal / di luar desa)'}
        </p>
        <button
          type="button"
          onClick={() => { onToggleManual(!isManual); setOpen(false); }}
          className="text-[10px] font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
        >
          {isManual ? <UserCheck className="w-3 h-3" /> : <PenLine className="w-3 h-3" />}
          {isManual ? 'Pilih dari KK' : 'Ketik Manual'}
        </button>
      </div>
    </div>
  );
}

export default function AdminPendudukEdit({ onBack, data, onSave }: AdminPendudukEditProps) {
  const isAdd = !data || !data.nik;

  const getCleanedVillageName = () => {
    const stored = localStorage.getItem('village_name') || 'Desa Sukamaju';
    if (stored.startsWith('Desa ')) {
      return stored.slice(5).trim();
    }
    if (stored.startsWith('Kelurahan ')) {
      return stored.slice(10).trim();
    }
    return stored.trim();
  };

  // Form State
  const [name, setName] = useState((data?.name || '').toUpperCase());
  const [nik, setNik] = useState(data?.nik || '');
  const [noKk, setNoKk] = useState(data?.noKk || '320412008890001');
  const [gender, setGender] = useState(data?.gender || 'Laki-laki');
  const [birthPlace, setBirthPlace] = useState(capitalizeWords(data?.birthPlace || ''));
  const [birthDate, setBirthDate] = useState(data?.birthDate || '1995-01-01');
  const [bloodType, setBloodType] = useState(data?.bloodType || 'O');
  const [religion, setReligion] = useState(data?.religion || 'Islam');
  const [job, setJob] = useState(data?.job || 'Wiraswasta');
  const [fatherName, setFatherName] = useState((data?.fatherName || '').toUpperCase());
  const [motherName, setMotherName] = useState((data?.motherName || '').toUpperCase());

  // Kontak & Identitas Lain
  const [noWhatsapp, setNoWhatsapp] = useState(data?.noWhatsapp || '');

  // Pendidikan & Sipil

  // Kesejahteraan & Dokumen
  const [statusDtks, setStatusDtks] = useState(data?.statusDtks || 'Tidak Terdaftar DTKS');
  const [disabilitas, setDisabilitas] = useState(data?.disabilitas || 'Tidak Ada');

  // Same-KK family members used for parent dropdowns
  const [kkMembers, setKkMembers] = useState<any[]>([]);
  const [kkLoading, setKkLoading] = useState(false);
  const [fatherManual, setFatherManual] = useState(false);
  const [motherManual, setMotherManual] = useState(false);
  
  const [address, setAddress] = useState(capitalizeWords(data?.address || ''));
  const [rt, setRt] = useState(data?.rt || '01');
  const [rw, setRw] = useState(data?.rw || '01');
  const [desa, setDesa] = useState(() => capitalizeWords(data?.desa || getCleanedVillageName()));
  const [domicileStatus, setDomicileStatus] = useState(data?.domicileStatus || 'Sesuai KTP');
  
  const [familyRelation, setFamilyRelation] = useState(data?.familyRelation || 'Kepala Keluarga');
  const [education, setEducation] = useState(data?.education || 'Sarjana (S1)');
  const [residentStatus, setResidentStatus] = useState(normalizeStatusKeberadaan(data?.status || data?.status_keberadaan || 'TETAP'));
  const [maritalStatus, setMaritalStatus] = useState(data?.maritalStatus || 'Belum Kawin');
  const [activeAids, setActiveAids] = useState<string[]>(data?.activeAids || []);

  // Photo state
  const [photoPreview, setPhotoPreview] = useState<string | null>(data?.photo || null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Errors state
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  // Active tab state
  const [activeTab, setActiveTab] = useState(0);

  // Letter history state (Tab 4)
  const [residentLetters, setResidentLetters] = useState<any[]>([]);
  const [viewLetter, setViewLetter] = useState<any>(null);

  useEffect(() => {
    if (data?.nik) {
      fetchResidentLettersAsync(data.nik, data.name || "").then(setResidentLetters);
    } else {
      setResidentLetters([]);
    }
  }, [data]);

  // Load family members sharing the same KK (for parent dropdowns)
  useEffect(() => {
    let cancelled = false;
    const loadKkMembers = async () => {
      const kk = (noKk || '').trim();
      if (!kk) { setKkMembers([]); return; }
      setKkLoading(true);
      try {
        const tenantId = await resolveCurrentTenant();
        if (!tenantId) return;
        const { data: rows, error } = await supabase
          .from('residents')
          .select('*')
          .eq('tenant_id', tenantId)
          .eq('no_kk', kk);
        if (error) throw error;
        if (cancelled) return;
        const formatted = (rows || []).map((r: any) => ({
          ...r,
          name: r.name,
          nik: r.nik,
          gender: r.gender,
          noKk: r.no_kk,
          familyRelation: r.family_relation,
        }));
        setKkMembers(formatted);
      } catch (e) {
        console.error('Gagal memuat anggota KK:', e);
      } finally {
        if (!cancelled) setKkLoading(false);
      }
    };
    loadKkMembers();
    return () => { cancelled = true; };
  }, [noKk]);

  // If stored parent is not found among KK members, fall back to manual typing
  useEffect(() => {
    const exists = (name: string, gender: string) => {
      if (!name) return false;
      return kkMembers.some((m: any) =>
        String(m.gender || '').toLowerCase() === (gender === 'Laki-laki' ? 'laki-laki' : 'perempuan') &&
        String(m.name || '').toLowerCase() === String(name).toLowerCase()
      );
    };
    if (kkMembers.length > 0) {
      if (fatherName && !exists(fatherName, 'Laki-laki')) setFatherManual(true);
      if (motherName && !exists(motherName, 'Perempuan')) setMotherManual(true);
    }
  }, [kkMembers]);

  // Auto populate RW: rt 01/02 -> rw 01; rt 03/04 -> rw 02
  const handleRtChange = (val: string) => {
    setRt(val);
    if (errors.rt) setErrors(prev => ({ ...prev, rt: '' }));
    
    if (val === '01' || val === '02') {
      setRw('01');
    } else if (val === '03' || val === '04') {
      setRw('02');
    }
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 2 * 1024 * 1024) {
        showToast('File terlalu besar! Maksimal 2MB.', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!name.trim()) newErrors.name = 'Nama lengkap wajib diisi';
    
    // NIK validation (exactly 16 digits of numbers)
    if (!nik.trim()) {
      newErrors.nik = 'NIK wajib diisi';
    } else if (nik.length !== 16) {
      newErrors.nik = 'NIK harus tepat 16 digit';
    } else if (!/^\d+$/.test(nik)) {
      newErrors.nik = 'NIK hanya boleh berupa angka';
    }

    // Nomor KK validation (exactly 16 digits of numbers)
    if (!noKk.trim()) {
      newErrors.noKk = 'Nomor KK wajib diisi';
    } else if (noKk.length !== 16) {
      newErrors.noKk = 'Nomor KK harus tepat 16 digit';
    } else if (!/^\d+$/.test(noKk)) {
      newErrors.noKk = 'Nomor KK hanya boleh berupa angka';
    }

    if (!birthPlace.trim()) newErrors.birthPlace = 'Tempat lahir wajib diisi';
    if (!birthDate) newErrors.birthDate = 'Tanggal lahir wajib diisi';
    if (!address.trim()) newErrors.address = 'Alamat lengkap wajib diisi';
    if (!rt.trim()) newErrors.rt = 'RT wajib diisi';
    if (!desa.trim()) newErrors.desa = 'Desa/Kelurahan wajib diisi';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (!validateForm()) {
      showToast('Mohon lengkapi semua data formulir dengan benar.', 'error');
      return;
    }
    setShowConfirmModal(true);
  };

  // Auto-set "Hubungan Keluarga" to "Anak" whenever a father/mother is chosen,
  // whether from the same-KK dropdown or typed manually.
  const handleFatherNameChange = (val: string) => {
    setFatherName(val);
    if (val && val.trim()) setFamilyRelation('Anak');
  };

  const handleMotherNameChange = (val: string) => {
    setMotherName(val);
    if (val && val.trim()) setFamilyRelation('Anak');
  };

  // If the selected mother is a same-KK member whose husband is "Kepala Keluarga",
  // keep the mother's relation in this KK consistent as "Istri".
  const syncMotherAsWifeIfNeeded = async () => {
    try {
      const fatherMember = kkMembers.find((m: any) =>
        String(m.name || '').trim().toLowerCase() === String(fatherName || '').trim().toLowerCase()
      );
      const motherMember = kkMembers.find((m: any) =>
        String(m.name || '').trim().toLowerCase() === String(motherName || '').trim().toLowerCase()
      );
      if (!fatherMember || !motherMember) return;
      const isFatherKepala = String(fatherMember.familyRelation || '').toLowerCase().includes('kepala');
      if (!isFatherKepala) return;
      if (String(motherMember.nik || '') === String(nik || '')) return;
      const currentMotherRel = String(motherMember.familyRelation || '').toLowerCase();
      if (currentMotherRel === 'istri') return;
      const tenantId = await resolveCurrentTenant();
      if (!tenantId) return;
      await supabase.from('residents')
        .update({ family_relation: 'Istri' })
        .eq('nik', motherMember.nik)
        .eq('tenant_id', tenantId);
    } catch (e) {
      console.warn('Gagal sinkronisasi status Ibu menjadi Istri:', e);
    }
  };

  const executeSave = async () => {

    // Determine age from birthDate
    const birthYear = new Date(birthDate).getFullYear();
    const currentYear = new Date().getFullYear();
    const age = isNaN(birthYear) ? 30 : Math.max(0, currentYear - birthYear);

    // Compute status colors
    const genderColor = gender === 'Perempuan' ? 'pink' : 'blue';
    const statusColor = residentStatus === 'Aktif' || residentStatus === 'TETAP' ? 'emerald' : 'gray';

    const fullName = (name || '').trim();

    const savedResident = {
      ...data,
      nik,
      noKk,
      name: fullName.toUpperCase(),
      age,
      gender,
      genderColor,
      rtRw: `${rt.padStart(2, '0')} / ${rw.padStart(2, '0')}`,
      status: residentStatus,
      statusKeberadaan: residentStatus,
      maritalStatus,
      statusColor,
      initials: fullName.split(' ').map((n: string) => n[0]).slice(0, 2).join('').toUpperCase(),
      birthPlace,
      birthDate,
      bloodType,
      religion,
      job,
      pekerjaan: job,
      jenis_pekerjaan: job,
      pekerjaan_nama: job,
      address,
      rt,
      rw,
      desa,
      domicileStatus,
      familyRelation,
      education,
      statusDtks,
      disabilitas,
      noWhatsapp,
      fatherName: (fatherName || '').trim().toUpperCase(),
      motherName: (motherName || '').trim().toUpperCase(),
      activeAids,
      photo: photoPreview
    };

    const authUser = JSON.parse(localStorage.getItem('didesa_auth_user') || '{}');
    
    if (authUser.role === 'admin') {
      try {
        const res = await fetch(`/api/residents/${data.nik}/request-approval`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            actionType: 'edit',
            originalStatus: data.status || 'Aktif',
            details: savedResident
          })
        });
        if (res.ok) {
          showToast(`Perubahan data ${name} berhasil diajukan ke Super Admin!`, "success");
          onBack();
        } else {
          throw new Error("Gagal mengajukan permohonan.");
        }
      } catch (e: any) {
        showToast(e.message || "Gagal mengajukan permohonan.", "error");
      }
    } else {
      if (onSave) {
        await syncMotherAsWifeIfNeeded();
        onSave(savedResident);
      } else {
        showToast('Data berhasil disimpan!', 'success');
        onBack();
      }
    }
  };

  // Parse bansos history from activeAids (Tab 5)
  const bansosHistory = useMemo(() => {
    const entries: { program: string; periode: string; status: string; nominal: string }[] = [];
    const aids = Array.isArray(activeAids) ? activeAids : [];
    aids.forEach((aid: string) => {
      const isStopped = aid.startsWith('STOPPED:');
      const raw = isStopped ? aid.replace(/^STOPPED:\s*/, '') : aid;
      const match = raw.match(/^(.*?)\s*\((\d{4})\)/);
      const program = match ? match[1].trim() : raw.split('|')[0].trim();
      const periode = match ? match[2] : '-';
      const nominal = program.toLowerCase().includes('blt')
        ? 'Rp 300.000'
        : program.toLowerCase().includes('pkh')
          ? 'Rp 600.000'
          : program.toLowerCase().includes('non-tunai')
            ? 'Rp 200.000'
            : '-';
      entries.push({ program, periode, status: isStopped ? 'Dihentikan' : 'Aktif', nominal });
    });
    return entries;
  }, [activeAids]);

  const TABS = [
    { id: 0, label: 'Identitas & Kontak', icon: User },
    { id: 1, label: 'Keluarga & Pendidikan', icon: GraduationCap },
    { id: 2, label: 'Kesejahteraan & Dokumen', icon: Heart },
    { id: 3, label: 'Riwayat Dokumen', icon: FileText },
    { id: 4, label: 'Riwayat Bantuan Sosial', icon: HandHeart },
  ];

  return (
    <div className="pt-6 pb-12 animate-in fade-in duration-300">
      {/* Breadcrumb & Sticky Header */}
      <div className="sticky top-16 z-40 bg-slate-50/60 dark:bg-slate-900/80 backdrop-blur-xl pb-4 -mx-4 -mt-4 px-4 pt-4 md:-mx-6 md:-mt-6 md:px-6 md:pt-6 lg:-mx-8 lg:-mt-8 lg:px-8 lg:pt-8 border-b border-slate-200/50 dark:border-slate-700/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-slate-400 mb-2 font-medium">
            <button onClick={onBack} className="hover:text-emerald-700 transition-colors">Daftar Penduduk</button>
            <span className="text-gray-400">/</span>
            <span className="text-emerald-700 font-bold">
              {isAdd ? 'Formulir Pendaftaran' : 'Edit Data'}
            </span>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight">
            {isAdd ? 'Tambah Penduduk Baru' : 'Edit Data Penduduk'}
          </h2>
          <p className="text-sm text-gray-500 dark:text-slate-400">
            {isAdd 
              ? 'Silakan lengkapi seluruh formulir di bawah ini untuk mendaftarkan warga baru.' 
              : `Mengubah data informasi kependudukan warga dengan NIK ${data.nik}.`}
          </p>
        </div>
        
        <div className="flex gap-3 w-full sm:w-auto">
          <button 
            onClick={onBack}
            className="flex-1 sm:flex-none px-6 py-2.5 border border-gray-300 dark:border-slate-600 text-gray-700 dark:text-slate-300 font-bold text-sm rounded-xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-all active:scale-95 bg-white dark:bg-slate-900"
          >
            Batal
          </button>
          <button 
            onClick={handleSave}
            className="flex-1 sm:flex-none px-6 py-2.5 bg-emerald-700 text-white font-bold text-sm rounded-xl shadow-sm dark:shadow-none hover:bg-emerald-800 transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            {isAdd ? 'Simpan Data' : 'Simpan Perubahan'}
          </button>
        </div>
      </div>

      {/* 5-Tab Navigation */}
      <div className="sticky top-[132px] z-30 bg-slate-50/90 dark:bg-slate-900/90 backdrop-blur-xl pb-2 -mx-4 px-4 md:-mx-6 md:px-6 lg:-mx-8 lg:px-8 pt-4 border-b border-slate-200/50 dark:border-slate-700/50 overflow-x-auto">
        <div className="flex gap-1.5 min-w-max">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-700 text-white shadow-sm'
                    : 'text-gray-600 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-slate-800 hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-6">
        {/* Left Columns: Tab Content */}
        <div className="lg:col-span-8 space-y-8">

          {/* ===== TAB 1: Identitas & Kontak ===== */}
          {activeTab === 0 && (
            <>
              {/* Biodata & Kontak */}
              <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800">
                <div className="flex items-center gap-3 mb-6 border-b border-gray-100 dark:border-slate-800 pb-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                    <User className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white">Identitas & Kontak</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="md:col-span-2 space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">
                      Nama Lengkap Sesuai KTP <span className="text-red-500 font-bold ml-1">*</span>
                    </label>
                    <input 
                      type="text"
                      value={name}
                      onChange={(e) => {
                        setName(e.target.value.toUpperCase());
                        if (errors.name) setErrors(prev => ({ ...prev, name: '' }));
                      }}
                      className={`w-full h-11 px-4 border rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all ${
                        errors.name ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-200 dark:border-slate-700'
                      }`}
                      placeholder="Masukkan nama lengkap..."
                    />
                    {errors.name && <p className="text-xs text-red-500 font-semibold">{errors.name}</p>}
                  </div>

                  {/* NIK Field */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">
                      NIK (Nomor Induk Kependudukan) <span className="text-red-500 font-bold ml-1">*</span>
                    </label>
                    <input 
                      type="text"
                      maxLength={16}
                      value={nik}
                      onChange={(e) => {
                        const val = e.target.value.replace(/\D/g, '');
                        setNik(val);
                        if (errors.nik) setErrors(prev => ({ ...prev, nik: '' }));
                      }}
                      className={`w-full h-11 px-4 border rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all font-mono ${
                        errors.nik ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-200 dark:border-slate-700'
                      }`}
                      placeholder="Masukkan 16 digit NIK..."
                    />
                    {errors.nik && <p className="text-xs text-red-500 font-semibold">{errors.nik}</p>}
                  </div>

                  {/* Nomor KK Field */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">
                      No. KK (Kartu Keluarga) <span className="text-red-500 font-bold ml-1">*</span>
                    </label>
                    <input 
                      type="text"
                      maxLength={16}
                      value={noKk}
                      onChange={(e) => {
                        const val = e.target.value.replace(/\D/g, '');
                        setNoKk(val);
                        if (errors.noKk) setErrors(prev => ({ ...prev, noKk: '' }));
                      }}
                      className={`w-full h-11 px-4 border rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all font-mono ${
                        errors.noKk ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-200 dark:border-slate-700'
                      }`}
                      placeholder="Masukkan 16 digit No. KK..."
                    />
                    {errors.noKk && <p className="text-xs text-red-500 font-semibold">{errors.noKk}</p>}
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">
                      No. WhatsApp
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input 
                        type="text"
                        value={noWhatsapp}
                        onChange={(e) => setNoWhatsapp(e.target.value.replace(/[^\d]/g, ''))}
                        className="w-full h-11 pl-10 pr-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 font-mono"
                        placeholder="Contoh: 081234567890"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">
                      Jenis Kelamin <span className="text-red-500 font-bold ml-1">*</span>
                    </label>
                    <select 
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 cursor-pointer"
                    >
                      <option value="Laki-laki">Laki-laki</option>
                      <option value="Perempuan">Perempuan</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">
                      Tempat Lahir <span className="text-red-500 font-bold ml-1">*</span>
                    </label>
                    <input 
                      type="text"
                      value={birthPlace}
                      onChange={(e) => {
                        setBirthPlace(capitalizeWords(e.target.value));
                        if (errors.birthPlace) setErrors(prev => ({ ...prev, birthPlace: '' }));
                      }}
                      className={`w-full h-11 px-4 border rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all ${
                        errors.birthPlace ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-200 dark:border-slate-700'
                      }`}
                      placeholder="Contoh: Jakarta"
                    />
                    {errors.birthPlace && <p className="text-xs text-red-500 font-semibold">{errors.birthPlace}</p>}
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">
                      Tanggal Lahir <span className="text-red-500 font-bold ml-1">*</span>
                    </label>
                    <input 
                      type="date"
                      value={birthDate}
                      onChange={(e) => {
                        setBirthDate(e.target.value);
                        if (errors.birthDate) setErrors(prev => ({ ...prev, birthDate: '' }));
                      }}
                      className={`w-full h-11 px-4 border rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 ${
                        errors.birthDate ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-200 dark:border-slate-700'
                      }`}
                    />
                    {errors.birthDate && <p className="text-xs text-red-500 font-semibold">{errors.birthDate}</p>}
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">Agama</label>
                    <select 
                      value={religion}
                      onChange={(e) => setReligion(e.target.value)}
                      className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 cursor-pointer"
                    >
                      <option value="Islam">Islam</option>
                      <option value="Kristen Protestan">Kristen Protestan</option>
                      <option value="Kristen Katolik">Kristen Katolik</option>
                      <option value="Hindu">Hindu</option>
                      <option value="Budha">Budha</option>
                      <option value="Khonghucu">Khonghucu</option>
                    </select>
                  </div>
                </div>
              </section>

              {/* Alamat & Domisili */}
              <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800">
                <div className="flex items-center gap-3 mb-6 border-b border-gray-100 dark:border-slate-800 pb-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white">Alamat & Domisili</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-6 gap-5">
                  <div className="md:col-span-6 space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">
                        Alamat Lengkap <span className="text-red-500 font-bold ml-1">*</span>
                      </label>
                      <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-900/30 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">✨ Smart Autofill RT/RW Aktif</span>
                    </div>
                    <textarea 
                      rows={2}
                      value={address}
                      onChange={(e) => {
                        const rawVal = e.target.value;
                        if (/\b(RT|RW)\b/i.test(rawVal)) {
                          const parsed = parseAddressString(rawVal, rt, rw);
                          setAddress(parsed.address);
                          if (parsed.rt) handleRtChange(parsed.rt);
                          if (parsed.rw) setRw(parsed.rw);
                          showToast(`Otomatis mengekstrak RT: ${parsed.rt}, RW: ${parsed.rw}`, 'info');
                        } else {
                          setAddress(capitalizeWords(rawVal));
                        }
                        if (errors.address) setErrors(prev => ({ ...prev, address: '' }));
                      }}
                      className={`w-full px-4 py-3 border rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all resize-none ${
                        errors.address ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-200 dark:border-slate-700'
                      }`}
                      placeholder="Nama jalan, nomor rumah... (Jika ditempel dengan RT/RW, sistem otomatis memisahkan RT & RW!)"
                    ></textarea>
                    {errors.address && <p className="text-xs text-red-500 font-semibold">{errors.address}</p>}
                  </div>

                  {/* RT Dropdown select list */}
                  <div className="md:col-span-2 space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">
                      RT <span className="text-red-500 font-bold ml-1">*</span>
                    </label>
                    <select 
                      value={rt}
                      onChange={(e) => handleRtChange(e.target.value)}
                      className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 cursor-pointer font-mono"
                    >
                      <option value="01">01</option>
                      <option value="02">02</option>
                      <option value="03">03</option>
                      <option value="04">04</option>
                    </select>
                  </div>

                  {/* RW input (auto-populated and disabled based on the rule) */}
                  <div className="md:col-span-2 space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">RW (Otomatis)</label>
                    <input 
                      type="text"
                      maxLength={3}
                      disabled
                      value={rw}
                      className="w-full h-11 px-4 border border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-800 text-gray-500 dark:text-slate-400 rounded-xl text-sm outline-none font-mono cursor-not-allowed"
                      placeholder="Terisi otomatis..."
                    />
                  </div>

                  <div className="md:col-span-3 space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">Desa/Kelurahan</label>
                    <input 
                      type="text"
                      value={desa}
                      onChange={(e) => {
                        setDesa(e.target.value);
                        if (errors.desa) setErrors(prev => ({ ...prev, desa: '' }));
                      }}
                      className={`w-full h-11 px-4 border rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 ${
                        errors.desa ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-200 dark:border-slate-700'
                      }`}
                      placeholder="Nama Desa/Kelurahan..."
                    />
                    {errors.desa && <p className="text-xs text-red-500 font-semibold">{errors.desa}</p>}
                  </div>
                </div>
              </section>
            </>
          )}

          {/* ===== TAB 2: Keluarga & Pendidikan ===== */}
          {activeTab === 1 && (
            <>
              <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800">
                <div className="flex items-center gap-3 mb-6 border-b border-gray-100 dark:border-slate-800 pb-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                    <Users className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white">Status Perkawinan & Hubungan Keluarga</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">Status Perkawinan</label>
                    <select 
                      value={maritalStatus}
                      onChange={(e) => setMaritalStatus(e.target.value)}
                      className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 cursor-pointer"
                    >
                      <option value="Belum Kawin">Belum Kawin</option>
                      <option value="Kawin">Kawin</option>
                      <option value="Cerai Hidup">Cerai Hidup</option>
                      <option value="Cerai Mati">Cerai Mati</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">Hubungan Keluarga</label>
                    <select 
                      value={familyRelation}
                      onChange={(e) => setFamilyRelation(e.target.value)}
                      className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 cursor-pointer"
                    >
                      <option value="Kepala Keluarga">Kepala Keluarga</option>
                      <option value="Istri">Istri</option>
                      <option value="Anak">Anak</option>
                      <option value="Orang Tua">Orang Tua</option>
                      <option value="Lainnya">Lainnya</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">Pendidikan Terakhir</label>
                    <select 
                      value={education}
                      onChange={(e) => setEducation(e.target.value)}
                      className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 cursor-pointer"
                    >
                      {PENDIDIKAN_OPTIONS.map((opt) => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  </div>

                  {/* Pekerjaan Dropdown selection */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">Pekerjaan</label>
                    <select 
                      value={job}
                      onChange={(e) => setJob(e.target.value)}
                      className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 cursor-pointer"
                    >
                      {PEKERJAAN_OPTIONS.map((opt) => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </section>

              {/* Orang Tua & Dokumen Sipil */}
              <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800">
                <div className="flex items-center gap-3 mb-6 border-b border-gray-100 dark:border-slate-800 pb-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                    <BookOpen className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white">Orang Tua & Dokumen Sipil</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {/* Father and Mother Names (Linked to Same-KK Members) */}
                  <div className="md:col-span-2 flex items-center gap-2 text-[10px] text-gray-400 mb-1">
                    {kkLoading ? (
                      <span className="flex items-center gap-1.5"><span className="w-3 h-3 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" /> Memuat anggota KK...</span>
                    ) : kkMembers.length > 0 ? (
                      <span className="flex items-center gap-1.5"><ListFilter className="w-3.5 h-3.5" /> {kkMembers.length} anggota ditemukan dalam KK {noKk || '-'}</span>
                    ) : (
                      <span className="flex items-center gap-1.5"><Info className="w-3.5 h-3.5" /> Tidak ada anggota KK ditemukan — gunakan "Ketik Manual"</span>
                    )}
                  </div>

                  <KkParentCombobox
                    label="Nama Ayah Kandung"
                    members={kkMembers}
                    value={fatherName}
                    onChange={handleFatherNameChange}
                    onToggleManual={setFatherManual}
                    isManual={fatherManual}
                    genderFilter="Laki-laki"
                    placeholder="Pilih ayah dari anggota KK..."
                  />

                  <KkParentCombobox
                    label="Nama Ibu Kandung"
                    members={kkMembers}
                    value={motherName}
                    onChange={handleMotherNameChange}
                    onToggleManual={setMotherManual}
                    isManual={motherManual}
                    genderFilter="Perempuan"
placeholder="Pilih ibu dari anggota KK..."
                  />
                </div>
              </section>
            </>
          )}

          {/* ===== TAB 3: Kesejahteraan & Dokumen ===== */}
          {activeTab === 2 && (
            <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800">
              <div className="flex items-center gap-3 mb-6 border-b border-gray-100 dark:border-slate-800 pb-4">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                  <Heart className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">Kesejahteraan & Dokumen</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">Status DTKS / Bansos</label>
                  <select 
                    value={statusDtks}
                    onChange={(e) => setStatusDtks(e.target.value)}
                    className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 cursor-pointer"
                  >
                    <option value="Terdaftar DTKS">Terdaftar DTKS</option>
                    <option value="Tidak Terdaftar DTKS">Tidak Terdaftar DTKS</option>
                    <option value="Usulan Baru">Usulan Baru</option>
                    <option value="Tidak Tahu">Tidak Tahu</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">Disabilitas</label>
                  <select 
                    value={disabilitas}
                    onChange={(e) => setDisabilitas(e.target.value)}
                    className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 cursor-pointer"
                  >
                    <option value="Tidak Ada">Tidak Ada</option>
                    <option value="Disabilitas Fisik">Disabilitas Fisik</option>
                    <option value="Disabilitas Netra">Disabilitas Netra</option>
                    <option value="Disabilitas Rungu/Wicara">Disabilitas Rungu/Wicara</option>
                    <option value="Disabilitas Mental">Disabilitas Mental</option>
                    <option value="Disabilitas Ganda">Disabilitas Ganda</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">Golongan Darah</label>
                  <select 
                    value={bloodType}
                    onChange={(e) => setBloodType(e.target.value)}
                    className="w-full h-11 px-4 border border-gray-200 dark:border-slate-700 rounded-xl text-sm text-gray-900 dark:text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all bg-white dark:bg-slate-900 cursor-pointer"
                  >
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="AB">AB</option>
                    <option value="O">O</option>
                    <option value="Tidak Tahu">Tidak Tahu</option>
                  </select>
                </div>

                <div className="md:col-span-2 space-y-2">
                  <label className="text-xs font-bold text-gray-600 dark:text-slate-400 uppercase tracking-wider">Status Domisili</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <button 
                      type="button"
                      onClick={() => setDomicileStatus('Sesuai KTP')}
                      className={`flex items-center gap-3 p-3.5 border-2 rounded-xl transition-all ${
                        domicileStatus === 'Sesuai KTP' 
                          ? 'border-emerald-600 bg-emerald-50/50 text-emerald-900 font-bold' 
                          : 'border-gray-200 dark:border-slate-700 text-gray-600 dark:text-slate-400 hover:bg-gray-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                        domicileStatus === 'Sesuai KTP' ? 'border-emerald-600' : 'border-gray-300 dark:border-slate-600'
                      }`}>
                        {domicileStatus === 'Sesuai KTP' && <div className="w-2 h-2 bg-emerald-600 rounded-full" />}
                      </div>
                      <span className="text-sm">Sesuai KTP</span>
                    </button>

                    <button 
                      type="button"
                      onClick={() => setDomicileStatus('Pendatang / Domisili Sementara')}
                      className={`flex items-center gap-3 p-3.5 border-2 rounded-xl transition-all ${
                        domicileStatus === 'Pendatang / Domisili Sementara' 
                          ? 'border-emerald-600 bg-emerald-50/50 text-emerald-900 font-bold' 
                          : 'border-gray-200 dark:border-slate-700 text-gray-600 dark:text-slate-400 hover:bg-gray-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                        domicileStatus === 'Pendatang / Domisili Sementara' ? 'border-emerald-600' : 'border-gray-300 dark:border-slate-600'
                      }`}>
                        {domicileStatus === 'Pendatang / Domisili Sementara' && <div className="w-2 h-2 bg-emerald-600 rounded-full" />}
                      </div>
                      <span className="text-sm">Pendatang / Domisili Sementara</span>
                    </button>
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* ===== TAB 4: Riwayat Dokumen (Surat) ===== */}
          {activeTab === 3 && (
            <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 overflow-hidden">
              <div className="flex items-center gap-3 mb-6 border-b border-gray-100 dark:border-slate-800 pb-4">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white">Riwayat Dokumen (Surat)</h3>
                  <p className="text-xs text-gray-500 dark:text-slate-400">{residentLetters.length} surat pernah diterbitkan untuk warga ini</p>
                </div>
              </div>

              {residentLetters.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead>
                      <tr className="border-b border-gray-100 dark:border-slate-800 text-[10px] uppercase tracking-wider text-gray-400 dark:text-slate-500">
                        <th className="px-3 py-2.5 font-bold">Nomor Surat</th>
                        <th className="px-3 py-2.5 font-bold">Jenis Surat</th>
                        <th className="px-3 py-2.5 font-bold">Tgl Terbit</th>
                        <th className="px-3 py-2.5 font-bold">Status</th>
                        <th className="px-3 py-2.5 font-bold text-right">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      {residentLetters.map((letter: any) => (
                        <tr key={letter.id} className="border-b border-gray-50 dark:border-slate-800/60 hover:bg-gray-50/60 dark:hover:bg-slate-800/40 transition-colors">
                          <td className="px-3 py-3 font-mono text-xs font-bold text-gray-900 dark:text-white uppercase">{letter.nomor.toUpperCase() || '-'}</td>
                          <td className="px-3 py-3 text-xs text-gray-700 dark:text-slate-300">{getFullLetterName(letter.jenis)}</td>
                          <td className="px-3 py-3 text-xs text-gray-500 dark:text-slate-400">{letter.tanggal}</td>
                          <td className="px-3 py-3">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider border ${
                              letter.status === 'Selesai' 
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-900/30 dark:border-emerald-800'
                                : 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-900/30 dark:border-amber-800'
                            }`}>{letter.status}</span>
                          </td>
                          <td className="px-3 py-3 text-right">
                            <button
                              type="button"
                              onClick={async () => {
                                const fullData = await getLetterFullData(letter);
                                setViewLetter({ ...letter, fullData });
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-900/30 dark:hover:bg-emerald-900/50 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold transition-colors"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              Lihat
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-8 rounded-xl border border-dashed border-gray-200 dark:border-slate-700 bg-gray-50/50 dark:bg-slate-800/40 text-center">
                  <FileText className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                  <p className="text-sm text-gray-400 italic">Belum ada riwayat surat untuk warga ini.</p>
                </div>
              )}
            </section>
          )}

          {/* ===== TAB 5: Riwayat Bantuan Sosial ===== */}
          {activeTab === 4 && (
            <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 overflow-hidden">
              <div className="flex items-center gap-3 mb-6 border-b border-gray-100 dark:border-slate-800 pb-4">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                  <HandHeart className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white">Riwayat Bantuan Sosial</h3>
                  <p className="text-xs text-gray-500 dark:text-slate-400">{bansosHistory.length} catatan bantuan sosial untuk warga ini</p>
                </div>
              </div>

              {bansosHistory.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead>
                      <tr className="border-b border-gray-100 dark:border-slate-800 text-[10px] uppercase tracking-wider text-gray-400 dark:text-slate-500">
                        <th className="px-3 py-2.5 font-bold">Jenis Program</th>
                        <th className="px-3 py-2.5 font-bold">Periode</th>
                        <th className="px-3 py-2.5 font-bold">Nominal</th>
                        <th className="px-3 py-2.5 font-bold">Status Penyaluran</th>
                      </tr>
                    </thead>
                    <tbody>
                      {bansosHistory.map((entry, idx) => (
                        <tr key={idx} className="border-b border-gray-50 dark:border-slate-800/60 hover:bg-gray-50/60 dark:hover:bg-slate-800/40 transition-colors">
                          <td className="px-3 py-3 text-xs font-bold text-gray-900 dark:text-white">{entry.program}</td>
                          <td className="px-3 py-3 text-xs text-gray-500 dark:text-slate-400">{entry.periode}</td>
                          <td className="px-3 py-3 font-mono text-xs font-bold text-emerald-700 dark:text-emerald-400">{entry.nominal}</td>
                          <td className="px-3 py-3">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider border ${
                              entry.status === 'Aktif'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-900/30 dark:border-emerald-800'
                                : 'bg-rose-50 text-rose-700 border-rose-100 dark:bg-rose-900/30 dark:border-rose-800'
                            }`}>{entry.status}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-8 rounded-xl border border-dashed border-gray-200 dark:border-slate-700 bg-gray-50/50 dark:bg-slate-800/40 text-center">
                  <HandHeart className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                  <p className="text-sm text-gray-400 italic">Belum ada catatan bantuan sosial untuk warga ini.</p>
                </div>
              )}
            </section>
          )}
        </div>

        {/* Right Columns: Sidebar Upload and Dropdowns */}
        <div className="lg:col-span-4 space-y-8">
          
          {/* Avatar Upload Card */}
          <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 text-center relative overflow-hidden">
            <h4 className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-4 text-left">Foto Penduduk</h4>
            
            <div className="relative group mx-auto mb-6">
              <div 
                onClick={() => fileInputRef.current?.click()}
                className={`w-44 h-44 mx-auto rounded-2xl bg-gray-50 dark:bg-slate-800 border-2 border-dashed border-gray-200 dark:border-slate-700 flex flex-col items-center justify-center overflow-hidden transition-all group-hover:border-emerald-600 group-hover:bg-emerald-50/20 cursor-pointer ${
                  photoPreview ? 'border-solid border-emerald-100' : ''
                }`}
              >
                {photoPreview ? (
                  <img src={photoPreview} alt="Pratinjau Foto" className="w-full h-full object-cover animate-in fade-in duration-200" />
                ) : (
                  /* Falls back automatically to beautifully styled gender base avatar (pink/blue) */
                  <div className={`w-full h-full flex flex-col items-center justify-center bg-gradient-to-b text-white transition-all duration-300 ${
                    gender === 'Perempuan' ? 'from-pink-300 to-pink-400' : 'from-blue-300 to-blue-400'
                  }`}>
                    <User className="w-16 h-16 animate-pulse" fill="currentColor" />
                    <span className="text-xs text-white/95 font-bold mt-2 tracking-wide">Pilih Foto</span>
                  </div>
                )}
              </div>
              
              <input 
                type="file" 
                ref={fileInputRef}
                id="photo-upload-input" 
                accept="image/*" 
                className="hidden" 
                onChange={handlePhotoChange}
              />
            </div>

            <div className="flex gap-2">
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 py-2 bg-white dark:bg-slate-900 text-emerald-700 border border-emerald-600 font-bold text-xs rounded-xl hover:bg-emerald-50 transition-colors"
              >
                Pilih File
              </button>
              {photoPreview && (
                <button 
                  type="button"
                  onClick={() => setPhotoPreview(null)}
                  className="px-3 py-2 bg-white dark:bg-slate-900 text-red-600 border border-red-200 rounded-xl hover:bg-red-50 hover:text-red-700 transition-colors"
                  title="Hapus Foto"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
            
            <p className="text-[11px] text-gray-400 leading-relaxed mt-4 text-justify">
              Pastikan foto wajah terlihat jelas dan menggunakan latar belakang polos untuk keperluan administrasi resmi.
            </p>
          </section>

          {/* Status Keberadaan */}
          <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800">
            <div className="flex items-center gap-3 mb-6 border-b border-gray-100 dark:border-slate-800 pb-4">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white">Status Keberadaan</h3>
            </div>

            <div className="space-y-2">
              {STATUS_KEBERADAAN_OPTIONS.map((status) => (
                <button
                  key={status}
                  type="button"
                  onClick={() => setResidentStatus(status)}
                  className={`w-full flex items-center justify-between gap-2 py-2.5 px-4 rounded-xl border-2 text-xs font-bold transition-all ${
                    residentStatus === status
                      ? 'border-emerald-600 bg-emerald-50/50 text-emerald-700'
                      : 'border-gray-100 dark:border-slate-800 text-gray-500 dark:text-slate-400 hover:bg-gray-50/60'
                  }`}
                >
                  {status}
                  {residentStatus === status && <Check className="w-3.5 h-3.5" />}
                </button>
              ))}
            </div>
          </section>

          {/* System Info Accent Card */}
          <div className="bg-white/60 backdrop-blur-xl p-5 rounded-2xl shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 border-l-4 border-l-emerald-600 flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
              <Info className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-emerald-700 uppercase tracking-wider mb-0.5">Informasi Sistem</p>
              <p className="text-xs text-gray-500 dark:text-slate-400 leading-relaxed">
                Data akan dienkripsi dan disimpan secara aman di database desa.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {showConfirmModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm" 
              onClick={() => setShowConfirmModal(false)} 
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white dark:bg-slate-900 rounded-3xl shadow-2xl p-6 md:p-8 w-full max-w-lg border border-gray-100 dark:border-slate-800 flex flex-col max-h-[90vh]"
            >
              <div className="flex items-center gap-4 mb-5 shrink-0">
                <div className="p-4 rounded-2xl bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400">
                  <Check className="w-8 h-8" strokeWidth={2.5} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white leading-tight">
                    Konfirmasi Penyimpanan
                  </h3>
                  <p className="text-sm font-semibold text-gray-500 dark:text-slate-400 mt-1">
                    Pastikan data yang Anda masukkan sudah benar.
                  </p>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto pr-2 mb-6 space-y-4">
                <div className="bg-gray-50 dark:bg-slate-800/80 p-4 rounded-2xl border border-gray-100 dark:border-slate-700/50">
                  <h4 className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider mb-3">Data Pokok Terisi</h4>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-gray-700 dark:text-slate-300">
                    {[
                      { label: 'Nama', val: name },
                      { label: 'NIK', val: nik },
                      { label: 'No KK', val: noKk },
                      { label: 'TTL', val: `${birthPlace}, ${birthDate}` },
                      { label: 'Pekerjaan', val: job },
                      { label: 'Pendidikan', val: education },
                    ].filter(item => item.val).map((item, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                        <span><span className="font-semibold">{item.label}:</span> Terisi</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {(!fatherName || !motherName || !photoPreview) && (
                  <div className="bg-rose-50 dark:bg-rose-900/20 p-4 rounded-2xl border border-rose-100 dark:border-rose-800/30">
                    <h4 className="text-xs font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider mb-3">Bagian Masih Kosong (Opsional)</h4>
                    <ul className="text-sm text-rose-800 dark:text-rose-300 space-y-2">
                      {!fatherName && <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-rose-500" /> Nama Ayah Kandung belum diisi</li>}
                      {!motherName && <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-rose-500" /> Nama Ibu Kandung belum diisi</li>}
                      {!photoPreview && <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-rose-500" /> Foto Penduduk belum diunggah</li>}
                    </ul>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowConfirmModal(false)}
                  className="flex-1 py-3.5 px-4 bg-gray-100 dark:bg-slate-800 hover:bg-gray-200 dark:hover:bg-slate-700 text-gray-700 dark:text-slate-300 font-bold text-sm rounded-xl transition-colors cursor-pointer"
                >
                  Edit Kembali
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowConfirmModal(false);
                    executeSave();
                  }}
                  className="flex-1 py-3.5 px-4 text-white font-bold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20"
                >
                  <Save className="w-4 h-4" />
                  Ya, Simpan Data
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Letter Detail Modal */}
      <AnimatePresence>
        {viewLetter && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm" 
              onClick={() => setViewLetter(null)} 
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white dark:bg-slate-900 rounded-3xl shadow-2xl p-6 w-full max-w-md border border-gray-100 dark:border-slate-800"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-2xl bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400">
                    <FileText className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white">Detail Surat</h3>
                </div>
                <button 
                  onClick={() => setViewLetter(null)}
                  className="text-gray-400 hover:text-gray-600 bg-gray-50 hover:bg-gray-100 dark:bg-slate-800 dark:hover:bg-slate-700 p-1.5 rounded-lg transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between gap-3 border-b border-gray-100 dark:border-slate-800 pb-2.5">
                  <span className="text-gray-500 dark:text-slate-400">Nomor Surat</span>
                  <span className="font-bold text-gray-900 dark:text-white text-right font-mono uppercase">{viewLetter.nomor.toUpperCase() || '-'}</span>
                </div>
                <div className="flex justify-between gap-3 border-b border-gray-100 dark:border-slate-800 pb-2.5">
                  <span className="text-gray-500 dark:text-slate-400">Jenis Surat</span>
                  <span className="font-bold text-gray-900 dark:text-white text-right">{viewLetter.jenis || '-'}</span>
                </div>
                <div className="flex justify-between gap-3 border-b border-gray-100 dark:border-slate-800 pb-2.5">
                  <span className="text-gray-500 dark:text-slate-400">Tgl Terbit</span>
                  <span className="font-bold text-gray-900 dark:text-white text-right">{viewLetter.tanggal || '-'}</span>
                </div>
                <div className="flex justify-between gap-3 border-b border-gray-100 dark:border-slate-800 pb-2.5">
                  <span className="text-gray-500 dark:text-slate-400">Status</span>
                  <span className="font-bold text-gray-900 dark:text-white text-right">{viewLetter.status || '-'}</span>
                </div>
                <div className="flex justify-between gap-3 border-b border-gray-100 dark:border-slate-800 pb-2.5">
                  <span className="text-gray-500 dark:text-slate-400">Keperluan</span>
                  <span className="font-bold text-gray-900 dark:text-white text-right">{viewLetter.keperluan || '-'}</span>
                </div>
                <div className="flex justify-between gap-3">
                  <span className="text-gray-500 dark:text-slate-400">NIK</span>
                  <span className="font-bold text-gray-900 dark:text-white text-right font-mono">{viewLetter.nik || '-'}</span>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
