import { fetchResidentsCached } from '../../../utils/apiCache';
import React, { useState, useRef, useMemo, useEffect } from 'react';
import {
  Plus, Search, Filter, FilterX, FileText, Eye, Printer, Download, Trash2, X, ZoomIn, ZoomOut, Edit2, Ban, ChevronDown, Inbox, BookOpen, MessageCircle, ClipboardCheck, Users
} from 'lucide-react';
import { fetchLetterHistoryAsync, LetterHistory, cancelLetterHistoryAsync, deleteSuratSmart } from '../../../utils/letterHistory';
import { useReactToPrint } from 'react-to-print';
import { getReactSignaturePreview } from '../../../utils/signature';
import { getActiveTenantIdSync } from '../../../utils/tenantResolver';
import { showToast } from '../../../utils/toast';
import { SAAS_CONFIG } from './AdminSuratMasterTemplate';
import TTESignatureBox from './TTESignatureBox';
import WANumberInputModal from '../../common/WANumberInputModal';
import { buildSuratSelesaiMessage, getResidentWaPhone, openFreeWhatsAppMessage } from '../../../utils/waFreeEngine';
import AdminSuratCatatLuar from './AdminSuratCatatLuar';

const getFullLetterName = (jenis: string): string => {
  const mapping: Record<string, string> = {
    'SKM': 'Surat Keterangan Kematian (SKM)',
    'SK KEMATIAN': 'Surat Keterangan Kematian (SKM)',
    'SKAW': 'Surat Keterangan Ahli Waris (SKAW)',
    'SK AHLI WARIS': 'Surat Keterangan Ahli Waris (SKAW)',
    'SKTM': 'Surat Keterangan Tidak Mampu (SKTM)',
    'SKH': 'Surat Keterangan Kehilangan (SKH)',
    'SK KEHILANGAN': 'Surat Keterangan Kehilangan (SKH)',
    'SPT': 'Surat Pengurusan Taspen (SPT)',
    'SURAT PENGURUSAN TASPEN': 'Surat Pengurusan Taspen (SPT)',
    'SDU': 'Surat Keterangan Domisili Usaha (SDU)',
    'SKD': 'Surat Keterangan Domisili Perorangan (SDP)',
    'SDP': 'Surat Keterangan Domisili Perorangan (SDP)',
    'SK DOMISILI': 'Surat Keterangan Domisili Perorangan (SDP)',
    'SK DOMISILI PERORANGAN': 'Surat Keterangan Domisili Perorangan (SDP)',
    'Surat Keterangan Domisili': 'Surat Keterangan Domisili Perorangan (SDP)',
    'SURAT KETERANGAN DOMISILI': 'Surat Keterangan Domisili Perorangan (SDP)',
    'SURAT KETERANGAN DOMISILI PERORANGAN': 'Surat Keterangan Domisili Perorangan (SDP)',
    'SKBM': 'Surat Keterangan Belum Menikah (SKBM)',
    'SK BELUM MENIKAH': 'Surat Keterangan Belum Menikah (SKBM)',
    'SKU': 'Surat Keterangan Usaha (SKU)',
    'SK USAHA': 'Surat Keterangan Usaha (SKU)',
    'SKP': 'Surat Keterangan Pindah (SKP)',
    'SURAT KETERANGAN PINDAH': 'Surat Keterangan Pindah (SKP)',
    'SPH': 'Surat Pengantar Pindah (SPH)',
    'SURAT PINDAH': 'Surat Pengantar Pindah (SPH)',
    'SK PENGHASILAN': 'Surat Keterangan Penghasilan (SKPH)',
    'SKPH': 'Surat Keterangan Penghasilan (SKPH)',
    'Surat Pengantar Nikah': 'Surat Pengantar Nikah (SKN)',
    'SKN': 'Surat Pengantar Nikah (SKN)',
    'SK NIKAH': 'Surat Pengantar Nikah (SKN)'
  };
  const clean = (jenis || '').trim();
  const cleanUpper = clean.toUpperCase();
  return mapping[clean] || mapping[cleanUpper] || clean;
};

interface AdminSuratDashboardProps {
  onBuatSurat: () => void;
  onOpenBatch?: () => void;
  onEditLetter?: (letter: LetterHistory) => void;
  onOpenTambahTamu?: () => void;
  onOpenTambahPermohonan?: () => void;
  searchQuery?: string;
  setSearchQuery?: (val: string) => void;
  debouncedSearchQuery?: string;
}

export default function AdminSuratDashboard({ 
  onBuatSurat,
  onOpenBatch,
  onEditLetter,
  onOpenTambahTamu,
  onOpenTambahPermohonan,
  searchQuery: externalSearchQuery,
  setSearchQuery: externalSetSearchQuery,
  debouncedSearchQuery: externalDebouncedSearchQuery
}: AdminSuratDashboardProps) {
  const [localSearchQuery, setLocalSearchQuery] = useState('');
  const [localDebouncedSearchQuery, setLocalDebouncedSearchQuery] = useState('');
  
  const searchQuery = externalSearchQuery !== undefined ? externalSearchQuery : localSearchQuery;
  const setSearchQuery = externalSetSearchQuery !== undefined ? externalSetSearchQuery : setLocalSearchQuery;

  // Handle local debouncing if no external debounced query is provided
  useEffect(() => {
    if (externalDebouncedSearchQuery !== undefined) return;
    const timer = setTimeout(() => {
      setLocalDebouncedSearchQuery(localSearchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [localSearchQuery, externalDebouncedSearchQuery]);

  const debouncedSearchQuery = externalDebouncedSearchQuery !== undefined ? externalDebouncedSearchQuery : localDebouncedSearchQuery;
  const [selectedType, setSelectedType] = useState('');
  const [suratList, setSuratList] = useState<LetterHistory[]>([]);
  const [residents, setResidents] = useState<any[]>([]);
  const componentRef = useRef<HTMLDivElement>(null);

  const [showPrintWarning, setShowPrintWarning] = useState(false);
  const [selectedSurat, setSelectedSurat] = useState<LetterHistory | null>(null);
  const [suratToDelete, setSuratToDelete] = useState<LetterHistory | null>(null);
  const [suratToCancel, setSuratToCancel] = useState<LetterHistory | null>(null);
  const [waTargetSurat, setWaTargetSurat] = useState<LetterHistory | null>(null);
  const [waInputOpen, setWaInputOpen] = useState(false);
  const [waInputMessage, setWaInputMessage] = useState('');
  const [selectedSuratIds, setSelectedSuratIds] = useState<string[]>([]);
  const [showBulkDeleteModal, setShowBulkDeleteModal] = useState(false);
  const [useEsignature, setUseEsignature] = useState<boolean>(true);
  const [zoomLevel, setZoomLevel] = useState(0.65);
  const [isPrintingTable, setIsPrintingTable] = useState(false);
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [printStartDate, setPrintStartDate] = useState('');
  const [printEndDate, setPrintEndDate] = useState('');
  const [showQuickActions, setShowQuickActions] = useState(false);
  const [showCatatLuar, setShowCatatLuar] = useState(false);
  const quickActionRef = useRef<HTMLDivElement>(null);

  // Kop Surat Settings State for dynamic printing header
  const [kopSettings, setKopSettings] = useState(() => ({
    logoUrl: localStorage.getItem('kop_logo_url') || 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Lambang_Kabupaten_Hulu_Sungai_Selatan.svg/200px-Lambang_Kabupaten_Hulu_Sungai_Selatan.svg.png',
    kabupaten: localStorage.getItem('kop_kabupaten') || localStorage.getItem('village_kabupaten') || 'Pemerintah Kabupaten Hulu Sungai Selatan',
    kecamatan: localStorage.getItem('kop_kecamatan') || localStorage.getItem('village_kecamatan') || 'Kecamatan Simpur',
    desa: localStorage.getItem('kop_desa') || localStorage.getItem('village_name') || 'Desa Ketupat',
    alamat: localStorage.getItem('kop_alamat') || localStorage.getItem('village_alamat') || 'Jalan Keramat, Simpur, Hulu Sungai Selatan, Kalimantan Selatan 71261',
    kontak: localStorage.getItem('kop_kontak') || '0813 4686 7519, pemdesKetupat@gmail.com',
  }));

  useEffect(() => {
    fetchLetterHistoryAsync().then(setSuratList);
    // Fetch residents for accurate preview mapping
    fetchResidentsCached()
      .then(res => { if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`); return res.json(); })
      .then(data => {
        if (Array.isArray(data)) {
          setResidents(data);
        }
      })
      .catch(err => console.error("Error loading residents in dashboard:", err));

    const parseIndonesianDate = (dateStr: string) => {
    if (!dateStr) return null;
    const months = ['januari', 'februari', 'maret', 'april', 'mei', 'juni', 'juli', 'agustus', 'september', 'oktober', 'november', 'desember'];
    const parts = dateStr.toLowerCase().split(' ');
    if (parts.length < 3) return null;
    const day = parseInt(parts[0]);
    const month = months.indexOf(parts[1]);
    const year = parseInt(parts[2]);
    if (isNaN(day) || month === -1 || isNaN(year)) return null;
    return new Date(year, month, day);
  };

  const handleSettingsUpdate = () => {
      setKopSettings({
        logoUrl: localStorage.getItem('kop_logo_url') || 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Lambang_Kabupaten_Hulu_Sungai_Selatan.svg/200px-Lambang_Kabupaten_Hulu_Sungai_Selatan.svg.png',
        kabupaten: localStorage.getItem('kop_kabupaten') || localStorage.getItem('village_kabupaten') || 'Pemerintah Kabupaten Hulu Sungai Selatan',
        kecamatan: localStorage.getItem('kop_kecamatan') || localStorage.getItem('village_kecamatan') || 'Kecamatan Simpur',
        desa: localStorage.getItem('kop_desa') || localStorage.getItem('village_name') || 'Desa Ketupat',
        alamat: localStorage.getItem('kop_alamat') || localStorage.getItem('village_alamat') || 'Jalan Keramat, Simpur, Hulu Sungai Selatan, Kalimantan Selatan 71261',
        kontak: localStorage.getItem('kop_kontak') || '0813 4686 7519, pemdesKetupat@gmail.com',
      });
    };

    window.addEventListener('village_settings_updated', handleSettingsUpdate);
    return () => {
      window.removeEventListener('village_settings_updated', handleSettingsUpdate);
    };
  }, []);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (quickActionRef.current && !quickActionRef.current.contains(event.target as Node)) {
        setShowQuickActions(false);
      }
    }
    if (showQuickActions) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showQuickActions]);

  const handlePrintAll = () => {
    setShowPrintModal(false);
    setIsPrintingTable(true);
    const originalTitle = document.title;
    document.title = "DAFTAR NOMOR SURAT Desa Ketupat";
    setTimeout(() => {
      try {
        window.print();
      } catch (e) {
        setShowPrintWarning(true);
        setTimeout(() => setShowPrintWarning(false), 5000);
      }
      setIsPrintingTable(false);
      document.title = originalTitle;
    }, 200);
  };

  const singlePrintRef = useRef<HTMLDivElement>(null);
  const handleSinglePrint = useReactToPrint({
    contentRef: singlePrintRef,
    documentTitle: selectedSurat ? `Surat_${selectedSurat.nomor.replace(/\//g, '_')}` : 'Cetak Surat',
  });

  const triggerSinglePrint = (surat: LetterHistory) => {
    setSelectedSurat(surat);
    // Tweak to ensure the DOM is ready before printing
    setTimeout(() => {
      handleSinglePrint();
    }, 200);
  };

  const handleDelete = async (surat: LetterHistory) => {
    try {
      const result = await deleteSuratSmart(surat);
      const updated = await fetchLetterHistoryAsync();
      setSuratList(updated);
      showToast(result.message, 'success');
    } catch (e) {
      console.error('Gagal menghapus surat:', e);
      showToast('Gagal menghapus surat. Coba lagi.', 'error');
    }
    setSuratToDelete(null);
    if (selectedSurat && selectedSurat.id === surat.id) {
      setSelectedSurat(null);
    }
  };

  const handleCancel = async (surat: LetterHistory) => {
    const updated = await cancelLetterHistoryAsync(surat.id);
    setSuratList(updated);
    showToast(`Permohonan surat berhasil dibatalkan.`, 'success');
    setSuratToCancel(null);
    if (selectedSurat && selectedSurat.id === surat.id) {
      setSelectedSurat(updated.find(u => u.id === surat.id) || null);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedSuratIds.length === 0) return;
    
    // Penghapusan masal mengikuti aturan yang sama (dual-mode per surat).
    let hardCount = 0;
    let softCount = 0;
    for (const id of selectedSuratIds) {
      const surat = suratList.find(s => s.id === id);
      if (!surat) continue;
      try {
        const result = await deleteSuratSmart(surat);
        if (result.type === 'HARD_DELETE') hardCount++;
        else softCount++;
      } catch (e) {
        console.error('Gagal menghapus surat masal:', id, e);
      }
    }
    const updated = await fetchLetterHistoryAsync();
    
    setSuratList(updated);
    const parts: string[] = [];
    if (hardCount > 0) parts.push(`${hardCount} dihapus permanen`);
    if (softCount > 0) parts.push(`${softCount} disembunyikan (nomor tengah)`);
    showToast(`${selectedSuratIds.length} arsip surat dihapus: ${parts.join(', ') || 'gagal'}.`, 'success');
    setSelectedSuratIds([]);
    setShowBulkDeleteModal(false);
    if (selectedSurat && selectedSuratIds.includes(selectedSurat.id)) {
      setSelectedSurat(null);
    }
  };

  const activeResident = useMemo(() => {
    if (!selectedSurat) return null;
    return residents.find(r => 
      (r.nik && r.nik === selectedSurat.nik) || 
      (r.name && (r.name || '').toLowerCase() === (selectedSurat.nama || '').toLowerCase())
    );
  }, [selectedSurat, residents]);

  const handleSendWaToPemohon = (surat: LetterHistory) => {
    const resident = residents.find(r => 
      (r.nik && r.nik === surat.nik) || 
      (r.name && (r.name || '').toLowerCase() === (surat.nama || '').toLowerCase())
    );
    const waMessage = buildSuratSelesaiMessage({
      nama: surat.nama || 'Warga',
      jenisSurat: getFullLetterName(surat.jenis),
      noSurat: surat.nomor
    });
    const phone = resident ? getResidentWaPhone(resident) : '';
    if (phone) {
      openFreeWhatsAppMessage({ phone, message: waMessage });
    } else {
      setWaTargetSurat(surat);
      setWaInputMessage(waMessage);
      setWaInputOpen(true);
    }
  };

  const filteredSurat = useMemo(() => {
    return suratList.filter((surat) => {
      const matchesSearch = 
        (surat.nomor || '').toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
        (surat.nama || '').toLowerCase().includes(debouncedSearchQuery.toLowerCase());

      let matchesType = true;
      if (selectedType) {
        if (selectedType === 'domisili') {
          matchesType = (surat.jenis || '').toLowerCase().includes('domisili');
        } else if (selectedType === 'sktm') {
          matchesType = (surat.jenis || '').toLowerCase() === 'sktm';
        } else if (selectedType === 'sku') {
          matchesType = (surat.jenis || '').toLowerCase().includes('usaha') || (surat.jenis || '').toLowerCase().includes('sku');
        } else if (selectedType === 'skph') {
          matchesType = (surat.jenis || '').toLowerCase().includes('penghasilan') || (surat.jenis || '').toLowerCase().includes('skph');
        } else if (selectedType === 'spt') {
          matchesType = (surat.jenis || '').toLowerCase() === 'spt' || (surat.jenis || '').toLowerCase().includes('taspen');
        } else if (selectedType === 'sppd') {
          matchesType = (surat.jenis || '').toLowerCase().includes('sppd') || (surat.jenis || '').toLowerCase().includes('perjalanan dinas') || (surat.jenis || '').toLowerCase().includes('surat tugas');
        }
      }

      return matchesSearch && matchesType;
    });
  }, [suratList, debouncedSearchQuery, selectedType]);

  const handleExportExcel = () => {
    const headers = ['Nomor Surat', 'Jenis Surat', 'Pemohon', 'Tanggal', 'Status'];
    const csvContent = [
      headers.join(','),
      ...suratList.map(surat => 
        `"${surat.nomor}","${surat.jenis}","${surat.nama}","${surat.tanggal}","${surat.status}"`
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', 'arsip_surat_desa.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Helper to render letter layout exactly like AdminSuratBuat.tsx
  const renderLetterContent = (surat: LetterHistory, residentObj: any) => {
    const logoUrl = localStorage.getItem('kop_logo_url') || 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Lambang_Kabupaten_Hulu_Sungai_Selatan.svg/200px-Lambang_Kabupaten_Hulu_Sungai_Selatan.svg.png';
    const kabupatenName = localStorage.getItem('kop_kabupaten') || 'Pemerintah Kabupaten Hulu Sungai Selatan';
    const kecamatanName = localStorage.getItem('kop_kecamatan') || 'Kecamatan Simpur';
    const desaName = localStorage.getItem('kop_desa') || 'Desa Ketupat';
    const alamatKantor = localStorage.getItem('kop_alamat') || 'Jalan Keramat, Simpur, Hulu Sungai Selatan, Kalimantan Selatan 71261';
    const kontakKantor = localStorage.getItem('kop_kontak') || '0813 4686 7519, pemdesKetupat@gmail.com';
    const namaKades = localStorage.getItem('kop_kades') || '';

    const renderReactSignature = (desaName: string, tglFormatted: string, namaPejabat: string, jabatanPejabat: string, nipPejabat?: string, includeCamatOverride?: boolean) => {
      const sig = getReactSignaturePreview(desaName, tglFormatted, namaPejabat, jabatanPejabat, nipPejabat, includeCamatOverride);

      const textAlignClass = sig.sigAlign === 'left' ? 'text-left' : 'text-center';
      const nameUnderlineClass = sig.sigUnderline === 'yes' ? 'underline' : 'no-underline';

      const rightSideJSX = (
      <div className={`w-[230px] inline-block align-top text-black ${textAlignClass}`}>
        {sig.sigShowMeta === 'simple' && (
          <p className="m-0 text-xs mb-2">{sig.cleanDesaName}, {tglFormatted}</p>
        )}
        {(sig.sigShowMeta === 'complete' || sig.sigShowMeta === 'yes') && (
          <div className="mb-2">
            <p className="m-0 text-xs">Dikeluarkan di : {sig.cleanDesaName}</p>
            <p className="m-0 border-b border-black pb-0.5 mb-2 text-xs inline-block">Pada Tanggal : {tglFormatted}</p>
          </div>
        )}
        <div className={`min-h-[45px] leading-relaxed mb-14 text-xs mt-1 ${textAlignClass}`}>
          {sig.rightRole.split('\n').map((line, idx) => (
            <React.Fragment key={idx}>{line}<br /></React.Fragment>
          ))}
        </div>
        <p className={`font-bold uppercase text-xs m-0 decoration-1 ${nameUnderlineClass} ${textAlignClass}`}>{namaPejabat}</p>
        {nipPejabat && nipPejabat !== '-' && nipPejabat !== '' && (
          <p className={`text-[10px] font-mono mt-0.5 text-gray-700 dark:text-slate-300 m-0 ${textAlignClass}`}>NIP. {nipPejabat}</p>
        )}
      </div>
    );

    if (sig.isDual) {
      return (
        <div className="mt-8 px-4 text-black">
          {/* TOP ROW (Roles) */}
          <div className="flex justify-between">
            {/* Left Top */}
            <div className={`w-[230px] ${textAlignClass}`}>
              <div className="invisible">
                {sig.sigShowMeta === 'simple' ? (
                  <p className="m-0 text-xs mb-2">&nbsp;</p>
                ) : (sig.sigShowMeta === 'complete' || sig.sigShowMeta === 'yes') ? (
                  <div className="mb-2">
                    <p className="m-0 text-xs">&nbsp;</p>
                    <p className="m-0 border-b border-transparent pb-0.5 mb-2 text-xs inline-block">&nbsp;</p>
                  </div>
                ) : null}
              </div>
              <div className={`mt-1 min-h-[45px] leading-relaxed text-xs whitespace-pre-line ${textAlignClass}`}>
                {sig.sigLeftRole}
              </div>
            </div>
            
            {/* Right Top */}
            <div className={`w-[230px] ${textAlignClass}`}>
              {sig.sigShowMeta === 'simple' && (
                <p className="m-0 text-xs mb-2">{sig.cleanDesaName}, {tglFormatted}</p>
              )}
              {(sig.sigShowMeta === 'complete' || sig.sigShowMeta === 'yes') && (
                <div className="mb-2">
                  <p className="m-0 text-xs">Dikeluarkan di : {sig.cleanDesaName}</p>
                  <p className="m-0 border-b border-black pb-0.5 mb-2 text-xs inline-block">Pada Tanggal : {tglFormatted}</p>
                </div>
              )}
              <div className={`min-h-[45px] leading-relaxed text-xs mt-1 ${textAlignClass}`}>
                {sig.rightRole.split('\n').map((line, idx) => (
                  <React.Fragment key={idx}>{line}<br /></React.Fragment>
                ))}
              </div>
            </div>
          </div>

          {/* SPACE FOR SIGNATURE */}
          <div className="h-14"></div>

          {/* BOTTOM ROW (Names) */}
          <div className="flex justify-between">
            {/* Left Bottom */}
            <div className={`w-[230px] ${textAlignClass}`}>
              <p className={`font-bold text-xs m-0 decoration-1 ${nameUnderlineClass} ${textAlignClass}`}>{sig.sigLeftName}</p>
              {sig.sigLeftPangkat && (
                <p className={`text-[11px] mt-0.5 text-gray-800 dark:text-slate-100 m-0 ${textAlignClass}`}>{sig.sigLeftPangkat}</p>
              )}
              {sig.sigLeftNip && sig.sigLeftNip !== '-' && (
                <p className={`text-[11px] mt-0.5 text-gray-800 dark:text-slate-100 m-0 ${textAlignClass}`}>NIP : {sig.sigLeftNip}</p>
              )}
            </div>

            {/* Right Bottom */}
            <div className={`w-[230px] ${textAlignClass}`}>
              <p className={`font-bold uppercase text-xs m-0 decoration-1 ${nameUnderlineClass} ${textAlignClass}`}>{namaPejabat}</p>
              {nipPejabat && nipPejabat !== '-' && nipPejabat !== '' && (
                <p className={`text-[10px] font-mono mt-0.5 text-gray-700 dark:text-slate-300 m-0 ${textAlignClass}`}>NIP. {nipPejabat}</p>
              )}
            </div>
          </div>
        </div>
      );
    } else {
      if (useEsignature) {
        const tenantId = getActiveTenantIdSync();
        const verifyUrl = typeof window !== 'undefined' ? `${window.location.origin}/?tab=verifikasi&t_id=${encodeURIComponent(tenantId)}&id=${surat.id}` : `https://sistemdidesa.id/?tab=verifikasi&t_id=${encodeURIComponent(tenantId)}&id=${surat.id}`;
        return (
          <div className="mt-8 flex justify-end text-black">
            <div className="text-right">
              <TTESignatureBox
                dateStr={`${sig.cleanDesaName}, ${tglFormatted}`}
                officerTitle={sig.rightRole.replace(/\n/g, ' ')}
                officerName={namaPejabat}
                nip={nipPejabat !== '-' ? nipPejabat : undefined}
                verifyUrl={verifyUrl}
              />
            </div>
          </div>
        );
      }

      return (
        <div className="mt-8 flex justify-end text-black">
          {rightSideJSX}
        </div>
      );
    }
  };

    const getKlasifikasiFromSurat = (s: LetterHistory) => {
      const typeLower = (s.jenis || '').toLowerCase();
      const nomorSafe = (s.nomor || '');
      if (typeLower.includes('nikah') || typeLower.includes('skn') || typeLower === 'skn' || nomorSafe.includes('/SKN/')) return 'SKN';
      if (typeLower.includes('kematian') || typeLower === 'skm' || nomorSafe.includes('/SKM/')) return 'SKM';
      if (typeLower.includes('ahli waris') || typeLower === 'skaw' || nomorSafe.includes('/SKAW/')) return 'SKAW';
      if (typeLower.includes('tidak mampu') || typeLower.includes('sktm') || nomorSafe.includes('/SKTM/')) return 'SKTM';
      if (typeLower.includes('usaha') || typeLower === 'sku' || nomorSafe.includes('/SKU/')) return 'SKU';
      if (typeLower.includes('penghasilan') || typeLower === 'skph' || nomorSafe.includes('/SKPH/')) return 'SKPH';
      if (typeLower.includes('belum menikah') || typeLower.includes('belum kawin') || typeLower === 'skbm' || nomorSafe.includes('/SKBM/')) return 'SKBM';
      if (typeLower.includes('kelahiran') || typeLower.includes('lahir') || typeLower === 'skl' || nomorSafe.includes('/SKL/')) return 'SKL';
      if (typeLower.includes('pindah') || typeLower === 'skp' || typeLower === 'sph' || nomorSafe.includes('/SPH/') || nomorSafe.includes('/SKP/')) return 'SKP';
      if (typeLower.includes('kehilangan') || typeLower === 'skh' || nomorSafe.includes('/SKH/')) return 'SKH';
      if (typeLower.includes('undangan') || typeLower === 'und' || nomorSafe.includes('/UND/')) return 'UND';
      if (typeLower === 'su' || nomorSafe.includes('/SU/') || typeLower.includes('umum') || typeLower.includes('dinas')) return 'SU';
      if (typeLower.includes('domisili') || typeLower === 'skd' || typeLower === 'sdp' || nomorSafe.includes('/SKD/') || nomorSafe.includes('/SDP/')) return 'SDP';
      return typeLower.toUpperCase();
    };

    const code = getKlasifikasiFromSurat(surat);
    const isSU = code === 'SU' || code === 'UND';
    
    const rawData = surat.data || {};
    const sd = {
      ...rawData,
      usahaName: rawData.nama_usaha || rawData.usahaName,
      usahaJenis: rawData.jenis_usaha || rawData.usahaJenis,
      usahaAlamat: rawData.alamat_usaha || rawData.usahaAlamat,
      namaPasangan: rawData.nama_pasangan || rawData.namaPasangan,
      nikPasangan: rawData.nik_pasangan || rawData.nikPasangan,
      tanggalNikah: rawData.tanggal_nikah || rawData.tanggalNikah
    };
    const name = sd.nama || residentObj?.name || surat.nama;
    const nik = sd.nik || residentObj?.nik || surat.nik || '-';
    const birthPlace = sd.tempatLahir || residentObj?.birthPlace || '-';
    const birthDate = sd.tanggalLahir || residentObj?.birthDate || '-';
    const gender = sd.jenisKelamin || residentObj?.gender || '-';
    const address = sd.alamat || residentObj?.address || '-';
    const rtRw = (sd.rt && sd.rw) ? `RT.${sd.rt} RW.${sd.rw}` : (residentObj?.rt_rw ? `RT/RW ${residentObj.rt_rw}` : '-');

    return (
      <div className="text-black text-left font-sans" style={{ fontFamily: 'Arial, Helvetica, sans-serif' }}>
        {/* Kop Surat */}
        <div className="flex flex-col mb-[25px]">
          <div className="flex items-center pb-3 border-b-[2.5px] border-black">
            {logoUrl && (
              <div className="w-[80px] h-[90px] flex-shrink-0 flex items-center justify-center mr-[15px]">
                <img 
                  src={logoUrl} 
                  alt="Logo" 
                  className="w-full h-full object-contain" 
                  onError={(e) => e.currentTarget.style.display = 'none'} 
                />
              </div>
            )}
            <div className={`flex-1 text-center ${logoUrl ? 'pr-[80px]' : ''}`}>
              <h5 className="text-[12px] uppercase font-bold text-black" style={{ lineHeight: '1.2', letterSpacing: '1px' }}>{kabupatenName}</h5>
              <h5 className="text-[12px] uppercase font-bold text-black" style={{ lineHeight: '1.2', letterSpacing: '1px' }}>{kecamatanName}</h5>
              <h5 className="font-black text-[22px] uppercase mt-[2px] leading-none text-black" style={{ letterSpacing: '2px' }}>{desaName}</h5>
              <p className="text-[9px] text-black mt-[4px] capitalize">{alamatKantor}</p>
              <p className="text-[9px] text-black">{kontakKantor}</p>
            </div>
          </div>
        </div>
        
        {/* Letter Body */}
        {isSU ? (
          <div className="text-[14px] text-black space-y-4">
            <div className="flex justify-end mb-4">
              <p>{desaName.replace(/desa|kelurahan/gi, '').trim()}, {surat.tanggal}</p>
            </div>
            
            <div className="flex gap-4">
              <div className="w-20 font-bold">
                <p>Nomor</p>
                <p>Sifat</p>
                <p>Lampiran</p>
                <p>Hal</p>
              </div>
              <div className="w-4">
                <p>:</p>
                <p>:</p>
                <p>:</p>
                <p>:</p>
              </div>
              <div className="flex-1">
                <p className="font-mono font-bold uppercase nomor-surat-cetak">{surat.nomor.toUpperCase()}</p>
                <p>Penting</p>
                <p>-</p>
                <p className="font-bold uppercase text-emerald-950">{surat.keperluan || (code === 'UND' ? 'UNDANGAN PERTEMUAN KOORDINASI' : 'PERMOHONAN RESMI / KOORDINASI')}</p>
              </div>
            </div>

            <div className="mt-6 mb-8">
              <div className="flex gap-2">
                <span>Yth.</span>
                <div>
                  <p>{code === 'UND' ? 'Seluruh Warga Desa Terkait' : 'Kepala Instansi / Warga Terkait'}</p>
                  <p>di</p>
                  <p className="ml-4 font-bold">Tempat</p>
                </div>
              </div>
            </div>

            <div className="space-y-2 text-justify leading-relaxed">
              {code === 'UND' ? (
                <>
                  <p className="indent-8">
                    Sehubungan dengan diadakannya agenda rapat koordinasi bulanan dan evaluasi kemasyarakatan di lingkungan wilayah {desaName}, kami bermaksud mengundang kehadiran Bapak/Ibu/Saudara(i) dalam rapat bersama tersebut.
                  </p>
                  <p className="indent-8">
                    Kehadiran Bapak/Ibu sangat kami harapkan demi kelancaran pembangunan wilayah kependudukan kita bersama secara berkelanjutan.
                  </p>
                </>
              ) : (
                <>
                  <p className="indent-8">
                    Dalam rangka kelancaran administrasi kependudukan dan koordinasi pembangunan di wilayah {desaName}, {kecamatanName}, {kabupatenName}, kami bermaksud menyampaikan hal terkait perihal di atas.
                  </p>
                  <p className="indent-8">
                    Sehubungan dengan hal tersebut, segala ketentuan kependudukan dan rincian teknis yang bersangkutan agar dapat dipergunakan dan difasilitasi sebagaimana mestinya sesuai aturan yang berlaku.
                  </p>
                </>
              )}
              <p className="indent-8">
                Demikian surat ini kami sampaikan, atas kerja sama dan perhatian bapak/ibu kami ucapkan terima kasih.
              </p>
            </div>

            <div className="mt-16 flex justify-end">
              <div className="text-center w-[250px]">
                <p>Kepala {desaName},</p>
                <div className="h-24"></div>
                <p className="font-bold uppercase">{namaKades}</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-[14px] text-black">
            
            <div className="text-center mb-8">
              <h6 className="font-bold underline uppercase text-[16px] tracking-wide" style={{ letterSpacing: '1px' }}>
                {(() => {
                  switch (code) {
                    case 'SKN': return 'SURAT PENGANTAR NIKAH (SKN)';
                    case 'SKM': return 'SURAT KETERANGAN KEMATIAN (SKM)';
                    case 'SKAW': return 'SURAT KETERANGAN AHLI WARIS (SKAW)';
                    case 'SKTM': return 'SURAT KETERANGAN TIDAK MAMPU (SKTM)';
                    case 'SKU': return 'SURAT KETERANGAN USAHA (SKU)';
                    case 'SKBM': return 'SURAT KETERANGAN BELUM PERNAH MENIKAH (SKBM)';
                    case 'SKL': return 'SURAT KETERANGAN KELAHIRAN (SKL)';
                    case 'SPH': return 'SURAT PENGANTAR PINDAH (SPH)';
                    case 'SKPH': return 'SURAT KETERANGAN PENGHASILAN (SKPH)';
                    case 'SKD':
                    case 'SDP': return 'SURAT KETERANGAN DOMISILI PERORANGAN (SDP)';
                    case 'SKP': return 'SURAT KETERANGAN PINDAH (SKP)';
                    case 'SKH': return 'SURAT KETERANGAN KEHILANGAN (SKH)';
                    case 'SDU': return 'SURAT KETERANGAN DOMISILI USAHA (SDU)';
                    case 'SPT': return 'SURAT PENGURUSAN TASPEN (SPT)';
                    default: return getFullLetterName(surat.jenis).toUpperCase();
                  }
                })()}
              </h6>
              <p className="text-[14px] font-mono mt-1 uppercase nomor-surat-cetak">Nomor: {surat.nomor.toUpperCase()}</p>
            </div>

            
            {(() => {
              let leadingParagraph = `Yang bertanda tangan di bawah ini Kepala ${desaName}, ${kecamatanName}, ${kabupatenName}, menerangkan dengan sebenarnya bahwa:`;
              let middleParagraph = `Adalah benar nama tersebut di atas merupakan penduduk ${desaName} yang berdomisili sah pada alamat tersebut. Surat keterangan ini diterbitkan secara resmi untuk memenuhi keperluan:`;
              let trailingParagraph = `Demikian surat keterangan ini kami buat dengan sebenarnya agar dapat dipergunakan dan dipertanggungjawabkan sebagaimana mestinya.`;

              let specificContent = null;

              const fmtDate = (d: string) => {
                if (!d) return '-';
                try { return new Date(d).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }); } catch(e) { return d; }
              };
              
              if (code === 'SKH') {
                return (
                  <>
                    <p className="text-justify leading-relaxed indent-8 mb-2">
                      Yang bertanda tangan di bawah ini Kepala {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')} Kabupaten {kabupatenName.replace(/^(kabupaten|kota)\s+/i, '')}, menerangkan dengan sebenarnya bahwa :
                    </p>
                    <table className="w-[calc(100%-40px)] border-collapse mb-2 ml-10 text-[14px]" style={{lineHeight: 1.3}}>
                      <tbody>
                        <tr><td style={{width: '30%'}}>Nama Lengkap</td><td style={{width: '3%'}}>:</td><td><strong className="uppercase">{name}</strong></td></tr>
                        <tr><td>NIK</td><td>:</td><td>{nik}</td></tr>
                        <tr><td>Tempat, Tanggal lahir</td><td>:</td><td>{birthPlace}, {fmtDate(birthDate)}</td></tr>
                        <tr><td>Jenis Kelamin</td><td>:</td><td>{gender}</td></tr>
                        <tr><td>Agama</td><td>:</td><td>{sd.agama || '-'}</td></tr>
                        <tr><td>Pekerjaan</td><td>:</td><td>{sd.pekerjaan || '-'}</td></tr>
                        <tr><td>Status Perkawinan</td><td>:</td><td>{sd.statusPerkawinan || '-'}</td></tr>
                        <tr><td style={{verticalAlign: 'top'}}>Alamat</td><td style={{verticalAlign: 'top'}}>:</td><td>{address} {rtRw}<br/>Desa {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')}</td></tr>
                      </tbody>
                    </table>
                    
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Berdasarkan keterangan yang bersangkutan, bahwa telah kehilangan surat / barang berharga berupa:
                    </p>
                    <table className="w-[calc(100%-40px)] border-collapse mb-2 ml-10 text-[14px]" style={{lineHeight: 1.3}}>
                      <tbody>
                        <tr><td style={{width: '30%'}}>Barang yang Hilang</td><td style={{width: '3%'}}>:</td><td><strong>{sd.barangHilang || '-'}</strong></td></tr>
                        <tr><td>Tanggal Kehilangan</td><td>:</td><td>{fmtDate(sd.tanggalKehilangan)}</td></tr>
                        <tr><td>Tempat Kehilangan</td><td>:</td><td>{sd.tempatKehilangan || '-'}</td></tr>
                        <tr><td style={{verticalAlign: 'top'}}>Keterangan</td><td style={{verticalAlign: 'top'}}>:</td><td>{sd.keteranganKehilangan || '-'}</td></tr>
                      </tbody>
                    </table>
                    
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Surat Keterangan ini dibuat untuk <strong>{surat.keperluan || '-'}</strong>.
                    </p>
                    <p className="text-justify leading-relaxed indent-8 mb-6">
                      Demikian Surat Keterangan Kehilangan ini dibuat dengan sebenarnya dan untuk dipergunakan sebagaimana mestinya.
                    </p>
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const officersList = JSON.parse(localStorage.getItem('village_officers') || '[]'); const found = officersList.find((o: any) => o.name === namaKades); return found?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              }
              

              const DataPenduduk = () => (
                <table className="w-[calc(100%-40px)] border-collapse mb-4 ml-10 text-[14px]" style={{lineHeight: 1.3}}>
                  <tbody>
                    <tr><td style={{width: '30%'}}>Nama Lengkap</td><td style={{width: '3%'}}>:</td><td><strong className="uppercase">{name}</strong></td></tr>
                    <tr><td>NIK</td><td>:</td><td>{nik}</td></tr>
                    <tr><td>Tempat, Tanggal lahir</td><td>:</td><td>{birthPlace}, {fmtDate(birthDate)}</td></tr>
                    <tr><td>Jenis Kelamin</td><td>:</td><td>{gender}</td></tr>
                    <tr><td>Agama</td><td>:</td><td>{sd.agama || '-'}</td></tr>
                    <tr><td>Pekerjaan</td><td>:</td><td>{sd.pekerjaan || '-'}</td></tr>
                    <tr><td>Status Perkawinan</td><td>:</td><td>{sd.statusPerkawinan || '-'}</td></tr>
                    <tr><td style={{verticalAlign: 'top'}}>Alamat</td><td style={{verticalAlign: 'top'}}>:</td><td>{address} {rtRw}<br/>Desa {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')}</td></tr>
                  </tbody>
                </table>
              );

              const pembuka = (
                <p className="text-justify leading-relaxed indent-8 mb-2">
                  Yang bertanda tangan di bawah ini Kepala {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')} Kabupaten {kabupatenName.replace(/^(kabupaten|kota)\s+/i, '')}, menerangkan dengan sebenarnya bahwa :
                </p>
              );

              const penutup = (keperluan: string, namaSurat: string) => (
                <>
                  <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                    Surat keterangan ini diberikan atas dasar permohonan yang bersangkutan, untuk dipergunakan sebagai persyaratan administrasi <strong>{keperluan || '-'}</strong>.
                  </p>
                  <p className="text-justify leading-relaxed indent-8 mb-6">
                    Demikian surat keterangan ini dibuat dengan sebenarnya untuk dapat dipergunakan sebagaimana mestinya.
                  </p>
                </>
              );

              if (code === 'SKD' || code === 'SDP') {
                return (
                  <>
                    <p className="text-justify leading-relaxed indent-8 mb-2">
                      Menerangkan bahwa:
                    </p>
                    <table className="w-[calc(100%-40px)] border-collapse mb-4 ml-10 text-[14px]" style={{lineHeight: 1.3}}>
                      <tbody>
                        <tr><td style={{width: '30%'}}>a. Nama</td><td style={{width: '3%'}}>:</td><td><strong className="uppercase">{name}</strong></td></tr>
                        <tr><td>b. NIK</td><td>:</td><td>{nik}</td></tr>
                        <tr><td>c. Jenis Kelamin</td><td>:</td><td>{gender}</td></tr>
                        <tr><td>d. Tempat, Tgl Lahir</td><td>:</td><td>{birthPlace}, {fmtDate(birthDate)}</td></tr>
                        <tr><td>e. Pekerjaan</td><td>:</td><td>{sd.pekerjaan || '-'}</td></tr>
                        <tr><td>f. Kewarganegaraan</td><td>:</td><td>{sd.kewarganegaraan || 'WNI'}</td></tr>
                        <tr><td>g. Status Perkawinan</td><td>:</td><td>{sd.statusPerkawinan || '-'}</td></tr>
                        <tr><td>h. Agama</td><td>:</td><td>{sd.agama || '-'}</td></tr>
                        <tr><td style={{verticalAlign: 'top'}}>i. Alamat</td><td style={{verticalAlign: 'top'}}>:</td><td>{address} {rtRw}<br/>Desa {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')}</td></tr>
                        <tr><td style={{verticalAlign: 'top'}}>j. Alamat Sekarang</td><td style={{verticalAlign: 'top'}}>:</td><td>{sd.alamatSekarang || '-'} RT.{sd.rtSekarang || '-'} RW.{sd.rwSekarang || '-'}<br/>Desa {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')}</td></tr>
                      </tbody>
                    </table>
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Berdasarkan surat pernyataan dan keterangan yang dibuat oleh yang bersangkutan, nama tersebut di atas menyatakan dengan sadar bahwa ia memang berstatus <strong className="uppercase">DOMISILI {sd.sifatDomisili || '-'}</strong> di alamat sekarang tersebut.
                    </p>
                    {penutup(surat.keperluan, 'Domisili')}
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              } else if (code === 'SKP') {
                return (
                  <>
                    {pembuka}
                    <DataPenduduk />
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Bahwa nama tersebut di atas terhitung mulai tanggal <strong>{fmtDate(sd.tanggalPindah)}</strong> mengajukan permohonan pindah domisili dengan rincian sebagai berikut:
                    </p>
                    <table className="w-[calc(100%-40px)] border-collapse mb-2 ml-10 text-[14px]" style={{lineHeight: 1.3}}>
                      <tbody>
                        <tr><td style={{width: '30%'}}>Alamat Tujuan Pindah</td><td style={{width: '3%'}}>:</td><td>{sd.alamatTujuan || '-'}</td></tr>
                        <tr><td>RT / RW Tujuan</td><td>:</td><td>RT. {sd.rtTujuan || '-'} / RW. {sd.rwTujuan || '-'}</td></tr>
                        <tr><td>Desa / Kelurahan Tujuan</td><td>:</td><td>{sd.desaTujuan || '-'}</td></tr>
                        <tr><td>Kecamatan Tujuan</td><td>:</td><td>{sd.kecamatanTujuan || '-'}</td></tr>
                        <tr><td>Kabupaten / Kota Tujuan</td><td>:</td><td>{sd.kabupatenTujuan || '-'}</td></tr>
                        <tr><td>Provinsi Tujuan</td><td>:</td><td>{sd.provinsiTujuan || '-'}</td></tr>
                        <tr><td>Alasan Pindah</td><td>:</td><td><strong>{sd.alasanPindah || '-'}</strong></td></tr>
                        <tr><td>Jml Keluarga Pindah</td><td>:</td><td>{sd.jumlahKeluargaPindah || '0'} Orang</td></tr>
                      </tbody>
                    </table>
                    {penutup(surat.keperluan, 'Pengantar Pindah')}
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              } else if (code === 'SKM') {
                return (
                  <>
                    {pembuka}
                    <DataPenduduk />
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Nama tersebut di atas adalah benar-benar penduduk Desa {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')}, yang mana berdasarkan laporan dan kesaksian dari pihak keluarga, yang bersangkutan telah meninggal dunia pada:
                    </p>
                    <table className="w-[calc(100%-40px)] border-collapse mb-2 ml-10 text-[14px]" style={{lineHeight: 1.3}}>
                      <tbody>
                        <tr><td style={{width: '30%'}}>Hari</td><td style={{width: '3%'}}>:</td><td>{sd.hariMeninggal || '-'}</td></tr>
                        <tr><td>Tanggal</td><td>:</td><td>{fmtDate(sd.tanggalMeninggal)}</td></tr>
                        <tr><td>Pukul</td><td>:</td><td>{sd.pukulMeninggal || '-'}</td></tr>
                        <tr><td>Tempat</td><td>:</td><td>{sd.tempatMeninggal || '-'}</td></tr>
                        <tr><td>Penyebab Kematian</td><td>:</td><td>{sd.penyebabMeninggal || '-'}</td></tr>
                      </tbody>
                    </table>
                    {penutup(surat.keperluan, 'Kematian')}
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              } else if (code === 'SKAW') {
                return (
                  <>
                    {pembuka}
                    <DataPenduduk />
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Menyatakan dengan sesungguhnya bahwa nama warga di atas adalah <strong>ahli waris sah</strong> yang diakui secara adat dan administrasi hukum dari garis keturunan almarhum pewaris sah.
                    </p>
                    {penutup(surat.keperluan, 'Ahli Waris')}
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              } else if (code === 'SKTM') {
                return (
                  <>
                    {pembuka}
                    <DataPenduduk />
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Nama tersebut di atas adalah benar-benar warga / penduduk yang berdomisili di Desa {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')} dan yang bersangkutan benar-benar tergolong keluarga <strong className="italic">Kurang Mampu (Miskin)</strong>.
                    </p>
                    {(sd.pekerjaan_ortu || sd.penghasilan) && (
                      <table className="w-[calc(100%-40px)] border-collapse mb-2 ml-10 text-[14px]" style={{lineHeight: 1.3}}>
                        <tbody>
                          {sd.pekerjaan_ortu && <tr><td style={{width: '40%'}}>Pekerjaan Orang Tua / Wali</td><td style={{width: '3%'}}>:</td><td>{sd.pekerjaan_ortu}</td></tr>}
                          {sd.penghasilan && <tr><td>Rata-rata Penghasilan</td><td>:</td><td>Rp {Number(sd.penghasilan).toLocaleString('id-ID')}</td></tr>}
                        </tbody>
                      </table>
                    )}
                    {penutup(surat.keperluan, 'Tidak Mampu')}
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              } else if (code === 'SKU') {
                return (
                  <>
                    {pembuka}
                    <DataPenduduk />
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Adalah benar nama tersebut di atas merupakan warga kami yang berdomisili sah di Desa {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')}, dan berdasarkan peninjauan kami memang benar memiliki dan aktif mengelola unit usaha perorangan mandiri dengan rincian detail sebagai berikut :
                    </p>
                    <table className="w-[calc(100%-40px)] border-collapse mb-2 ml-10 text-[14px]" style={{lineHeight: 1.3}}>
                      <tbody>
                        <tr><td style={{width: '30%'}}>Nama Usaha / Toko</td><td style={{width: '3%'}}>:</td><td><strong className="uppercase">{sd.usahaName || 'WARUNG / TOKO PERORANGAN'}</strong></td></tr>
                        <tr><td>Jenis / Bidang Usaha</td><td>:</td><td>{sd.usahaJenis || '-'}</td></tr>
                        <tr><td>Alamat Lokasi Usaha</td><td>:</td><td>{sd.usahaAlamat || address}</td></tr>
                        <tr><td>Mulai Berdiri Sejak</td><td>:</td><td>{sd.usahaMulai || '-'}</td></tr>
                        {sd.usahaNib && <tr><td>NIB / Izin Usaha</td><td>:</td><td className="font-mono font-bold">{sd.usahaNib}</td></tr>}
                        {sd.usahaOmzet && <tr><td>Estimasi Omset Bulanan</td><td>:</td><td>{sd.usahaOmzet}</td></tr>}
                      </tbody>
                    </table>
                    {penutup(surat.keperluan, 'Usaha')}
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              } else if (code === 'SKBM') {
                return (
                  <>
                    {pembuka}
                    <DataPenduduk />
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Berdasarkan data kependudukan kami, nama tersebut di atas benar berstatus <strong>Belum Kawin (Belum Pernah Menikah)</strong>. Surat keterangan ini diberikan atas dasar permohonan yang bersangkutan untuk dipergunakan sebagai persyaratan administrasi <strong>{surat.keperluan || '-'}</strong>.
                    </p>
                    <p className="text-justify leading-relaxed indent-8 mb-6 mt-4">
                      Demikian surat keterangan ini dibuat dengan sebenarnya untuk dapat dipergunakan sebagaimana mestinya.
                    </p>
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              } else if (code === 'SKL') {
                return (
                  <>
                    <p className="text-justify leading-relaxed indent-8 mb-2">
                      Yang bertanda tangan di bawah ini Kepala {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')}, menerangkan bahwa dari pasangan warga kami telah lahir seorang anak dengan identitas kependudukan terlampir di bawah ini. Adapun orang tua anak tersebut adalah:
                    </p>
                    <DataPenduduk />
                    {penutup(surat.keperluan, 'Kelahiran')}
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              } else if (code === 'SPH') {
                return (
                  <>
                    {pembuka}
                    <DataPenduduk />
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Nama tersebut di atas adalah benar-benar penduduk Desa {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')}, yang mana yang bersangkutan mengajukan permohonan pindah domisili dengan rincian sebagai berikut:
                    </p>
                    <table className="w-[calc(100%-40px)] border-collapse mb-2 ml-10 text-[14px]" style={{lineHeight: 1.3}}>
                      <tbody>
                        <tr><td style={{width: '30%'}}>Tanggal Pindah</td><td style={{width: '3%'}}>:</td><td>{fmtDate(sd.tanggalPindah)}</td></tr>
                        <tr><td>Alasan Pindah</td><td>:</td><td>{sd.alasanPindah || '-'}</td></tr>
                        <tr><td style={{verticalAlign: 'top'}}>Alamat Tujuan</td><td style={{verticalAlign: 'top'}}>:</td><td>{sd.alamatTujuan || '-'} RT.{sd.rtTujuan || '-'} RW.{sd.rwTujuan || '-'}<br/>Desa {sd.desaTujuan || '-'} Kecamatan {sd.kecamatanTujuan || '-'}<br/>Kab. {sd.kabupatenTujuan || '-'} Prov. {sd.provinsiTujuan || '-'}</td></tr>
                      </tbody>
                    </table>
                    {penutup(surat.keperluan, 'Pengantar Pindah')}
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              } else if (code === 'SKPH') {
                return (
                  <>
                    {pembuka}
                    <DataPenduduk />
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Adalah benar nama tersebut di atas merupakan warga kami yang berdomisili sah di Desa {desaName.replace(/desa|kelurahan/gi, '').trim()}, dan berdasarkan data/pengakuan yang bersangkutan memiliki rincian penghasilan bulanan yang sah dengan rata-rata sebesar <strong>Rp {sd.penghasilan || '-'}</strong> per bulan.
                    </p>
                    {penutup(surat.keperluan, 'Penghasilan')}
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              } else if (code === 'SKN') {
                return (
                  <>
                    <p className="text-justify leading-relaxed indent-8 mb-2">
                      Yang bertanda tangan di bawah ini Kepala {desaName.replace(/desa|kelurahan/gi, '').trim()} Kecamatan {kecamatanName.replace(/^kecamatan\s+/i, '')} Kabupaten {kabupatenName.replace(/^(kabupaten|kota)\s+/i, '')}, menerangkan dengan sebenarnya bahwa:
                    </p>
                    <table className="w-[calc(100%-40px)] border-collapse mb-2 ml-10 text-[14px]" style={{lineHeight: 1.3}}>
                      <tbody>
                        <tr><td style={{width: '30%'}}>Nama Lengkap</td><td style={{width: '3%'}}>:</td><td><strong className="uppercase">{name}</strong></td></tr>
                        <tr><td>NIK</td><td>:</td><td>{nik}</td></tr>
                        <tr><td>Tempat, Tanggal lahir</td><td>:</td><td>{birthPlace}, {fmtDate(birthDate)}</td></tr>
                        <tr><td>Jenis Kelamin</td><td>:</td><td>{gender}</td></tr>
                        <tr><td>Agama</td><td>:</td><td>{sd.agama || '-'}</td></tr>
                        <tr><td>Pekerjaan</td><td>:</td><td>{sd.pekerjaan || '-'}</td></tr>
                        <tr><td>Status Perkawinan</td><td>:</td><td>{sd.statusPerkawinan || '-'}</td></tr>
                        <tr><td>Alamat</td><td>:</td><td>{address}</td></tr>
                      </tbody>
                    </table>
                    <p className="text-justify leading-relaxed indent-8 mb-2 mt-4">
                      Orang tersebut di atas adalah benar-benar warga Desa {desaName.replace(/desa|kelurahan/gi, '').trim()} yang hendak mengurus <strong>Persyaratan Pernikahan / Pengantar Nikah</strong>{sd.namaPasangan ? ` dengan pasangan bernama:` : '.'}
                    </p>
                    {sd.namaPasangan && (
                      <table className="w-[calc(100%-40px)] border-collapse mb-2 ml-10 text-[14px]" style={{lineHeight: 1.3}}>
                        <tbody>
                          <tr><td style={{width: '30%'}}>Nama Pasangan</td><td style={{width: '3%'}}>:</td><td><strong className="uppercase">{sd.namaPasangan}</strong></td></tr>
                          {sd.nikPasangan && <tr><td>NIK Pasangan</td><td>:</td><td>{sd.nikPasangan}</td></tr>}
                          {sd.tanggalNikah && <tr><td>Rencana Tgl Nikah</td><td>:</td><td>{fmtDate(sd.tanggalNikah)}</td></tr>}
                        </tbody>
                      </table>
                    )}
                    {penutup(surat.keperluan || 'Persyaratan Nikah', 'Pengantar Nikah')}
                    {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                  </>
                );
              }

              return (
                <>
                  {pembuka}
                  <DataPenduduk />
                  {penutup(surat.keperluan, surat.jenis)}
                  {renderReactSignature(desaName, surat.tanggal, namaKades, 'Kepala Desa', (() => { try { const ol = JSON.parse(localStorage.getItem('village_officers') || '[]'); return ol.find((o: any) => o.name === namaKades)?.nip || '-'; } catch(e) { return '-'; } })(), sd.includeCamat)}
                </>
              );
            })()}
          </div>
        )}
      </div>
    );
  };

  return (
    <div id="admin-surat-dashboard-root" className="space-y-6">
      {/* Legacy single printing style removed since useReactToPrint is now used */}

      {/* Dynamic table landscape printing stylesheet */}
      {isPrintingTable && (
        <style type="text/css" media="print">
          {`
            @media print {
              @page { 
                size: A4 landscape; 
                margin: 20mm 20mm 18mm 20mm !important;
              }
              /* 1. Hide sidebar, header, non-print elements */
              aside, header, .no-print, [role="navigation"], .admin-sidebar, .admin-header, footer, .tour-container, #hubungi-bantuan-btn {
                display: none !important;
              }
              
              /* 2. Hide everything except printable table area */
              #admin-surat-dashboard-root > *:not(.printable-table-area) {
                display: none !important;
              }

              /* 3. Strip layout constraints dari semua ancestor */
              html, body, #root, 
              #root > div, 
              #root > div > div, 
              main, 
              main > div, 
              main > div > div,
              .max-w-6xl,
              #admin-surat-dashboard-root {
                position: static !important;
                overflow: visible !important;
                margin: 0 !important;
                padding: 0 !important;
                height: auto !important;
                min-height: 0 !important;
                background: transparent !important;
                box-shadow: none !important;
              }

              body {
                margin: 0 !important;
                padding: 0 !important;
                background-color: white !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
              
              body * {
                visibility: hidden !important;
              }
              
              .printable-table-area, .printable-table-area * {
                visibility: visible !important;
              }
              .nomor-surat-cetak { text-transform: uppercase !important; }
              
              /* Padding dalam area cetak agar tabel tidak mepet tepi */
              .printable-table-area {
                position: static !important;
                display: block !important;
                width: 100% !important;
                height: auto !important;
                min-height: 0 !important;
                margin: 0 !important;
                padding: 8mm 12mm 16mm 12mm !important;
                box-sizing: border-box !important;
                background-color: white !important;
                box-shadow: none !important;
                border: none !important;
                border-radius: 0 !important;
              }
              .printable-table-content {
                overflow: visible !important;
                width: 100% !important;
              }
              table {
                width: 100% !important;
                border-collapse: collapse !important;
                font-size: 10.5px !important;
                margin-top: 12px !important;
              }
              thead {
                display: table-header-group !important;
              }
              th, td {
                border: 1px solid #cbd5e1 !important;
                padding: 7px 10px !important;
                text-align: left !important;
                color: #1e293b !important;
              }
              th {
                background-color: #f8fafc !important;
                font-weight: 700 !important;
                color: #0f172a !important;
                border-bottom: 2px solid #94a3b8 !important;
              }
              tr {
                page-break-inside: avoid !important;
              }
              .print\\:hidden {
                display: none !important;
              }

              /* ── Global Footer: 1 garis pemisah + 1 baris teks, pojok kiri bawah ── */
              #global-print-footer {
                display: block !important;
                position: fixed !important;
                bottom: 4mm !important;
                left: 20mm !important;
                right: 20mm !important;
                visibility: visible !important;
                text-align: left !important;
                font-size: 7pt !important;
                color: #94a3b8 !important;
                z-index: 9999 !important;
                padding-top: 0 !important;
                background: white !important;
                white-space: nowrap !important;
                overflow: hidden !important;
                text-overflow: ellipsis !important;
                line-height: 1.4 !important;
              }
              #global-print-footer * {
                visibility: visible !important;
                text-align: left !important;
                color: #94a3b8 !important;
                font-size: 7pt !important;
                white-space: nowrap !important;
              }
              /* Sembunyikan elemen footer kecuali baris pertama */
              #global-print-footer > *:not(:first-child) {
                display: none !important;
              }
            }
            @media screen {
              #global-print-footer {
                display: none !important;
              }
            }
          `}
        </style>
      )}

      {showPrintWarning && (
        <div className="p-4 mb-4 bg-yellow-50 border border-yellow-200 rounded-xl text-sm text-yellow-800 flex items-center justify-between">
          <span><span className="font-bold">Perhatian:</span> Fitur cetak mungkin diblokir oleh browser saat di dalam mode preview. Untuk mencetak, silakan buka aplikasi ini di tab baru (Open in New Tab).</span>
          <button onClick={() => setShowPrintWarning(false)} className="text-yellow-600 hover:text-yellow-800 font-bold px-2">&times;</button>
        </div>
      )}

      {/* Header */}
      <div className="sticky top-16 z-40 bg-slate-50/60 dark:bg-slate-900/80 backdrop-blur-xl pb-4 -mx-4 -mt-4 px-4 pt-4 md:-mx-6 md:-mt-6 md:px-6 md:pt-6 lg:-mx-8 lg:-mt-8 lg:px-8 lg:pt-8 border-b border-slate-200/50 dark:border-slate-700/50 flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Arsip Surat</h2>
          <p className="text-sm text-gray-500 dark:text-slate-400 mt-1">Kelola dan lihat riwayat surat yang telah diterbitkan.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button 
            onClick={handleExportExcel}
            className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-slate-300 px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm dark:shadow-none hover:bg-gray-50 dark:hover:bg-slate-800 transition-all flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Excel
          </button>
          <button 
            onClick={() => setShowPrintModal(true)}
            className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-slate-300 px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm dark:shadow-none hover:bg-gray-50 dark:hover:bg-slate-800 transition-all flex items-center gap-2"
          >
            <Printer className="w-4 h-4" />
            Cetak Daftar
          </button>
          <div className="relative" ref={quickActionRef}>
            <button 
              onClick={() => setShowQuickActions(!showQuickActions)}
              className="bg-emerald-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-sm dark:shadow-none hover:bg-emerald-800 transition-all flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Buat / Input Baru
              <ChevronDown className={`w-4 h-4 transition-transform ${showQuickActions ? 'rotate-180' : ''}`} />
            </button>

            {showQuickActions && (
              <div className="absolute right-0 top-full mt-2 w-72 shadow-lg border border-slate-100 rounded-xl bg-white p-1.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                <button
                  onClick={() => { setShowQuickActions(false); onBuatSurat(); }}
                  className="w-full p-2.5 hover:bg-slate-50 rounded-xl transition-colors flex items-center gap-3 cursor-pointer text-left"
                >
                  <span className="p-2 rounded-lg bg-emerald-50 border border-emerald-100">
                    <FileText className="w-5 h-5 text-emerald-600" />
                  </span>
                  <span>
                    <span className="block text-sm font-medium text-slate-800">Buat Surat Langsung</span>
                    <span className="block text-xs text-slate-500 mt-0.5">Buka katalog template surat resmi</span>
                  </span>
                </button>
                <button
                  onClick={() => { setShowQuickActions(false); onOpenBatch?.(); }}
                  className="w-full p-2.5 hover:bg-slate-50 rounded-xl transition-colors flex items-center gap-3 cursor-pointer text-left"
                >
                  <span className="p-2 rounded-lg bg-amber-50 border border-amber-100">
                    <Users className="w-5 h-5 text-amber-600" />
                  </span>
                  <span>
                    <span className="block text-sm font-medium text-slate-800">Buat Surat Masal</span>
                    <span className="block text-xs text-slate-500 mt-0.5">SKTM / SKU / Domisili untuk banyak warga sekaligus</span>
                  </span>
                </button>
                <button
                  onClick={() => { setShowQuickActions(false); onOpenTambahPermohonan?.(); }}
                  className="w-full p-2.5 hover:bg-slate-50 rounded-xl transition-colors flex items-center gap-3 cursor-pointer text-left"
                >
                  <span className="p-2 rounded-lg bg-blue-50 border border-blue-100">
                    <Inbox className="w-5 h-5 text-blue-600" />
                  </span>
                  <span>
                    <span className="block text-sm font-medium text-slate-800">Tambah Permohonan (Bantuan Admin)</span>
                    <span className="block text-xs text-slate-500 mt-0.5">Input permohonan warga ke Inbox / Kiosk</span>
                  </span>
                </button>
                <button
                  onClick={() => { setShowQuickActions(false); onOpenTambahTamu?.(); }}
                  className="w-full p-2.5 hover:bg-slate-50 rounded-xl transition-colors flex items-center gap-3 cursor-pointer text-left"
                >
                  <span className="p-2 rounded-lg bg-purple-50 border border-purple-100">
                    <BookOpen className="w-5 h-5 text-purple-600" />
                  </span>
                  <span>
                    <span className="block text-sm font-medium text-slate-800">Catat Buku Tamu</span>
                    <span className="block text-xs text-slate-500 mt-0.5">Input entri kehadiran tamu baru</span>
                  </span>
                </button>
                <button
                  onClick={() => { setShowQuickActions(false); setShowCatatLuar(true); }}
                  className="w-full p-2.5 hover:bg-slate-50 rounded-xl transition-colors flex items-center gap-3 cursor-pointer text-left"
                >
                  <span className="p-2 rounded-lg bg-amber-50 border border-amber-100">
                    <ClipboardCheck className="w-5 h-5 text-amber-600" />
                  </span>
                  <span>
                    <span className="block text-sm font-medium text-slate-800">Catat Surat Luar</span>
                    <span className="block text-xs text-slate-500 mt-0.5">Pencatatan surat fisik di luar web</span>
                  </span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-96">
          <input 
            type="text" 
            placeholder="Cari nomor surat atau nama..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm outline-none transition-all"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <select 
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 text-sm font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 flex-1 md:flex-none cursor-pointer"
          >
            <option value="">Semua Jenis Surat</option>
            <option value="domisili">Domisili</option>
            <option value="sktm">SKTM</option>
            <option value="sku">Keterangan Usaha</option>
            <option value="skph">Keterangan Penghasilan</option>
            <option value="spt">Pengurusan Taspen (SPT)</option>
            <option value="sppd">Perjalanan Dinas (SPPD)</option>
          </select>
          <button 
            onClick={() => {
              setSearchQuery('');
              setSelectedType('');
            }}
            className={`p-2.5 border rounded-xl transition-colors ${
              searchQuery || selectedType
                ? 'border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                : 'border-gray-200 dark:border-slate-700 text-gray-600 dark:text-slate-400 hover:bg-gray-50 dark:hover:bg-slate-800 bg-white dark:bg-slate-900'
            }`}
            title="Reset Pencarian & Filter"
          >
            {searchQuery || selectedType ? (
              <Filter className="w-4 h-4" />
            ) : (
              <FilterX className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>

      {/* Bulk Delete Action Banner */}
      {selectedSuratIds.length > 0 && (
        <div className="bg-red-50 border border-red-200 p-4 rounded-2xl flex items-center justify-between animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-4">
            <span className="text-sm font-semibold text-red-800">
              {selectedSuratIds.length} surat terpilih
            </span>
            <button 
              onClick={() => setSelectedSuratIds([])}
              className="text-xs text-red-600 hover:underline font-bold"
            >
              Batal Pilihan
            </button>
          </div>
          <button 
            onClick={() => setShowBulkDeleteModal(true)}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm dark:shadow-none transition-all"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Hapus Masal
          </button>
        </div>
      )}

      {showPrintModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full shadow-2xl overflow-hidden animate-in zoom-in-95">
            <div className="px-6 py-4 border-b border-gray-100 dark:border-slate-800 flex items-center justify-between">
              <h3 className="font-bold text-gray-900 dark:text-white">Cetak Daftar Arsip</h3>
              <button onClick={() => setShowPrintModal(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="text-sm font-bold text-gray-700 dark:text-slate-300 block mb-1.5">Dari Tanggal</label>
                <input type="date" value={printStartDate} onChange={(e) => setPrintStartDate(e.target.value)} className="w-full px-4 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" />
              </div>
              <div>
                <label className="text-sm font-bold text-gray-700 dark:text-slate-300 block mb-1.5">Sampai Tanggal</label>
                <input type="date" value={printEndDate} onChange={(e) => setPrintEndDate(e.target.value)} className="w-full px-4 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" />
              </div>
              <p className="text-xs text-gray-500 dark:text-slate-400">* Kosongkan tanggal jika ingin mencetak semua data.</p>
            </div>

            {/* Panduan Cetak Singkat */}
            <div className="mx-6 mb-4 bg-blue-50 border border-blue-100 rounded-xl p-4">
              <div className="flex items-start gap-2.5">
                <span className="text-blue-500 mt-0.5 text-base">💡</span>
                <div>
                  <p className="text-xs font-bold text-blue-700 mb-2">Tips untuk Hasil Cetak Terbaik</p>
                  <ol className="text-xs text-blue-600 space-y-1.5 list-none">
                    <li className="flex items-start gap-2">
                      <span className="bg-blue-200 text-blue-700 rounded-full w-4 h-4 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">1</span>
                      <span>Gunakan browser <strong>Google Chrome</strong> atau <strong>Microsoft Edge</strong></span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="bg-blue-200 text-blue-700 rounded-full w-4 h-4 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">2</span>
                      <span>Pilih ukuran kertas <strong>A4</strong> di dialog cetak</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="bg-blue-200 text-blue-700 rounded-full w-4 h-4 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">3</span>
                      <span>Aktifkan <strong>Background graphics</strong> agar warna header tercetak</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="bg-blue-200 text-blue-700 rounded-full w-4 h-4 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">4</span>
                      <span>Cetak dari <strong>laptop/PC</strong> untuk hasil terbaik</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>

            <div className="px-6 py-4 bg-gray-50 dark:bg-slate-800 flex justify-end gap-3">
              <button onClick={() => setShowPrintModal(false)} className="px-4 py-2 text-gray-600 dark:text-slate-400 font-bold hover:bg-gray-100 dark:hover:bg-slate-700 rounded-xl">Batal</button>
              <button onClick={handlePrintAll} className="px-4 py-2 bg-emerald-600 text-white font-bold rounded-xl flex items-center gap-2 shadow-sm dark:shadow-none">
                <Printer className="w-4 h-4" /> Cetak Sekarang
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Table */}
      <div ref={componentRef} className={`bg-white dark:bg-slate-900 rounded-2xl shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 overflow-hidden ${isPrintingTable ? 'printable-table-area' : ''}`}>
        <div className={`overflow-x-auto ${isPrintingTable ? 'printable-table-content' : ''}`}>
          {/* Official Kop Surat on printed list */}
          {isPrintingTable && (
            <div className="hidden print:block mb-8 text-center text-black">
              <h1 className="text-xl font-black tracking-wider uppercase text-black">
                DAFTAR NOMOR SURAT
              </h1>
              <p className="text-sm font-bold uppercase tracking-wide text-gray-800 dark:text-slate-100 mt-1">
                DESA {kopSettings.desa.toUpperCase()}
              </p>
              <p className="text-xs font-semibold uppercase tracking-wide text-gray-600 dark:text-slate-400 mt-0.5 border-b-2 border-black pb-4 inline-block w-full">
                KECAMATAN {kopSettings.kecamatan.toUpperCase()}
              </p>
            </div>
          )}
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50/50 dark:bg-slate-800/50 border-b border-gray-100 dark:border-slate-700">
                <th className="px-3 py-2 w-10 text-center print:hidden">
                  <input 
                    type="checkbox"
                    className="rounded border-gray-300 dark:border-slate-600 text-emerald-600 focus:ring-emerald-500 cursor-pointer h-4 w-4"
                    checked={filteredSurat.length > 0 && filteredSurat.every(s => selectedSuratIds.includes(s.id))}
                    onChange={(e) => {
                      if (e.target.checked) {
                        const newIds = filteredSurat.map(s => s.id);
                        setSelectedSuratIds(prev => Array.from(new Set([...prev, ...newIds])));
                      } else {
                        const filteredIds = filteredSurat.map(s => s.id);
                        setSelectedSuratIds(prev => prev.filter(id => !filteredIds.includes(id)));
                      }
                    }}
                  />
                </th>
                <th className="px-3 py-2 text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Nomor Surat</th>
                <th className="px-3 py-2 text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Jenis Surat</th>
                <th className="px-3 py-2 text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Pemohon</th>
                <th className="px-3 py-2 text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Keperluan</th>
                <th className="px-3 py-2 text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Tanggal</th>
                <th className="px-3 py-2 text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider text-center print:hidden">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
              {filteredSurat.length > 0 ? (
                filteredSurat.map((surat) => {
                  const isCancelled = surat.status === 'Dibatalkan';
                  return (
                  <tr key={surat.id} className={`hover:bg-gray-50/80 dark:hover:bg-slate-800/50 transition-colors group ${isCancelled ? 'opacity-70 bg-gray-50 dark:bg-slate-800' : ''}`}>
                    <td className="px-3 py-2 print:hidden text-center">
                      <input 
                        type="checkbox"
                        className="rounded border-gray-300 dark:border-slate-600 text-emerald-600 focus:ring-emerald-500 cursor-pointer h-4 w-4"
                        checked={selectedSuratIds.includes(surat.id)}
                        onChange={() => {
                          setSelectedSuratIds(prev => 
                            prev.includes(surat.id)
                              ? prev.filter(id => id !== surat.id)
                              : [...prev, surat.id]
                          );
                        }}
                      />
                    </td>
                    <td className="px-3 py-2">
                      <span className="text-sm font-bold text-gray-900 dark:text-white group-hover:text-emerald-700 transition-colors flex items-center gap-2">
                        <span className={isCancelled ? 'line-through text-gray-500 dark:text-slate-400' : 'uppercase'}>{surat.nomor.toUpperCase()}</span>
                        {isCancelled && (
                          <span className="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-semibold">DIBATALKAN</span>
                        )}
                      </span>
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-gray-400 shrink-0" />
                        <span className="text-sm font-medium text-gray-700 dark:text-slate-300 truncate max-w-[200px]" title={getFullLetterName(surat.jenis)}>{getFullLetterName(surat.jenis)}</span>
                      </div>
                    </td>
                    <td className="px-3 py-2">
                      <span className="text-sm font-medium text-gray-900 dark:text-white truncate max-w-[180px] block" title={surat.nama}>{surat.nama}</span>
                    </td>
                    <td className="px-3 py-2 text-sm text-gray-700 dark:text-slate-300 max-w-[200px] truncate" title={surat.keperluan || '-'}>
                      {surat.keperluan || '-'}
                    </td>
                    <td className="px-3 py-2 text-sm text-gray-500 dark:text-slate-400 whitespace-nowrap">
                      {surat.tanggal}
                    </td>
                    <td className="px-3 py-2 print:hidden text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button 
                          onClick={() => handleSendWaToPemohon(surat)}
                          className="p-1.5 text-emerald-600 hover:bg-emerald-50 hover:text-emerald-800 dark:hover:bg-emerald-950/40 rounded-lg transition-colors" 
                          title="Kirim Notifikasi WhatsApp ke Pemohon"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => setSelectedSurat(surat)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 hover:text-blue-800 dark:hover:bg-blue-950/40 rounded-lg transition-colors" 
                          title="Lihat Hasil Cetak Pratinjau Surat"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {!isCancelled && (
                          <>
                            <button 
                              onClick={() => onEditLetter?.(surat)}
                              className="p-1.5 text-amber-600 hover:bg-amber-50 hover:text-amber-800 rounded-lg transition-colors" 
                              title="Edit Isi Surat"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            
                            <button 
                              onClick={() => setSuratToCancel(surat)}
                              className="p-1.5 text-orange-600 hover:bg-orange-50 hover:text-orange-800 rounded-lg transition-colors" 
                              title="Batalkan Surat"
                            >
                              <Ban className="w-4 h-4" />
                            </button>
                          </>
                        )}
                        <button 
                          onClick={() => setSuratToDelete(surat)}
                          className="p-1.5 text-red-600 hover:bg-red-50 hover:text-red-800 rounded-lg transition-colors" 
                          title="Hapus Surat Dari Arsip"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );})
              ) : (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-sm text-gray-500 dark:text-slate-400">
                    Tidak ada data surat yang sesuai dengan pencarian atau filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {/* Centralized SaaS Footer for List Printing */}
        {isPrintingTable && (
          <div 
            id="global-print-footer"
            dangerouslySetInnerHTML={{ __html: SAAS_CONFIG.globalFooterHTML }}
          />
        )}
      </div>

      {/* Detail Viewer Modal */}
      {selectedSurat && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto animate-in fade-in zoom-in-95 slide-in-from-bottom-4 duration-300 ease-out">
          <div className="bg-gray-100 dark:bg-slate-800 rounded-2xl max-w-4xl w-full shadow-2xl flex flex-col max-h-[90vh] overflow-hidden border border-gray-200 dark:border-slate-700">
            {/* Header */}
            <div className="bg-white dark:bg-slate-900 px-6 py-4 border-b border-gray-200 dark:border-slate-700 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-gray-900 dark:text-white text-lg">Detail Arsip Surat</h3>
                <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Melihat dokumen resmi yang telah diterbitkan</p>
              </div>
              <button 
                onClick={() => setSelectedSurat(null)}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-xl transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

             {/* Content & Sidebar */}
            <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
              {/* Paper Preview Area */}
              <div className="flex-1 bg-gray-200/80 dark:bg-slate-900/80 p-6 overflow-auto no-scrollbar flex justify-center items-start min-h-[400px] relative">
                {/* Floating Document Zoom Controls */}
                <div className="absolute top-4 right-4 bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm border border-gray-200 dark:border-slate-700 shadow-lg dark:shadow-none rounded-xl p-1.5 flex items-center gap-1 z-30">
                  <button 
                    onClick={() => setZoomLevel(prev => Math.max(0.3, prev - 0.1))} 
                    className="p-1.5 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg text-gray-600 dark:text-slate-400 hover:text-emerald-700 transition-colors"
                    title="Perkecil (Zoom Out)"
                  >
                    <ZoomOut className="w-4.5 h-4.5" />
                  </button>
                  <span className="text-xs font-bold text-gray-700 dark:text-slate-300 min-w-[50px] text-center">
                    {Math.round(zoomLevel * 100)}%
                  </span>
                  <button 
                    onClick={() => setZoomLevel(prev => Math.min(1.5, prev + 0.1))} 
                    className="p-1.5 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg text-gray-600 dark:text-slate-400 hover:text-emerald-700 transition-colors"
                    title="Perbesar (Zoom In)"
                  >
                    <ZoomIn className="w-4.5 h-4.5" />
                  </button>
                  <div className="w-px h-4 bg-gray-200 mx-1"></div>
                  <button 
                    onClick={() => setZoomLevel(0.65)} 
                    className="px-2 py-1 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg text-[10px] font-bold text-gray-600 dark:text-slate-400 hover:text-emerald-700 transition-colors"
                    title="Sesuaikan Halaman (Fit)"
                  >
                    Fit
                  </button>
                  <button 
                    onClick={() => setZoomLevel(1.0)} 
                    className="px-2 py-1 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg text-[10px] font-bold text-gray-600 dark:text-slate-400 hover:text-emerald-700 transition-colors"
                    title="Ukuran Asli (100%)"
                  >
                    100%
                  </button>
                </div>

                <div 
                  className="bg-white dark:bg-slate-900 shadow-lg dark:shadow-none border border-gray-300 dark:border-slate-600 p-12 text-black transition-all shrink-0 origin-top relative"
                  style={{
                    width: '794px',
                    minHeight: '1123px',
                    transform: `scale(${zoomLevel})`,
                    marginBottom: `${(zoomLevel - 1) * 1123}px`,
                    marginRight: zoomLevel > 1 ? `${(zoomLevel - 1) * 794}px` : '0px',
                    marginLeft: zoomLevel > 1 ? `${(zoomLevel - 1) * 794}px` : '0px',
                  }}
                >
                  {renderLetterContent(selectedSurat, activeResident)}
                  {/* Global Print Footer */}
                  <div 
                    className="absolute bottom-[8mm] left-[15mm] right-[15mm] w-[calc(100%-30mm)]"
                    dangerouslySetInnerHTML={{ 
                      __html: SAAS_CONFIG.globalFooterHTML
                    }} 
                  />
                </div>
              </div>

              {/* Sidebar Controls */}
              <div className="w-full md:w-64 bg-white dark:bg-slate-900 p-6 border-t md:border-t-0 md:border-l border-gray-200 dark:border-slate-700 flex flex-col justify-between">
                <div className="space-y-6">
                  <div>
                    <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Metadata Surat</h4>
                    
                    {/* TTE Toggle Option */}
                    <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700 mb-4">
                      <label className="flex items-start gap-2.5 cursor-pointer text-xs font-bold text-slate-800 dark:text-slate-200">
                        <input 
                          type="checkbox" 
                          checked={useEsignature} 
                          onChange={(e) => setUseEsignature(e.target.checked)} 
                          className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 mt-0.5" 
                        />
                        <div>
                          <span className="block">Tanda Tangan Elektronik (TTE)</span>
                          <span className="text-[10px] font-normal text-slate-500 dark:text-slate-400 block mt-0.5">
                            Sertakan QR Code verifikasi resmi pada cetakan surat.
                          </span>
                        </div>
                      </label>
                    </div>

                    <div className="space-y-3 text-sm text-gray-700 dark:text-slate-300">
                      <div>
                        <span className="text-gray-400 block text-xs">Nomor Surat</span>
                        <span className="font-mono font-bold text-gray-900 dark:text-white break-all uppercase">{selectedSurat.nomor.toUpperCase()}</span>
                      </div>
                      <div>
                        <span className="text-gray-400 block text-xs">Jenis Surat</span>
                        <span className="font-semibold text-gray-900 dark:text-white">{getFullLetterName(selectedSurat.jenis)}</span>
                      </div>
                      <div>
                        <span className="text-gray-400 block text-xs">Pemohon</span>
                        <span className="font-semibold text-emerald-800">{selectedSurat.nama}</span>
                      </div>
                      {selectedSurat.nik && (
                        <div>
                          <span className="text-gray-400 block text-xs">NIK Pemohon</span>
                          <span className="font-mono text-gray-900 dark:text-white">{selectedSurat.nik}</span>
                        </div>
                      )}
                      <div>
                        <span className="text-gray-400 block text-xs">Tanggal Terbit</span>
                        <span className="text-gray-900 dark:text-white">{selectedSurat.tanggal}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 mt-6">
                  {!selectedSurat.status || selectedSurat.status !== 'Dibatalkan' ? (
                    <>
                      <button 
                        onClick={() => triggerSinglePrint(selectedSurat)}
                        className="w-full flex items-center justify-center gap-2 bg-emerald-700 text-white py-2.5 rounded-xl text-sm font-bold shadow-sm dark:shadow-none hover:bg-emerald-800 transition-all"
                      >
                        <Printer className="w-4 h-4" /> Cetak Surat
                      </button>
                      <button 
                        onClick={() => {
                          const s = selectedSurat;
                          setSelectedSurat(null);
                          onEditLetter?.(s);
                        }}
                        className="w-full flex items-center justify-center gap-2 border border-amber-300 bg-amber-50 dark:bg-amber-950/30 text-amber-800 dark:text-amber-300 hover:bg-amber-100 py-2.5 rounded-xl text-sm font-bold transition-all"
                      >
                        <Edit2 className="w-4 h-4" /> Perbaiki / Edit Surat
                      </button>
                    </>
                  ) : (
                    <div className="w-full text-center py-2.5 bg-red-50 text-red-700 rounded-xl text-sm font-bold border border-red-100">
                      Surat Dibatalkan
                    </div>
                  )}
                  <button 
                    onClick={() => setSuratToDelete(selectedSurat)}
                    className="w-full flex items-center justify-center gap-2 border border-red-200 text-red-600 hover:bg-red-50 py-2.5 rounded-xl text-sm font-bold transition-all"
                  >
                    <Trash2 className="w-4 h-4" /> Hapus Arsip
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Confirmation Modal */}
      {suratToCancel && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in zoom-in-95 slide-in-from-bottom-4 duration-300 ease-out">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-gray-100 dark:border-slate-800 text-center space-y-4">
            <div className="mx-auto w-12 h-12 rounded-full bg-orange-50 flex items-center justify-center text-orange-600">
              <Ban className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-gray-900 dark:text-white">Konfirmasi Batalkan Surat</h3>
              <p className="text-sm text-gray-500 dark:text-slate-400 mt-1 leading-relaxed">
                Apakah Anda yakin ingin membatalkan surat nomor <span className="font-mono font-bold text-orange-600 break-all uppercase">{suratToCancel.nomor.toUpperCase()}</span>? Surat akan tetap tercatat di arsip namun tidak dapat diedit atau dicetak lagi.
              </p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => setSuratToCancel(null)}
                className="flex-1 py-2.5 border border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-800 rounded-xl text-sm font-bold text-gray-700 dark:text-slate-300 transition-all"
              >
                Kembali
              </button>
              <button 
                onClick={() => suratToCancel && handleCancel(suratToCancel)}
                className="flex-1 py-2.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-sm font-bold shadow-sm dark:shadow-none transition-all"
              >
                Ya, Batalkan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {suratToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in zoom-in-95 slide-in-from-bottom-4 duration-300 ease-out">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-gray-100 dark:border-slate-800 text-center space-y-4">
            <div className="mx-auto w-12 h-12 rounded-full bg-red-50 flex items-center justify-center text-red-600">
              <Trash2 className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold text-gray-900 dark:text-white">Konfirmasi Hapus Arsip Surat</h3>
              <p className="text-sm text-gray-500 dark:text-slate-400 mt-1 leading-relaxed">
                Apakah Anda yakin ingin menghapus arsip surat nomor <span className="font-mono font-bold text-red-600 break-all uppercase">{suratToDelete.nomor.toUpperCase()}</span>? Tindakan ini bersifat permanen dan tidak dapat dibatalkan.
              </p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => setSuratToDelete(null)}
                className="flex-1 py-2.5 border border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-800 rounded-xl text-sm font-bold text-gray-700 dark:text-slate-300 transition-all"
              >
                Batal
              </button>
              <button 
                onClick={() => suratToDelete && handleDelete(suratToDelete)}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-bold shadow-sm dark:shadow-none transition-all"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Delete Confirmation Modal */}
      {showBulkDeleteModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in zoom-in-95 slide-in-from-bottom-4 duration-300 ease-out">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-gray-100 dark:border-slate-800 text-center space-y-4">
            <div className="mx-auto w-12 h-12 rounded-full bg-red-50 flex items-center justify-center text-red-600">
              <Trash2 className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold text-gray-900 dark:text-white">Konfirmasi Hapus Masal</h3>
              <p className="text-sm text-gray-500 dark:text-slate-400 mt-1 leading-relaxed">
                Apakah Anda yakin ingin menghapus <span className="font-bold text-red-600">{selectedSuratIds.length}</span> arsip surat yang terpilih? Tindakan ini bersifat permanen dan tidak dapat dibatalkan.
              </p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => setShowBulkDeleteModal(false)}
                className="flex-1 py-2.5 border border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-800 rounded-xl text-sm font-bold text-gray-700 dark:text-slate-300 transition-all"
              >
                Batal
              </button>
              <button 
                onClick={handleBulkDelete}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-bold shadow-sm dark:shadow-none transition-all"
              >
                Ya, Hapus Masal
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Hidden print container for printing a single letter in full resolution */}
      {selectedSurat && (
        <div ref={singlePrintRef} id="single-letter-print-container-wrapper" className="hidden print:block bg-white dark:bg-slate-900 text-black p-12 printable-area" style={{ fontFamily: 'Arial, Helvetica, sans-serif', width: '794px', minHeight: '1123px' }}>
          {renderLetterContent(selectedSurat, activeResident)}
          <div 
            id="global-print-footer"
            dangerouslySetInnerHTML={{ __html: SAAS_CONFIG.globalFooterHTML }}
          />
        </div>
      )}

      {/* Modal Input No. WA On-The-Fly dari Kolom Aksi */}
      <WANumberInputModal
        open={waInputOpen}
        onClose={() => setWaInputOpen(false)}
        residentName={waTargetSurat?.nama}
        residentNik={waTargetSurat?.nik}
        message={waInputMessage}
      />

      {/* Modal Catat Surat Luar */}
      {showCatatLuar && (
        <AdminSuratCatatLuar
          onClose={() => setShowCatatLuar(false)}
          onSuccess={() => fetchLetterHistoryAsync().then(setSuratList)}
        />
      )}

    </div>
  );
}
