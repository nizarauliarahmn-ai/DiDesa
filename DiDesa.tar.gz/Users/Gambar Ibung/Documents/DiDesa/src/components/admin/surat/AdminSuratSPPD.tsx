import SuratEditorHeader, { getLetterHeaderTemplate } from './SuratEditorHeader';
import { useBackdateNumber } from '../../../hooks/useBackdateNumber';
import BackdateConfig from './BackdateConfig';
import React, { useState, useEffect, useRef, Component } from 'react';
import { Printer, Plus, Trash2, Search, ZoomIn, ZoomOut, FileText, Upload, Loader2, Plane } from 'lucide-react';
import { showToast } from '../../../utils/toast';
import { parseInvitationPdf, getActiveTenantId } from '../../../utils/aiChat';
import { fetchResidentsCached } from '../../../utils/apiCache';
import { useLetterKode } from '../../../hooks/useLetterKode';
import { generateKopSuratHTML } from '../../../utils/letterFormat';
import { getLetterClassifications, generateLetterNumberAsync } from '../../../utils/letterClassifications';
import { addLetterHistory, updateLetterHistory } from '../../../utils/letterHistory';
import { SAAS_CONFIG } from './AdminSuratMasterTemplate';
import { getPrintSignatureHTML } from '../../../utils/signature';
import { useDragScroll } from '../../../hooks/useDragScroll';
import QuickAddResidentModal from '../penduduk/QuickAddResidentModal';
// Error Boundary to catch and display any rendering errors
class SPPDErrorBoundary extends Component<{children: React.ReactNode, onBack: () => void}, {hasError: boolean, error: any}> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }
  componentDidCatch(error: any, info: any) {
    console.error('SPPD Error:', error, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{padding: 40, fontFamily: 'monospace'}}>
          <h2 style={{color: 'red'}}>⚠️ Error pada halaman SPPD</h2>
          <pre style={{background: '#fee', padding: 20, borderRadius: 8, whiteSpace: 'pre-wrap', wordBreak: 'break-all'}}>
            {String(this.state.error?.message || this.state.error)}
          </pre>
          <pre style={{background: '#fff3cd', padding: 20, borderRadius: 8, whiteSpace: 'pre-wrap', wordBreak: 'break-all', marginTop: 10}}>
            {String(this.state.error?.stack || '')}
          </pre>
          <button onClick={this.props.onBack} style={{marginTop: 20, padding: '10px 20px', background: '#059669', color: 'white', border: 'none', borderRadius: 8, cursor: 'pointer'}}>← Kembali</button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function AdminSuratSPPD({ onBack, editData, editLetterId }: { onBack: () => void, editData?: any, editLetterId?: string | null }) {
  return (
    <SPPDErrorBoundary onBack={onBack}>
      <AdminSuratSPPDInner onBack={onBack} editData={editData} editLetterId={editLetterId} />
    </SPPDErrorBoundary>
  );
}

function AdminSuratSPPDInner({ onBack, editData, editLetterId }: { onBack: () => void, editData?: any, editLetterId?: string | null }) {
  const [showQuickAddModal, setShowQuickAddModal] = useState(false);
  const [quickAddInitialData, setQuickAddInitialData] = useState<{nik?: string, name?: string}>({});
  const [tanggalSurat, setTanggalSurat] = useState(new Date().toISOString().split('T')[0]);
  const backdateKlas = getLetterClassifications().find(c => c.klasifikasi === 'SPPD') || { klasifikasi: 'SPPD', kodeKlasifikasi: '094' };
  const kodeKlasifikasiSPPD = backdateKlas.kodeKlasifikasi || '094';
  const { isBackdate, setIsBackdate } = useBackdateNumber(tanggalSurat, backdateKlas.klasifikasi, backdateKlas.kodeKlasifikasi);
  const [manualSequence, setManualSequence] = useState('');

  const handleCustomNomorSurat = (nomor: string) => {
    setNomorSurat(nomor);
  };

  const [isSaving, setIsSaving] = useState(false);
  const [hasRecorded, setHasRecorded] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [zoomLevel, setZoomLevel] = useState(0.45);
  const [officers, setOfficers] = useState<any[]>([]);

  // Desa Settings
  const [desaName, setDesaName] = useState(() => localStorage.getItem('kop_desa') || 'Wasah Hilir');
  // PDF AI autofill state
  const [showPdfUpload, setShowPdfUpload] = useState(false);
  const [pdfAnalyzing, setPdfAnalyzing] = useState(false);
  const [pdfFileName, setPdfFileName] = useState('');
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const [namaKades, setNamaKades] = useState(() => localStorage.getItem('kop_kades') || '');
  const [roleKades, setRoleKades] = useState('Kepala Desa');
  const [nipKades, setNipKades] = useState('');
  const [useEsignature, setUseEsignature] = useState(true);

  // SPPD State
  const classifications = getLetterClassifications();
  const sppdClass = classifications.find(c => c.klasifikasi === 'SPPD');
  const kodeKlasifikasiRaw = useLetterKode('SPPD');
  const kodeKlasifikasi = kodeKlasifikasiRaw || '094';
  const [nomorSurat, setNomorSurat] = useState('');
  
  // Resident Data for Search
  const [residents, setResidents] = useState<any[]>([]);
  const [activePelaksanaDropdown, setActivePelaksanaDropdown] = useState<string | null>(null);
  const [activePengikutDropdown, setActivePengikutDropdown] = useState<string | null>(null);

  useEffect(() => {
    fetchResidentsCached()
      .then(res => { if (!res.ok) throw new Error(); return res.json(); })
      .then(data => {
        if (Array.isArray(data)) setResidents(data);
      })
      .catch(err => console.error("Failed to load residents for SPPD:", err));
      
    const officersList = JSON.parse(localStorage.getItem('village_officers') || '[]');
    setOfficers(officersList);
  }, []);

  // Daftar Pelaksana Perjalanan Dinas & Pengikut
  const [pelaksanaList, setPelaksanaList] = useState<any[]>(() => {
    if (editData?.pelaksanaList) return editData.pelaksanaList;
    if (editData?.namaPegawai) {
      return [{
        id: crypto.randomUUID(),
        nama: editData.namaPegawai,
        nip: editData.nipPegawai || '',
        pangkat: editData.pangkatGolongan || '',
        jabatan: editData.jabatanPegawai || '',
        pengikutList: editData.pengikut || []
      }];
    }
    return [{ id: crypto.randomUUID(), nama: '', nip: '', pangkat: '', jabatan: '', pengikutList: [] }];
  });

  const [activePreviewTab, setActivePreviewTab] = useState('surattugas');

  // Dasar & Pelaporan
  const [dasarPenugasan, setDasarPenugasan] = useState(editData?.dasarPenugasan || 'surat undangan dengan nomor surat: ........ tanggal ........');
  const [isDasarManual, setIsDasarManual] = useState(() => {
    if (!editData) return false;
    return editData.dasarPenugasan && !editData.dasarPenugasan.startsWith('surat undangan');
  });
  const [dasarNo, setDasarNo] = useState('');
  const [dasarTgl, setDasarTgl] = useState('');
  const [namaPPTK, setNamaPPTK] = useState(editData?.namaPPTK || '');
  const [kepadaYth, setKepadaYth] = useState(editData?.kepadaYth || `Kepala Desa`);

  // Detail Perjalanan
  const [maksudPerjalanan, setMaksudPerjalanan] = useState(editData?.maksudPerjalanan || '');
  const [alatAngkut, setAlatAngkut] = useState(editData?.alatAngkut || '');
  const [tempatBerangkat, setTempatBerangkat] = useState(() => editData?.tempatBerangkat || localStorage.getItem('kop_desa') || 'Wasah Hilir');
  const [tempatTujuan, setTempatTujuan] = useState(editData?.tempatTujuan || '');
  const [lamaPerjalanan, setLamaPerjalanan] = useState(editData?.lamaPerjalanan || '1 (Satu) Hari');
  const [tanggalBerangkat, setTanggalBerangkat] = useState(editData?.tanggalBerangkat || '');
  const [tanggalKembali, setTanggalKembali] = useState(editData?.tanggalKembali || '');
  
  // Anggaran
  const [bebanAnggaran, setBebanAnggaran] = useState(editData?.bebanAnggaran || 'APBDes');
  const [mataAnggaran, setMataAnggaran] = useState(editData?.mataAnggaran || '');


  const [printLayout, setPrintLayout] = useState('surattugas');

  const dragProps = useDragScroll();

  useEffect(() => {
    const activeDesa = localStorage.getItem('kop_desa') || 'Wasah Hilir';
    setDesaName(activeDesa);
    setNamaKades(localStorage.getItem('kop_kades') || '');
    setRoleKades('Kepala Desa');
    
    const officersList = JSON.parse(localStorage.getItem('village_officers') || '[]');
    const activeKades = localStorage.getItem('kop_kades');
    const found = officersList.find((o: any) => o.name === activeKades);
    setNipKades(found?.nip || '');

    if (editData?.nomorSurat) {
      setNomorSurat(editData.nomorSurat);
    } else {
      generateLetterNumberAsync('SPPD', kodeKlasifikasi || '094')
        .then(setNomorSurat)
        .catch(err => console.error('Gagal generate nomor surat:', err));
    }
  }, [editData, kodeKlasifikasi]);

  const angkaTerbilang = (angka: number): string => {
    const words = ["", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan", "Sembilan", "Sepuluh", "Sebelas"];
    if (angka < 12) return words[angka];
    if (angka < 20) return words[angka - 10] + " Belas";
    if (angka < 100) return words[Math.floor(angka / 10)] + " Puluh " + (angka % 10 !== 0 ? words[angka % 10] : "");
    return angka.toString();
  };

  useEffect(() => {
    if (tanggalBerangkat && tanggalKembali) {
      const start = new Date(tanggalBerangkat);
      const end = new Date(tanggalKembali);
      const diffTime = end.getTime() - start.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
      if (diffDays > 0) {
        setLamaPerjalanan(`${diffDays} (${angkaTerbilang(diffDays).trim()}) Hari`);
      }
    }
  }, [tanggalBerangkat, tanggalKembali]);

  const handlePrint = () => {
    if (iframeRef.current && iframeRef.current.contentWindow) {
      iframeRef.current.focus();
      iframeRef.current.contentWindow.print();
    }
  };

  const handlePrintAll = () => {
    const savedLayout = printLayout;
    setPrintLayout('semua');
    setTimeout(() => {
      if (iframeRef.current && iframeRef.current.contentWindow) {
        iframeRef.current.focus();
        iframeRef.current.contentWindow.print();
      }
      setTimeout(() => setPrintLayout(savedLayout), 500);
    }, 300);
  };

  const handleRecord = () => {
    if (!nomorSurat) {
      showToast('Nomor surat wajib diisi', 'error');
      return;
    }
    if (isBackdate && !(manualSequence || '').trim()) {
      showToast('Mohon isi nomor urut surat sisipan.', 'error');
      return;
    }
    
    setIsSaving(true);
    try {
      const formDataPayload = {
        klasifikasi: 'SPPD',
        nomorSurat: nomorSurat,
        tanggal: isBackdate ? new Date(tanggalSurat).toISOString() : new Date().toISOString(),
        pemohon: pelaksanaList[0]?.nama || 'Pelaksana',
        nikPemohon: pelaksanaList[0]?.nip || '-',
        pelaksanaList,
        maksudPerjalanan,
        alatAngkut,
        tempatBerangkat,
        tempatTujuan,
        lamaPerjalanan,
        tanggalBerangkat,
        tanggalKembali,
        bebanAnggaran,
        mataAnggaran,
        dasarPenugasan,
        namaPPTK,
        kepadaYth
      };

      const payload = {
        jenis: 'SPPD',
        nomor: nomorSurat,
        nama: pelaksanaList[0]?.nama || 'Pelaksana',
        nik: pelaksanaList[0]?.nip || '-',
        tanggal: isBackdate ? new Date(tanggalSurat).toISOString() : new Date().toISOString(),
        status: 'Selesai' as const,
        keperluan: maksudPerjalanan || 'Perjalanan Dinas',
        data: formDataPayload
      };

      if (editLetterId) {
        updateLetterHistory(editLetterId, payload);
        showToast('Surat SPPD berhasil diperbarui!', 'success');
      } else {
        addLetterHistory(payload);
        showToast('Surat SPPD berhasil dicatat!', 'success');
      }
      setHasRecorded(true);
    } catch (e) {
      showToast('Gagal mencatat surat', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const addPelaksana = () => {
    setPelaksanaList([...pelaksanaList, { id: crypto.randomUUID(), nama: '', nip: '', pangkat: '', jabatan: '', pengikutList: [] }]);
  };

  const removePelaksana = (id: string) => {
    setPelaksanaList(pelaksanaList.filter(p => p.id !== id));
    if (activePreviewTab === id) setActivePreviewTab('surattugas');
  };

  const handlePelaksanaChange = (id: string, field: string, value: string) => {
    setPelaksanaList(prev => prev.map(p => p.id === id ? { ...p, [field]: value } : p));
  };

  const addPengikutToPelaksana = (pelaksanaId: string) => {
    setPelaksanaList(pelaksanaList.map(p => {
      if (p.id === pelaksanaId) {
        if (p.pengikutList.length >= 5) return p;
        return { ...p, pengikutList: [...p.pengikutList, { nama: '', umur: '', keterangan: '' }] };
      }
      return p;
    }));
  };

  const removePengikutFromPelaksana = (pelaksanaId: string, pengikutIndex: number) => {
    setPelaksanaList(pelaksanaList.map(p => {
      if (p.id === pelaksanaId) {
        return { ...p, pengikutList: p.pengikutList.filter((_: any, i: number) => i !== pengikutIndex) };
      }
      return p;
    }));
  };

  const handlePengikutChange = (pelaksanaId: string, pengikutIndex: number, field: string, value: string) => {
    setPelaksanaList(prev => prev.map(p => {
      if (p.id === pelaksanaId) {
        const newPengikut = [...p.pengikutList];
        newPengikut[pengikutIndex] = { ...newPengikut[pengikutIndex], [field]: value };
        return { ...p, pengikutList: newPengikut };
      }
      return p;
    }));
  };

  // ─── AI PDF AUTOFILL ───
  const handlePdfUpload = async (file: File) => {
    if (!file || file.type !== 'application/pdf') {
      showToast('Hanya file PDF yang diterima.', 'error');
      return;
    }

    // Ambil tenant aktif — pola sama dengan komponen AI lain
    const tenantId = getActiveTenantId();

    setPdfFileName(file.name);
    setPdfAnalyzing(true);
    showToast('DiDesa AI sedang membaca dokumen PDF surat undangan...', 'info');

    try {
      // Kirim ke endpoint khusus /api/ai/parse-invitation — Gemini membaca PDF di server
      const parsed = await parseInvitationPdf(file, { tenantId });

      const dataKeys = ['nomorSuratUndangan', 'maksudPerjalanan', 'tempatTujuan', 'tanggalBerangkat', 'tanggalKembali', 'instansiPengundang'];
      const hasData = dataKeys.some(k => (parsed as any)[k] && String((parsed as any)[k]).trim());
      if (!hasData) {
        showToast('Tidak ada data SPPD yang dapat diekstrak dari PDF ini. Pastikan file adalah surat undangan yang jelas.', 'error');
        return;
      }

      if (parsed.nomorSuratUndangan) {
        setDasarNo(parsed.nomorSuratUndangan);
        setIsDasarManual(false);
      }
      if (parsed.maksudPerjalanan) setMaksudPerjalanan(parsed.maksudPerjalanan);
      if (parsed.tempatTujuan) setTempatTujuan(parsed.tempatTujuan);
      if (parsed.tanggalBerangkat) setTanggalBerangkat(parsed.tanggalBerangkat);
      if (parsed.tanggalKembali) setTanggalKembali(parsed.tanggalKembali);

      setShowPdfUpload(false);
      showToast('Data SPPD berhasil diisi otomatis dari Surat Undangan!', 'success');
    } catch (err: any) {
      console.error('AI PDF Error:', err);
      if (err && err.code === 'API_KEY_MISSING') {
        showToast('⚠️ Fitur AI Belum Aktif: API Key Google AI belum dimasukkan di Pengaturan SaaS. Silakan hubungi Admin untuk mengaktifkannya.', 'info');
      } else if (err && (err.code === 'API_KEY_INVALID' || err.code === 'QUOTA_EXCEEDED')) {
        showToast('❌ Fitur AI Tidak Dapat Digunakan: API Key tidak valid atau batas kuota harian telah tercapai.', 'error');
      } else {
        showToast('❌ Gagal Membaca Dokumen: Pastikan file yang diunggah berupa PDF Surat Undangan yang jelas.', 'error');
      }
    } finally {
      setPdfAnalyzing(false);
    }
  };

  const formatDateFull = (dateStr: string) => {

    if (!dateStr) return '';
    const date = new Date(dateStr);
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    return `${days[date.getDay()]}, ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    return `${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
  };

  useEffect(() => {
    if (!isDasarManual) {
      const tglStr = dasarTgl ? formatDate(dasarTgl) : '........';
      setDasarPenugasan(`surat undangan dengan nomor surat: ${dasarNo || '........'} tanggal ${tglStr}`);
    }
  }, [dasarNo, dasarTgl, isDasarManual]);

  const currentDateFormatted = () => {
    const d = new Date();
    const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
  };

  const generateHTML = () => {
    const activeKabupaten = localStorage.getItem('kop_kabupaten') || 'Hulu Sungai Selatan';
    const activeKecamatan = localStorage.getItem('kop_kecamatan') || 'Simpur';
    const activeDesa = localStorage.getItem('kop_desa') || 'Wasah Hilir';
    const activeAlamat = localStorage.getItem('kop_alamat') || 'Jalan Keramat RT.002 RW.001';
    const kontakKantor = localStorage.getItem('kop_kontak') || '';
    const villageLogo = localStorage.getItem('kop_logo_url') || 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Lambang_Kabupaten_Hulu_Sungai_Selatan.svg/200px-Lambang_Kabupaten_Hulu_Sungai_Selatan.svg.png';
    const isAn = (roleKades || '').toLowerCase() !== 'kepala desa';
    const cleanDesaName = activeDesa.replace(/desa|kelurahan/gi, '').trim();
    const rightRoleHtml = isAn ? `a.n. Kepala Desa ${cleanDesaName},<br/>${roleKades}` : `${roleKades}`;

    const kopSuratHTML = generateKopSuratHTML();

    const allParticipantsFlat = pelaksanaList.flatMap((p) => [
      { ...p, isLeader: true, groupId: p.id },
      ...(p.pengikutList || []).map((pg: any) => ({
        nama: pg.nama,
        jabatan: pg.keterangan || '-',
        pangkat: '-',
        nip: '-',
        isLeader: false,
        groupId: p.id
      }))
    ]); // Do not filter empty names so blank forms can be printed

    const generatePage2And3 = (participant: any) => `
          <!-- HALAMAN 2: VISUM SPPD (LANDSCAPE) -->
          <div class="page-landscape page-sppd bg-white shadow-lg mx-auto" style="${printLayout !== `sppd-${participant.groupId}` && printLayout !== 'semua' ? 'display: none;' : ''}">
            <div class="flex gap-4 h-full">
              <!-- Kiri -->
              <div class="w-[53%] pr-4">
                ${kopSuratHTML}
                
                <div class="flex justify-end text-[10px] pr-8 mb-2 mt-2">
                  <div class="grid grid-cols-[80px_10px_1fr]">
                    <span>Lembar ke</span><span>:</span><span>1</span>
                    <span>Kode Nomor</span><span>:</span><span>${kodeKlasifikasi}</span>
                    <span>Nomor</span><span>:</span><span class="uppercase">${nomorSurat.toUpperCase()}</span>
                  </div>
                </div>
                
                <div class="text-center text-[12px] mb-2">
                  <h6 class="font-bold underline uppercase text-[13px] tracking-wide">SURAT PERJALANAN DINAS</h6>
                </div>

                <table class="print-table text-[10px] mb-4">
                  <tbody>
                    <tr>
                      <td class="w-6 text-center">1</td>
                      <td class="w-[140px]">Pejabat berwenang yang memberi perintah</td>
                      <td>Kepala ${desaName}</td>
                    </tr>
                    <tr>
                      <td class="text-center">2</td>
                      <td>Nama Pegawai yang diperintah</td>
                      <td class="font-bold">${participant.nama}</td>
                    </tr>
                    <tr>
                      <td class="text-center">3</td>
                      <td>a. Pangkat dan golongan ruang<br>b. Jabatan<br>c. Tingkat menurut peraturan perjalanan</td>
                      <td>a. ${participant.pangkat}<br>b. ${participant.jabatan}<br>c. -</td>
                    </tr>
                    <tr>
                      <td class="text-center">4</td>
                      <td>Maksud perjalanan dinas</td>
                      <td>${maksudPerjalanan}</td>
                    </tr>
                    <tr>
                      <td class="text-center">5</td>
                      <td>Alat angkut yang dipergunakan</td>
                      <td>${alatAngkut}</td>
                    </tr>
                    <tr>
                      <td class="text-center">6</td>
                      <td>a. Tempat berangkat<br>b. Tempat Tujuan</td>
                      <td>a. ${tempatBerangkat}<br>b. ${tempatTujuan}</td>
                    </tr>
                    <tr>
                      <td class="text-center">7</td>
                      <td>a. Lamanya perjalanan dinas<br>b. Tanggal berangkat<br>c. Tanggal harus kembali</td>
                      <td>a. ${lamaPerjalanan}<br>b. ${formatDateFull(tanggalBerangkat)}<br>c. ${formatDateFull(tanggalKembali)}</td>
                    </tr>
                    <tr>
                        <td rowspan="2" class="text-center align-top">8</td>
                        <td class="font-bold align-middle pl-2">Pengikut/ Nama</td>
                        <td class="p-0 align-top border-b border-black">
                          <div class="flex w-full h-full min-h-[20px]">
                            <div class="w-[45%] border-r border-black p-1 text-center font-bold">Tgl Lahir</div>
                            <div class="w-[55%] p-1 text-center font-bold">Keterangan</div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td class="align-top pl-2" style="min-height: 40px; padding-bottom: 8px;">
                          ${participant.pengikutList?.length > 0 ? participant.pengikutList.map((p: any, i: number) => `${i+1}. ${p.nama}<br>`).join('') : (participant.isLeader ? '1.<br>2.<br>3. dst' : '')}
                        </td>
                        <td class="p-0 align-top h-full">
                          <div class="flex w-full h-full min-h-[40px]">
                            <div class="w-[45%] border-r border-black p-1 text-center">
                              ${participant.pengikutList?.length > 0 ? participant.pengikutList.map((p: any) => `${p.umur}<br>`).join('') : ''}
                            </div>
                            <div class="w-[55%] p-1 text-center">
                              ${participant.pengikutList?.length > 0 ? participant.pengikutList.map((p: any) => `${p.keterangan}<br>`).join('') : ''}
                            </div>
                          </div>
                        </td>
                      </tr>
                    <tr>
                      <td class="text-center align-top">9</td>
                      <td>Pembebanan anggaran<br>a. Instansi<br>b. Mata anggaran</td>
                      <td class="align-top"><br>a. Pemerintah Desa ${cleanDesaName}<br>b. ${bebanAnggaran || '-'}</td>
                    </tr>
                    <tr>
                      <td class="text-center">10</td>
                      <td>Keterangan</td>
                      <td>-</td>
                    </tr>
                  </tbody>
                </table>

                <div class="flex justify-end text-[10px] mt-1 pr-4">
                  <div class="w-[200px]">
                    <div class="grid grid-cols-[80px_10px_1fr] mb-1">
                      <span>Dikeluarkan di</span><span>:</span><span>${desaName.replace(/desa|kelurahan/gi, '').trim()}</span>
                      <span>pada tanggal</span><span>:</span><span>${currentDateFormatted()}</span>
                    </div>
                    <div class="text-center w-full">
                      <div class="font-bold">${rightRoleHtml}</div>
                      <div class="h-12"></div>
                      <div class="font-bold uppercase">${namaKades}</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <!-- Kanan -->
              <div class="w-[47%] pl-4 text-[9px] flex flex-col">
                <div class="pl-8 mb-2">
                  <div class="grid grid-cols-[90px_10px_1fr] leading-tight mb-2">
                    <span>I. SPPD Nomor</span><span>:</span><span class="uppercase">${nomorSurat.toUpperCase()}</span>
                    <span>Berangkat dari</span><span>:</span><span>${tempatBerangkat}</span>
                    <span class="pl-2 italic">(tempat kedudukan)</span><span></span><span></span>
                    <span>Pada tanggal</span><span>:</span><span>${formatDateFull(tanggalBerangkat)}</span>
                    <span>Ke</span><span>:</span><span>${tempatTujuan}</span>
                  </div>
                  <div class="text-center w-full">
                    <div class="font-bold">Pejabat Pelaksana Teknis Kegiatan,</div>
                    <div class="h-12"></div>
                    <div class="font-bold uppercase">${namaPPTK || '...................................................'}</div>
                  </div>
                </div>

                <table class="w-full border-collapse" style="border: 1px solid black;">
                  <tbody>
                    <!-- Box II -->
                    <tr>
                      <td class="border-b border-r border-black p-1 w-1/2 align-top">
                        <div class="grid grid-cols-[15px_45px_10px_1fr] leading-tight">
                          <span>II.</span><span>Tiba di</span><span>:</span><span>${tempatTujuan}</span>
                          <span></span><span>Pada tanggal</span><span>:</span><span>${formatDateFull(tanggalBerangkat)}</span>
                          <span></span><span>Kepala</span><span>:</span><span></span>
                        </div>
                        <div class="h-8"></div>
                        <div class="flex justify-center text-gray-500">..................................</div>
                      </td>
                      <td class="border-b border-black p-1 w-1/2 align-top">
                        <div class="grid grid-cols-[60px_10px_1fr] leading-tight pl-2">
                          <span>Berangkat dari</span><span>:</span><span>${tempatTujuan}</span>
                          <span>Ke</span><span>:</span><span>${tempatBerangkat}</span>
                          <span>Pada Tanggal</span><span>:</span><span>${formatDateFull(tanggalKembali)}</span>
                          <span>Kepala</span><span>:</span><span></span>
                        </div>
                        <div class="h-8"></div>
                        <div class="flex justify-center text-gray-500">..................................</div>
                      </td>
                    </tr>
                    
                    <!-- Box III -->
                    <tr>
                      <td class="border-b border-r border-black p-1 w-1/2 align-top">
                        <div class="grid grid-cols-[15px_45px_10px_1fr] leading-tight">
                          <span>III.</span><span>Tiba di</span><span>:</span><span></span>
                          <span></span><span>Pada tanggal</span><span>:</span><span></span>
                          <span></span><span>Kepala</span><span>:</span><span></span>
                        </div>
                        <div class="h-8"></div>
                        <div class="flex justify-center text-gray-500">..................................</div>
                      </td>
                      <td class="border-b border-black p-1 w-1/2 align-top">
                        <div class="grid grid-cols-[60px_10px_1fr] leading-tight pl-2">
                          <span>Berangkat dari</span><span>:</span><span></span>
                          <span>Ke</span><span>:</span><span></span>
                          <span>Pada Tanggal</span><span>:</span><span></span>
                          <span>Kepala</span><span>:</span><span></span>
                        </div>
                        <div class="h-8"></div>
                        <div class="flex justify-center text-gray-500">..................................</div>
                      </td>
                    </tr>
                    
                    <!-- Box IV -->
                    <tr>
                      <td class="border-b border-r border-black p-1 w-1/2 align-top">
                        <div class="grid grid-cols-[15px_45px_10px_1fr] leading-tight">
                          <span>IV.</span><span>Tiba di</span><span>:</span><span></span>
                          <span></span><span>Pada tanggal</span><span>:</span><span></span>
                          <span></span><span>Kepala</span><span>:</span><span></span>
                        </div>
                        <div class="h-8"></div>
                        <div class="flex justify-center text-gray-500">..................................</div>
                      </td>
                      <td class="border-b border-black p-1 w-1/2 align-top">
                        <div class="grid grid-cols-[60px_10px_1fr] leading-tight pl-2">
                          <span>Berangkat dari</span><span>:</span><span></span>
                          <span>Ke</span><span>:</span><span></span>
                          <span>Pada Tanggal</span><span>:</span><span></span>
                          <span>Kepala</span><span>:</span><span></span>
                        </div>
                        <div class="h-8"></div>
                        <div class="flex justify-center text-gray-500">..................................</div>
                      </td>
                    </tr>
                    
                    <!-- Box V -->
                    <tr>
                      <td colspan="2" class="border-b border-black p-1 align-top">
                        <div class="grid grid-cols-[15px_1fr] leading-tight">
                          <span>V.</span>
                          <div>
                            <div class="grid grid-cols-[60px_10px_1fr] leading-tight">
                              <span>Tiba di</span><span>:</span><span></span>
                              <span>Pada tanggal</span><span>:</span><span></span>
                            </div>
                            <div class="mt-1 leading-tight text-justify pr-2">
                              Telah diperiksa dengan keterangan bahwa perjalanan tersebut dilakukan atas perintah dan semata-mata untuk kepentingan jabatan dalam waktu yang sesingkat-singkatnya.
                            </div>
                          </div>
                        </div>
                        <div class="flex justify-center mt-2">
                          <div class="text-center w-full">
                            <div class="font-bold">${rightRoleHtml}</div>
                            <div class="h-12"></div>
                            <div class="font-bold uppercase">${namaKades}</div>
                          </div>
                        </div>
                      </td>
                    </tr>
                    
                    <!-- Box VI -->
                    <tr>
                      <td colspan="2" class="border-b border-black p-1 align-top">
                        <div class="grid grid-cols-[15px_1fr] leading-tight">
                          <span>VI.</span><span>CATATAN LAIN-LAIN</span>
                        </div>
                      </td>
                    </tr>
                    
                    <!-- Box VII -->
                    <tr>
                      <td colspan="2" class="p-1 align-top">
                        <div class="grid grid-cols-[15px_1fr] leading-tight">
                          <span>VII.</span>
                          <div>
                            <span>PERHATIAN :</span>
                            <div class="text-justify leading-tight mt-1">
                              Pejabat yang berwenang menerbitkan SPPD, Pegawai yang melakukan Perjalanan Dinas Para pejabat yang mengesahkan tanggal berangkat/tiba serta Bendaharawan bertanggung jawab berdasarkan peraturan-peraturan Keuangan Negara, apabila Negara menderita rugi akibat kesalahan dan kealpaannya
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div style="position:absolute;bottom:8mm;left:15mm;right:15mm;width:calc(100% - 30mm);">
                ${SAAS_CONFIG.globalFooterHTML}
            </div>
          </div>

          <!-- HALAMAN 3: LEMBAR LAPORAN -->
          <div class="page-a4 page-laporan bg-white shadow-lg mx-auto" style="${printLayout !== `laporan-${participant.groupId}` && printLayout !== 'semua' ? 'display: none;' : ''}">
            <div class="text-[14px] text-black pt-12">
              <div class="text-center mb-10">
                <h6 class="font-bold uppercase text-[16px]">LAPORAN PERJALANAN DINAS</h6>
              </div>

              <div class="grid grid-cols-[150px_10px_1fr] gap-2 mb-8 max-w-xl mx-auto">
                <span>Kepada Yth</span><span>:</span><span>${kepadaYth}</span>
                <span>Dari</span><span>:</span><span></span>
                <span>Nama</span><span>:</span><span>${participant.nama}</span>
                <span>Jabatan</span><span>:</span><span>${participant.jabatan}</span>
                <span>Hari/Tanggal</span><span>:</span><span>${formatDateFull(tanggalBerangkat)}</span>
                <span>Perihal</span><span>:</span><span>${maksudPerjalanan}</span>
                <span>Tempat</span><span>:</span><span>${tempatTujuan}</span>
              </div>

              <div class="grid grid-cols-[150px_10px_1fr] gap-2 mb-8 max-w-xl mx-auto">
                <span>HASIL PERJALANAN</span><span>:</span><span></span>
              </div>

              <div class="flex justify-end pr-10 mt-32">
                <div class="text-center w-[250px]">
                  <p>Yang Melaporkan,</p>
                  <div class="h-24"></div>
                  <p class="font-bold underline">${participant.nama}</p>
                </div>
              </div>
            </div>
            <div style="position:absolute;bottom:8mm;left:15mm;right:15mm;width:calc(100% - 30mm);">
                ${SAAS_CONFIG.globalFooterHTML}
            </div>
          </div>
    `;

    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Surat Perjalanan Dinas (SPPD)</title>
          <script src="https://cdn.tailwindcss.com"></script>
          <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
          <style>
            body { font-family: Arial, Helvetica, sans-serif; background: transparent; margin: 0; padding: 0; line-height: 1.5; color: #000; -webkit-print-color-adjust: exact; print-color-adjust: exact; overflow: hidden; }
            /* Hide scrollbar for Chrome, Safari and Opera */
            body::-webkit-scrollbar { display: none; }
            .page-a4 { width: 210mm; min-height: 297mm; padding: 15mm 20mm; position: relative; page-break-after: always; box-sizing: border-box; background: white; margin-bottom: 24px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); border-radius: 4px; overflow: hidden; }
            .page-landscape { width: 297mm; min-height: 210mm; padding: 10mm 15mm; position: relative; page-break-after: always; box-sizing: border-box; background: white; margin-bottom: 24px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); border-radius: 4px; overflow: hidden; }
            .page-a4:last-child, .page-landscape:last-child { page-break-after: auto; }
            .print-table { width: 100%; border-collapse: collapse; font-size: 11px; line-height: 1.2; }
            .print-table th, .print-table td { border: 1px solid black; padding: 2px 4px; vertical-align: top; }
            
            @media print {
              body { background: white; overflow: visible; margin: 0; padding: 0; }
              .page-a4 { width: 100% !important; min-height: 297mm !important; box-shadow: none; margin: 0; border-radius: 0; overflow: visible !important; }
              .page-landscape { width: 100% !important; min-height: 210mm !important; box-shadow: none; margin: 0; border-radius: 0; overflow: visible !important; }

              
              ${printLayout === 'surattugas' ? `@page { size: portrait; margin: 0; }` : ''}
              ${printLayout.startsWith('sppd-') ? `@page { size: landscape; margin: 0; }` : ''}
              ${printLayout.startsWith('laporan-') ? `@page { size: portrait; margin: 0; }` : ''}
              ${printLayout === 'semua' ? `@page { size: A4; margin: 0; }` : ''}
              .nomor-surat-cetak { text-transform: uppercase !important; }
            }
          </style>
        </head>
        <body>

          <!-- HALAMAN 1: SURAT TUGAS -->
          <div class="page-a4 page-spt bg-white shadow-lg mx-auto" style="${printLayout !== 'surattugas' && printLayout !== 'semua' ? 'display: none;' : ''}">
            ${kopSuratHTML}
            
            <div class="text-[14px] text-black">
              <div class="text-center mb-8">
                <h6 class="font-bold underline uppercase text-[16px]">SURAT TUGAS</h6>
                <p class="font-bold mt-1 nomor-surat-cetak" style="text-transform:uppercase;">Nomor : ${nomorSurat.toUpperCase()}</p>
              </div>

              <div class="mb-6 text-justify leading-relaxed">
                Berdasarkan ${dasarPenugasan},
              </div>

              <div class="text-center font-bold mb-6">MEMERINTAHKAN</div>
              
              <table class="print-table mb-8">
                <thead>
                  <tr class="bg-gray-50">
                    <th class="w-12 text-center py-3">NO</th>
                    <th class="text-center py-3">NAMA</th>
                    <th class="text-center py-3">JABATAN</th>
                  </tr>
                </thead>
                <tbody>
                  ${allParticipantsFlat.map((p: any, i: number) => `
                    <tr>
                      <td class="text-center py-3">${i+1}</td>
                      <td class="py-3 font-semibold">${p.nama}</td>
                      <td class="py-3">${p.jabatan || '-'}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>

              <div class="grid grid-cols-[130px_10px_1fr] gap-2 mb-10 text-[14px]">
                <span class="font-semibold">Hari/Tanggal</span><span>:</span>
                <span>${formatDateFull(tanggalBerangkat)}</span>
                
                <span class="font-semibold">Perihal</span><span>:</span>
                <span>${maksudPerjalanan}</span>

                <span class="font-semibold">Tempat</span><span>:</span>
                <span>${tempatTujuan}</span>
              </div>

              <div class="mb-10 text-justify leading-relaxed">Demikian surat tugas ini untuk dilaksanakan sebagaimana mestinya.</div>

              ${getPrintSignatureHTML(desaName, currentDateFormatted(), namaKades, roleKades, nipKades, false, useEsignature, nomorSurat)}
            </div>
            <div style="position:absolute;bottom:8mm;left:15mm;right:15mm;width:calc(100% - 30mm);">
                ${SAAS_CONFIG.globalFooterHTML}
            </div>
          </div>

          ${allParticipantsFlat.map((p: any) => generatePage2And3(p)).join('')}

        </body>
      </html>
    `;
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header (Reusable Standard Header) */}
      <SuratEditorHeader 
          template={getLetterHeaderTemplate('SPPD', { kode: '094', jenis: 'Surat Perjalanan Dinas', deskripsi: 'Surat Perintah & Perjalanan Dinas (SPPD)', nomorSurat: nomorSurat })}
          icon={<Plane className="w-5 h-5" />}
          onBack={onBack}
          onSave={handleRecord}
          isSaving={isSaving}
        >
          {/* Document selector in header */}
          <div className="flex items-center gap-1 pl-3 border-l border-slate-200 dark:border-slate-700 overflow-x-auto">
            <button
              onClick={() => setPrintLayout('surattugas')}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all whitespace-nowrap h-8 ${
                printLayout === 'surattugas'
                  ? 'bg-slate-700 dark:bg-slate-500 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <FileText size={12} /> S. Tugas
            </button>
            {pelaksanaList.map((p, idx) => (
              <React.Fragment key={`hdr-${p.id}`}>
                <button
                  onClick={() => setPrintLayout(`sppd-${p.id}`)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all whitespace-nowrap h-8 ${
                    printLayout === `sppd-${p.id}`
                      ? 'bg-slate-700 dark:bg-slate-500 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <Printer size={12} /> {p.nama ? p.nama.split(' ')[0] : `P${idx + 1}`}
                </button>
                <button
                  onClick={() => setPrintLayout(`laporan-${p.id}`)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all whitespace-nowrap h-8 ${
                    printLayout === `laporan-${p.id}`
                      ? 'bg-slate-700 dark:bg-slate-500 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <FileText size={12} /> Lap.
                </button>
              </React.Fragment>
            ))}
            <button
              onClick={handlePrintAll}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all whitespace-nowrap h-8 bg-emerald-600 text-white shadow-sm hover:bg-emerald-500"
            >
              <Printer size={12} /> Cetak Semua
            </button>
          </div>
        </SuratEditorHeader>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Column */}
        <div className="lg:col-span-7 space-y-6">

          {/* Backdate Config - Paling Atas Form */}
          <BackdateConfig
            prefix={kodeKlasifikasiSPPD}
            suffix="WHI-SPPD"
            tanggalSurat={tanggalSurat}
            onTanggalSuratChange={setTanggalSurat}
            isBackdate={isBackdate}
            onBackdateChange={setIsBackdate}
            manualSequence={manualSequence}
            onManualSequenceChange={setManualSequence}
            normalNomor={nomorSurat}
            onCustomNomorSurat={handleCustomNomorSurat}
          />

          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-gray-900 dark:text-white text-sm uppercase tracking-wider">Daftar Pelaksana Perjalanan Dinas</h3>
            </div>
            
            <div className="space-y-6">
              {pelaksanaList.map((pelaksana, pIdx) => (
                <div key={pelaksana.id} className="p-4 rounded-xl border border-gray-200 dark:border-slate-700 bg-gray-50/50 dark:bg-slate-800/30">
                  <div className="flex justify-between items-center mb-4 pb-2 border-b border-gray-200 dark:border-slate-700">
                    <h4 className="font-semibold text-gray-800 dark:text-slate-200 text-sm">
                      Pelaksana No. {pIdx + 1} {pIdx === 0 ? '(Ketua Rombongan)' : ''}
                    </h4>
                    {pelaksanaList.length > 1 && (
                      <button onClick={() => removePelaksana(pelaksana.id)} className="text-red-500 hover:text-red-700 text-xs flex items-center gap-1 font-medium">
                        <Trash2 size={14} /> Hapus
                      </button>
                    )}
                  </div>
                  
                  <div className="space-y-4 mb-4">
                    <div className="relative">
                      <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">Nama Lengkap</label>
                      <div className="relative">
                        <input 
                          type="text" 
                          value={pelaksana.nama}
                          onChange={(e) => {
                            handlePelaksanaChange(pelaksana.id, 'nama', e.target.value);
                            setActivePelaksanaDropdown(pelaksana.id);
                          }}
                          onFocus={() => setActivePelaksanaDropdown(pelaksana.id)}
                          onBlur={() => setTimeout(() => setActivePelaksanaDropdown(null), 200)}
                          className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800 bg-white"
                          placeholder="Ketik nama aparat / penduduk..."
                        />
                        <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
                      </div>
                      {activePelaksanaDropdown === pelaksana.id && pelaksana.nama.length > 1 && (
                        <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-gray-100 dark:border-slate-700 max-h-60 overflow-y-auto z-50">
                          {[...officers, ...residents].filter((r: any) => (r.name || r.nama || '').toLowerCase().includes((pelaksana?.nama || '').toLowerCase()) || (r.nik || r.nip || '').includes(pelaksana.nama)).slice(0, 5).map((res: any, idx: number) => (
                            <button
                              key={res.nik || res.nip || idx}
                              onMouseDown={(e) => {
                                e.preventDefault();
                                handlePelaksanaChange(pelaksana.id, 'nama', res.name || res.nama || '');
                                handlePelaksanaChange(pelaksana.id, 'nip', res.nik || res.nip || '');
                                handlePelaksanaChange(pelaksana.id, 'jabatan', res.role || res.pekerjaan || res.jabatan || '');
                                setActivePelaksanaDropdown(null);
                              }}
                              className="w-full text-left px-4 py-2 hover:bg-emerald-50 dark:hover:bg-slate-700 transition-colors border-b border-gray-50 dark:border-slate-700/50 last:border-0"
                            >
                              <div className="font-semibold text-gray-900 dark:text-white text-sm">{res.name || res.nama}</div>
                              <div className="text-xs text-gray-500 dark:text-slate-400">{res.nik ? `NIK: ${res.nik}` : (res.nip ? `NIP: ${res.nip}` : '')} &bull; {res.role || res.pekerjaan || res.jabatan || 'Tidak ada keterangan'}</div>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">NIP/NIK (Opsional)</label>
                        <input 
                          type="text" 
                          value={pelaksana.nip}
                          onChange={(e) => handlePelaksanaChange(pelaksana.id, 'nip', e.target.value)}
                          className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800 bg-white"
                          placeholder="NIP / NIK"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">Pangkat/Gol (Opsional)</label>
                        <input 
                          type="text" 
                          value={pelaksana.pangkat}
                          onChange={(e) => handlePelaksanaChange(pelaksana.id, 'pangkat', e.target.value)}
                          className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800 bg-white"
                          placeholder="Misal: II/a"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">Jabatan / Keterangan</label>
                      <input 
                        type="text" 
                        value={pelaksana.jabatan}
                        onChange={(e) => handlePelaksanaChange(pelaksana.id, 'jabatan', e.target.value)}
                        className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800 bg-white"
                        placeholder="Misal: Kaur Keuangan"
                      />
                    </div>
                  </div>

                  {/* Pengikut Section for this Pelaksana */}
                  <div className="mt-6 pt-4 border-t border-gray-200 dark:border-slate-700">
                    <div className="flex justify-between items-center mb-3">
                      <h5 className="font-semibold text-gray-700 dark:text-slate-300 text-xs uppercase tracking-wider">Pengikut (Bawaan No. {pIdx + 1})</h5>
                      {pelaksana.pengikutList.length < 5 && (
                        <button 
                          onClick={() => addPengikutToPelaksana(pelaksana.id)}
                          className="flex items-center gap-1 px-2 py-1 bg-white dark:bg-slate-700 border border-gray-200 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-600 text-gray-600 dark:text-gray-300 text-xs rounded transition-colors"
                        >
                          <Plus size={12} /> Tambah Pengikut
                        </button>
                      )}
                    </div>
                    {pelaksana.pengikutList.length === 0 ? (
                      <div className="text-center py-4 text-xs text-gray-500 dark:text-slate-400 bg-white dark:bg-slate-900 rounded-lg border border-dashed border-gray-200 dark:border-slate-700">
                        Tidak ada pengikut.
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {pelaksana.pengikutList.map((p: any, index: number) => (
                          <div key={index} className="flex gap-2 items-start bg-white dark:bg-slate-900 p-2 rounded-lg border border-gray-100 dark:border-slate-700">
                            <div className="flex-1 grid grid-cols-12 gap-2">
                              <div className="col-span-5 relative">
                                <input 
                                  type="text" 
                                  value={p.nama}
                                  onChange={(e) => {
                                    handlePengikutChange(pelaksana.id, index, 'nama', e.target.value);
                                    setActivePengikutDropdown(`${pelaksana.id}-${index}`);
                                  }}
                                  onFocus={() => setActivePengikutDropdown(`${pelaksana.id}-${index}`)}
                                  onBlur={() => setTimeout(() => setActivePengikutDropdown(null), 200)}
                                  className="w-full px-2 py-1.5 text-xs rounded-md border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800"
                                  placeholder="Nama Pengikut"
                                />
                                {activePengikutDropdown === `${pelaksana.id}-${index}` && p.nama.length > 1 && (
                                  <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-gray-100 dark:border-slate-700 max-h-48 overflow-y-auto z-50">
                                    {[...officers, ...residents].filter((r: any) => (r.name || r.nama || '').toLowerCase().includes((p?.nama || '').toLowerCase()) || (r.nik || r.nip || '').includes(p.nama)).slice(0, 5).map((res: any, idx: number) => (
                                      <button
                                        key={res.nik || res.nip || idx}
                                        onMouseDown={(e) => {
                                          e.preventDefault(); // Prevent input onBlur from firing before selection
                                          handlePengikutChange(pelaksana.id, index, 'nama', res.name || res.nama || '');
                                          handlePengikutChange(pelaksana.id, index, 'umur', (res.umur ? res.umur.toString() : (res.nik || res.nip || '')));
                                          handlePengikutChange(pelaksana.id, index, 'keterangan', res.pekerjaan || res.jabatan || '');
                                          setActivePengikutDropdown(null);
                                        }}
                                        className="w-full text-left px-2 py-1.5 hover:bg-emerald-50 dark:hover:bg-slate-700 transition-colors border-b border-gray-50 dark:border-slate-700/50 last:border-0"
                                      >
                                        <div className="font-medium text-gray-900 dark:text-white text-[11px]">{res.name || res.nama}</div>
                                      </button>
                                    ))}
                                  </div>
                                )}
                              </div>
                              <div className="col-span-3">
                                <input 
                                  type="text" 
                                  value={p.umur}
                                  onChange={(e) => handlePengikutChange(pelaksana.id, index, 'umur', e.target.value)}
                                  className="w-full px-2 py-1.5 text-xs rounded-md border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800"
                                  placeholder="Umur"
                                />
                              </div>
                              <div className="col-span-4">
                                <input 
                                  type="text" 
                                  value={p.keterangan}
                                  onChange={(e) => handlePengikutChange(pelaksana.id, index, 'keterangan', e.target.value)}
                                  className="w-full px-2 py-1.5 text-xs rounded-md border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800"
                                  placeholder="Keterangan"
                                />
                              </div>
                            </div>
                            <button 
                              onClick={() => removePengikutFromPelaksana(pelaksana.id, index)}
                              className="p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded transition-colors mt-0.5"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              
              <button 
                onClick={addPelaksana}
                className="w-full flex justify-center items-center gap-2 py-3 bg-emerald-50 dark:bg-slate-800 hover:bg-emerald-100 dark:hover:bg-slate-700 text-emerald-600 dark:text-emerald-400 text-sm font-semibold rounded-xl transition-colors border border-emerald-100 dark:border-slate-700"
              >
                <Plus size={16} /> Tambah Orang yang Melakukan Perjalanan Dinas
              </button>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 mb-6">
            <h3 className="font-bold text-gray-900 dark:text-white mb-4 text-sm uppercase tracking-wider">Detail Perjalanan Dinas & Dasar</h3>
            <div className="space-y-4 mb-4">
              <div className="mb-4">
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-sm font-medium text-gray-700 dark:text-slate-300">Dasar Penugasan</label>
                  <label className="flex items-center gap-2 text-xs text-emerald-600 dark:text-emerald-400 cursor-pointer hover:bg-emerald-50 dark:hover:bg-slate-800 p-1 px-2 rounded transition-colors">
                    <input 
                      type="checkbox" 
                      checked={isDasarManual} 
                      onChange={(e) => setIsDasarManual(e.target.checked)} 
                      className="rounded border-gray-300 dark:border-slate-600 text-emerald-500 focus:ring-emerald-500" 
                    />
                    Isi Manual (Format Lain)
                  </label>
                </div>
                {!isDasarManual ? (
                  <div className="flex gap-3 items-center">
                    <input 
                      type="text" 
                      value={dasarNo} 
                      onChange={(e) => setDasarNo(e.target.value)} 
                      placeholder="Nomor Surat Undangan..." 
                      className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800 text-sm" 
                    />
                    <input 
                      type="date" 
                      value={dasarTgl} 
                      onChange={(e) => setDasarTgl(e.target.value)} 
                      className="px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800 text-sm w-48" 
                    />
                  </div>
                ) : (
                  <textarea 
                    value={dasarPenugasan}
                    onChange={(e) => setDasarPenugasan(e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800 text-sm"
                    rows={2}
                    placeholder="Misal: Dokumen Pelaksanaan Anggaran (DPA)..."
                  />
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">Pejabat Pelaksana Teknis (PPTK)</label>
                <select
                  value={namaPPTK}
                  onChange={(e) => setNamaPPTK(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800 text-sm"
                >
                  <option value="">-- Pilih PPTK (Jika Ada) --</option>
                  {officers.length > 0 ? (
                    officers.map((officer: any, idx: number) => (
                      <option key={idx} value={officer.name}>{officer.name} - {officer.role}</option>
                    ))
                  ) : (
                    <option value={namaPPTK}>{namaPPTK}</option>
                  )}
                </select>
              </div>
            </div>
            
            <div className="h-px bg-gray-200 dark:bg-slate-700 my-4"></div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">Maksud Perjalanan</label>
                <textarea 
                  value={maksudPerjalanan}
                  onChange={(e) => setMaksudPerjalanan(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800 min-h-[80px]"
                  placeholder="Misal: Konsultasi terkait dana desa..."
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">Tempat Tujuan</label>
                <textarea 
                  value={tempatTujuan}
                  onChange={(e) => setTempatTujuan(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800"
                  rows={2}
                  placeholder="Tempat Tujuan (Bisa diisi panjang jika perlu)"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">Alat Angkut</label>
                  <select 
                    value={alatAngkut}
                    onChange={(e) => setAlatAngkut(e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800"
                  >
                    <option value="">-- Pilih Alat Angkut --</option>
                    <option value="Kendaraan Dinas">Kendaraan Dinas</option>
                    <option value="Kendaraan Umum">Kendaraan Umum</option>
                    <option value="Kendaraan Pribadi">Kendaraan Pribadi</option>
                    <option value="Pesawat Udara">Pesawat Udara</option>
                    <option value="Kapal Laut">Kapal Laut</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">Lama Perjalanan (Hari)</label>
                  <input 
                    type="text" 
                    value={lamaPerjalanan}
                    onChange={(e) => setLamaPerjalanan(e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800"
                    placeholder="Misal: 1 (Satu) Hari"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">Tanggal Berangkat</label>
                  <input 
                    type="date" 
                    value={tanggalBerangkat}
                    onChange={(e) => setTanggalBerangkat(e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">Tanggal Kembali</label>
                  <input 
                    type="date" 
                    value={tanggalKembali}
                    onChange={(e) => setTanggalKembali(e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 mb-6">
            <h3 className="font-bold text-gray-900 dark:text-white mb-4 text-sm uppercase tracking-wider">Pembebanan Anggaran</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1">Mata Anggaran</label>
                <input 
                  type="text" 
                  value={bebanAnggaran}
                  onChange={(e) => setBebanAnggaran(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none dark:bg-slate-800"
                  placeholder="Misal: APBDes Tahun 2026"
                />
              </div>
            </div>
          </div>
          
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm dark:shadow-none border border-amber-200 dark:border-amber-800/40 mb-6">
            <h3 className="font-bold text-gray-900 dark:text-white mb-4 text-sm uppercase tracking-wider flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span> Pejabat Penandatangan
            </h3>
            <div className="space-y-4">
              <div className="p-4 bg-amber-50/50 dark:bg-amber-950/20 rounded-xl border border-amber-100 dark:border-amber-800/30">
                <label className="block text-xs font-bold text-amber-700 dark:text-amber-400 mb-1.5 uppercase tracking-wider">Nama Pejabat</label>
                <select
                  value={namaKades}
                  onChange={(e) => {
                    const selected = officers.find((o: any) => o.name === e.target.value);
                    if (selected) {
                      setNamaKades(selected.name);
                      setRoleKades(selected.role);
                      setNipKades(selected.nip || '');
                    }
                  }}
                  className="w-full px-4 py-2.5 rounded-xl border border-amber-200 dark:border-amber-700 focus:ring-2 focus:ring-amber-500 outline-none dark:bg-slate-800 bg-white text-sm"
                >
                  {officers.length > 0 ? (
                    officers.map((officer: any, idx: number) => (
                      <option key={idx} value={officer.name}>{officer.name} ({officer.role})</option>
                    ))
                  ) : (
                    <option value={namaKades}>{namaKades} ({roleKades})</option>
                  )}
                </select>
              </div>

              <div className="mt-4 pt-4 border-t border-amber-100 dark:border-amber-800/30 space-y-3">
                <label className="flex items-center justify-between p-3.5 bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-800/40 rounded-xl cursor-pointer hover:bg-amber-50/50 transition-all">
                  <div className="space-y-0.5 pr-4">
                    <div className="font-bold text-slate-800 dark:text-slate-100 text-sm">Tanda Tangan Elektronik (TTE / QR Code)</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">Tampilkan QR Code verifikasi dokumen resmi pada hasil cetak</div>
                  </div>
                  <div className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input 
                      type="checkbox" 
                      checked={useEsignature} 
                      onChange={(e) => setUseEsignature(e.target.checked)}
                      className="sr-only peer" 
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                  </div>
                </label>
              </div>

              <p className="text-xs text-amber-600 dark:text-amber-400 italic mt-2">* Nama dan jabatan pejabat dapat diatur secara permanen melalui Menu Pengaturan.</p>
            </div>
          </div>

      </div>
      {/* End Form Column */}

      {/* Preview Column */}
      <div className="lg:col-span-5 space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-3xl overflow-hidden shadow-xl flex flex-col h-[700px] sticky top-[170px]">
          {/* Header bar with zoom + print */}
          <div className="px-4 py-3 border-b border-gray-100 dark:border-slate-800 flex items-center justify-between shrink-0 bg-gray-50/90 dark:bg-slate-800/50">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 tracking-wide uppercase">Preview</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-white dark:bg-slate-800 p-0.5 rounded-xl border border-slate-100 dark:border-slate-800">
                <button onClick={() => setZoomLevel(z => Math.max(0.3, z - 0.1))} className="p-1 text-gray-500 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"><ZoomOut size={14} /></button>
                <span className="text-[11px] font-mono font-bold text-slate-600 dark:text-slate-400 px-1.5 w-10 text-center">{Math.round(zoomLevel * 100)}%</span>
                <button onClick={() => setZoomLevel(z => Math.min(2.0, z + 0.1))} className="p-1 text-gray-500 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"><ZoomIn size={14} /></button>
                <div className="w-px h-4 bg-slate-200 mx-0.5"></div>
                <button onClick={() => setZoomLevel(0.45)} className="text-[10px] font-bold text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 px-1.5">Reset</button>
              </div>
            </div>
          </div>

          {/* Preview iframe */}
          <div
            {...dragProps}
            className="flex-1 overflow-auto p-6 flex flex-col items-center bg-slate-200/50 dark:bg-slate-800/50"
          >
            <div style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'top center', transition: 'transform 0.2s ease', width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <iframe
                ref={iframeRef}
                scrolling="no"
                className="pointer-events-none"
                style={{
                  width: '297mm',
                  minHeight: '297mm',
                  height: printLayout.startsWith('sppd-') ? '215mm' : '300mm',
                  border: 'none',
                  background: 'transparent'
                }}
                srcDoc={generateHTML()}
                title="Print Preview SPPD"
              />
            </div>
          </div>
        </div>
      </div>

      </div>
      {/* End Grid */}
    
      <QuickAddResidentModal
        isOpen={showQuickAddModal}
        onClose={() => setShowQuickAddModal(false)}
        onSuccess={() => {
          setShowQuickAddModal(false);
          handlePrint();
        }}
        initialData={quickAddInitialData}
      />
    </div>
  );
}
