import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Search, Edit2, Trash2, Calendar, MessageSquare, Heart, Image as ImageIcon, X, Upload, Newspaper, AlertTriangle, Star } from 'lucide-react';
import { showToast } from '../../utils/toast';
import { supabase } from '../../utils/supabase';
import { resolveCurrentTenant } from '../../utils/tenantResolver';

interface NewsComment {
  id: string;
  name: string;
  text: string;
  date: string;
}

export interface ProgressPhoto {
  id: string;
  stage: string;
  title: string;
  imageUrl: string;
}

export interface NewsItem {
  id: string;
  image: string;
  tag: string;
  tagColor: string;
  title: string;
  excerpt: string;
  fullContent: string;
  date: string;
  author: string;
  likes: number;
  comments: NewsComment[];
  progressPhotos?: ProgressPhoto[];
}

const CATEGORIES = [
  { label: 'KEGIATAN DESA', color: 'bg-emerald-50 text-emerald-700 border-emerald-100' },
  { label: 'PENGUMUMAN', color: 'bg-amber-50 text-amber-700 border-amber-100' },
  { label: 'PEMBANGUNAN', color: 'bg-blue-50 text-blue-700 border-blue-100' },
  { label: 'SOSIAL & BANTUAN', color: 'bg-purple-50 text-purple-700 border-purple-100' }
];

const newsChannel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('didesa_news_sync') : null;

const compressImage = (file: File): Promise<{ blob: Blob; originalSize: number; compressedSize: number }> => {
  return new Promise((resolve, reject) => {
    const originalSize = file.size;
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 900;
        const MAX_HEIGHT = 900;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        
        canvas.toBlob((blob) => {
          if (blob) {
            resolve({ blob, originalSize, compressedSize: blob.size });
          } else {
            reject(new Error('Canvas to Blob failed'));
          }
        }, 'image/jpeg', 0.65);
      };
      img.onerror = (error) => reject(error);
    };
    reader.onerror = (error) => reject(error);
  });
};

const sanitizeNewsList = (rawList: NewsItem[]): NewsItem[] => {
  return rawList.map(item => {
    const isLikedByUser = localStorage.getItem(`didesa_liked_${item.id}`) === 'true';
    const isLegacyDummy = item.likes === 35 || item.likes === 42 || item.likes === 18 || item.likes === 55 || item.likes === 31;
    return {
      ...item,
      likes: isLegacyDummy ? (isLikedByUser ? 1 : 0) : item.likes
    };
  });
};

export default function AdminBerita({ searchQuery = '', setSearchQuery, debouncedSearchQuery = '' }: { searchQuery?: string, setSearchQuery?: (v: string) => void, debouncedSearchQuery?: string }) {
  const [tenantId, setTenantId] = useState<string | null>(null);
  const [news, setNews] = useState<NewsItem[]>(() => {
    const saved = localStorage.getItem('didesa_news_list');
    const parsed = saved ? JSON.parse(saved) : [];
    return sanitizeNewsList(parsed);
  });

  const [desaName, setDesaName] = useState(() => localStorage.getItem('kop_desa') || 'Desa Ketupat');

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<NewsItem | null>(null);
  const [editingNews, setEditingNews] = useState<NewsItem | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    excerpt: '',
    fullContent: '',
    tag: CATEGORIES[0].label,
    image: '',
    author: '',
    progressPhotos: [] as ProgressPhoto[]
  });
  const [isUploading, setIsUploading] = useState(false);
  const [uploadingStageIndex, setUploadingStageIndex] = useState<number | null>(null);

  // Fetch news from Supabase on mount
  useEffect(() => {
    let isMounted = true;
    const fetchNews = async () => {
      const tid = await resolveCurrentTenant();
      if (!isMounted) return;
      setTenantId(tid);
      if (!tid) {
        console.error('[AdminBerita] Tenant ID tidak dapat diidentifikasi. Berita tidak akan disimpan ke server.');
        showToast('Gagal mengidentifikasi Tenant Desa. Silakan muat ulang halaman.', 'error');
        return;
      }

      try {
        const { data, error } = await supabase
          .from('saas_settings')
          .select('value')
          .eq('tenant_id', tid)
          .eq('key', 'didesa_news_list')
          .single();

        if (error && error.code !== 'PGRST116') {
          console.error('[AdminBerita] Gagal memuat berita dari server:', error.message);
          showToast('Gagal memuat berita dari server: ' + error.message, 'error');
          return;
        }

        if (data && data.value && isMounted) {
          const parsed = JSON.parse(data.value);
          const sanitized = sanitizeNewsList(parsed);
          setNews(sanitized);
          localStorage.setItem('didesa_news_list', JSON.stringify(sanitized));
        }
      } catch (err: any) {
        console.error('[AdminBerita] Error fetching news:', err?.message || err);
      }
    };
    fetchNews();
    return () => { isMounted = false; };
  }, []);

  // Save to Supabase and LocalStorage whenever news changes
  useEffect(() => {
    const sanitized = sanitizeNewsList(news);
    const serialized = JSON.stringify(sanitized);
    const savedLocal = localStorage.getItem('didesa_news_list');

    // Hindari loop tak berujung jika tidak ada perubahan struktural
    if (savedLocal === serialized) return;

    // BLOKIR save jika tenantId belum resolved — cegah silent failure
    if (!tenantId) {
      console.warn('[AdminBerita] Tenant ID belum tersedia. Menunda save ke Supabase...');
      return;
    }

    // Simpan ke localStorage dulu (optimistic)
    localStorage.setItem('didesa_news_list', serialized);

    // Push ke Supabase, THEN dispatch event setelah berhasil
    const saveToSupabase = async () => {
      try {
        const { data, error } = await supabase.from('saas_settings').upsert({
          tenant_id: tenantId,
          key: 'didesa_news_list',
          value: serialized
        }, { onConflict: 'tenant_id,key' });

        if (error) {
          console.error('[AdminBerita] Gagal menyimpan berita ke server:', error.message, error);
          showToast('Gagal menyimpan berita ke server: ' + error.message, 'error');
          // Rollback localStorage jika Supabase gagal
          localStorage.setItem('didesa_news_list', savedLocal || '[]');
          return;
        }

        // Dispatch event SETELAH Supabase save berhasil
        window.dispatchEvent(new Event('didesa_news_updated'));
        newsChannel?.postMessage({ type: 'news_updated' });
        console.log('[AdminBerita] Berita berhasil disimpan ke Supabase untuk tenant:', tenantId);
      } catch (err: any) {
        console.error('[AdminBerita] Error saat save ke Supabase:', err?.message || err);
        showToast('Terjadi kesalahan saat menyimpan berita. Data hanya tersimpan lokal.', 'error');
      }
    };
    saveToSupabase();
  }, [news, tenantId]);

  // Sync real-time when citizens like or comment from Portal Warga (local event sync)
  useEffect(() => {
    const handleNewsUpdate = async () => {
      if (!tenantId) return;
      try {
        const { data, error } = await supabase
          .from('saas_settings')
          .select('value')
          .eq('tenant_id', tenantId)
          .eq('key', 'didesa_news_list')
          .single();

        if (!error && data?.value) {
          const parsed = JSON.parse(data.value);
          const sanitized = sanitizeNewsList(parsed);
          setNews(sanitized);
          localStorage.setItem('didesa_news_list', JSON.stringify(sanitized));
        }
      } catch (err: any) {
        console.error('[AdminBerita] Gagal sync dari portal:', err?.message || err);
      }
    };
    window.addEventListener('didesa_news_updated', handleNewsUpdate);
    window.addEventListener('storage', handleNewsUpdate);
    newsChannel?.addEventListener('message', handleNewsUpdate);
    return () => {
      window.removeEventListener('didesa_news_updated', handleNewsUpdate);
      window.removeEventListener('storage', handleNewsUpdate);
      newsChannel?.removeEventListener('message', handleNewsUpdate);
    };
  }, [tenantId]);

  const filteredNews = useMemo(() => {
    return news.filter(item => 
      item.title.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
      item.excerpt.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
      item.tag.toLowerCase().includes(debouncedSearchQuery.toLowerCase())
    );
  }, [news, debouncedSearchQuery]);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    try {
      if (!e.target.files || e.target.files.length === 0) return;
      setIsUploading(true);
      const file = e.target.files[0];
      
      const { blob: compressedBlob, originalSize, compressedSize } = await compressImage(file);
      const fileName = `news-${Date.now()}-${Math.floor(Math.random() * 10000)}.jpg`;
      
      const { error: uploadError } = await supabase.storage
        .from('public-assets')
        .upload(fileName, compressedBlob, {
          contentType: 'image/jpeg'
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('public-assets')
        .getPublicUrl(fileName);

      setFormData(prev => ({ ...prev, image: publicUrl }));
      const savedKb = Math.round((originalSize - compressedSize) / 1024);
      const compressedKb = Math.round(compressedSize / 1024);
      showToast(`Gambar dikompresi (${compressedKb} KB, hemat ${savedKb} KB)`, 'success');
      
      e.target.value = '';
    } catch (error: any) {
      console.error('Error uploading image:', error);
      showToast('Gagal mengunggah gambar', 'error');
    } finally {
      setIsUploading(false);
    }
  };

  const handleProgressPhotoUpload = async (index: number, file: File) => {
    try {
      setUploadingStageIndex(index);
      const { blob: compressedBlob, originalSize, compressedSize } = await compressImage(file);
      const fileName = `progress-${Date.now()}-${Math.floor(Math.random() * 10000)}.jpg`;
      
      const { error: uploadError } = await supabase.storage
        .from('public-assets')
        .upload(fileName, compressedBlob, { contentType: 'image/jpeg' });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('public-assets')
        .getPublicUrl(fileName);

      setFormData(prev => {
        const updated = [...prev.progressPhotos];
        updated[index] = { ...updated[index], imageUrl: publicUrl };
        return { ...prev, progressPhotos: updated };
      });
      const compressedKb = Math.round(compressedSize / 1024);
      showToast(`Foto tahapan terkompresi (${compressedKb} KB)`, 'success');
    } catch (error: any) {
      console.error('Error uploading progress photo:', error);
      showToast('Gagal mengunggah foto tahapan', 'error');
    } finally {
      setUploadingStageIndex(null);
    }
  };

  const addDanaDesaPresets = () => {
    setFormData(prev => ({
      ...prev,
      progressPhotos: [
        { id: `p-0-${Date.now()}`, stage: '0%', title: 'Titik Nol / Persiapan Awal', imageUrl: '' },
        { id: `p-50-${Date.now()}`, stage: '50%', title: 'Progres Pelaksanaan 50%', imageUrl: '' },
        { id: `p-100-${Date.now()}`, stage: '100%', title: 'Penyelesaian & Serah Terima 100%', imageUrl: '' },
      ]
    }));
    showToast('Preset Tahapan Dana Desa (0%, 50%, 100%) dibuat', 'info');
  };

  const addCustomProgressSlot = () => {
    setFormData(prev => ({
      ...prev,
      progressPhotos: [
        ...prev.progressPhotos,
        { id: `p-custom-${Date.now()}-${Math.random()}`, stage: '40%', title: 'Dokumentasi Lapangan', imageUrl: '' }
      ]
    }));
  };

  const removeProgressSlot = (index: number) => {
    setFormData(prev => ({
      ...prev,
      progressPhotos: prev.progressPhotos.filter((_, i) => i !== index)
    }));
  };

  const handleOpenModal = (item?: NewsItem) => {
    if (item) {
      setEditingNews(item);
      setFormData({
        title: item.title,
        excerpt: item.excerpt,
        fullContent: item.fullContent,
        tag: item.tag,
        image: item.image,
        author: item.author || '',
        progressPhotos: item.progressPhotos && item.progressPhotos.length > 0 ? [...item.progressPhotos] : [
          { id: `p-0-${Date.now()}`, stage: '0%', title: 'Titik Nol / Persiapan Awal', imageUrl: '' },
          { id: `p-50-${Date.now()}`, stage: '50%', title: 'Progres Pelaksanaan 50%', imageUrl: '' },
          { id: `p-100-${Date.now()}`, stage: '100%', title: 'Penyelesaian & Serah Terima 100%', imageUrl: '' }
        ]
      });
    } else {
      setEditingNews(null);
      setFormData({
        title: '',
        excerpt: '',
        fullContent: '',
        tag: CATEGORIES[0].label,
        image: '',
        author: '',
        progressPhotos: [
          { id: `p-0-${Date.now()}`, stage: '0%', title: 'Titik Nol / Persiapan Awal', imageUrl: '' },
          { id: `p-50-${Date.now()}`, stage: '50%', title: 'Progres Pelaksanaan 50%', imageUrl: '' },
          { id: `p-100-${Date.now()}`, stage: '100%', title: 'Penyelesaian & Serah Terima 100%', imageUrl: '' }
        ]
      });
    }
    setIsModalOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!itemToDelete) return;
    const deletedId = itemToDelete.id;
    try {
      const { error } = await supabase
        .from('saas_settings')
        .update({ value: JSON.stringify(news.filter(n => n.id !== deletedId)) })
        .eq('tenant_id', tenantId)
        .eq('key', 'didesa_news_list');

      if (error) {
        console.error('[AdminBerita] Gagal menghapus berita dari server:', error.message);
        showToast('Gagal menghapus berita: ' + error.message, 'error');
        return;
      }

      setNews(prev => prev.filter(n => n.id !== deletedId));
      localStorage.setItem('didesa_news_list', JSON.stringify(news.filter(n => n.id !== deletedId)));
      window.dispatchEvent(new Event('didesa_news_updated'));
      showToast('Berita berhasil dihapus', 'success');
      setItemToDelete(null);
    } catch (err: any) {
      console.error('[AdminBerita] Error saat menghapus berita:', err?.message || err);
      showToast('Gagal menghapus berita: ' + (err?.message || 'Kesalahan tidak diketahui'), 'error');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const uploadedPhotos = formData.progressPhotos.filter(p => p.imageUrl.trim() !== '');
    
    if (!formData.title || !formData.excerpt || !formData.fullContent) {
      showToast('Harap lengkapi judul, ringkasan, dan isi berita', 'error');
      return;
    }

    if (uploadedPhotos.length === 0 && !formData.image) {
      showToast('Harap unggah minimal 1 foto tahapan kegiatan', 'error');
      return;
    }

    const coverImage = formData.image || uploadedPhotos[0]?.imageUrl || 'https://images.unsplash.com/photo-1541888081156-fce1fa5427d6?auto=format&fit=crop&q=80&w=800';
    const tagInfo = CATEGORIES.find(c => c.label === formData.tag) || CATEGORIES[0];
    const currentDate = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
    const authorName = formData.author || (localStorage.getItem('didesa_auth_user') ? JSON.parse(localStorage.getItem('didesa_auth_user')!).name : 'Admin');

    if (editingNews) {
      setNews(prev => prev.map(n => n.id === editingNews.id ? {
        ...n,
        title: formData.title,
        excerpt: formData.excerpt,
        fullContent: formData.fullContent,
        tag: tagInfo.label,
        tagColor: tagInfo.color,
        image: coverImage,
        author: formData.author || n.author,
        progressPhotos: uploadedPhotos
      } : n));
      showToast('Berita berhasil diperbarui', 'success');
    } else {
      const newItem: NewsItem = {
        id: `n-${Date.now()}`,
        title: formData.title,
        excerpt: formData.excerpt,
        fullContent: formData.fullContent,
        tag: tagInfo.label,
        tagColor: tagInfo.color,
        image: coverImage,
        author: authorName,
        date: currentDate,
        likes: 0,
        comments: [],
        progressPhotos: uploadedPhotos
      };
      setNews(prev => [newItem, ...prev]);
      showToast('Berita berhasil ditambahkan', 'success');
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-gray-100 dark:border-slate-800 shadow-sm">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Kelola Berita & Pengumuman</h1>
          <p className="text-gray-500 dark:text-slate-400 mt-1">Buat dan atur informasi yang tampil di Portal Warga {desaName}.</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative">
            <input 
              type="text" 
              placeholder="Cari berita..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery?.(e.target.value)}
              className="pl-10 pr-4 py-2 rounded-xl border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-all min-w-[200px]"
            />
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          </div>
          <button 
            onClick={() => handleOpenModal()}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium transition-colors flex items-center justify-center gap-2 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            Tambah Berita
          </button>
        </div>
      </div>

      {/* Grid of News */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredNews.map(item => (
          <div key={item.id} className="bg-white dark:bg-slate-900 rounded-3xl overflow-hidden border border-gray-100 dark:border-slate-800 shadow-sm flex flex-col h-full group relative">
            <div className="h-48 bg-cover bg-center overflow-hidden relative">
              <img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-transparent" />
              <span className={`absolute top-4 left-4 inline-block px-2.5 py-1 text-[9px] font-bold rounded-lg tracking-wider border ${item.tagColor}`}>
                {item.tag}
              </span>
              <div className="absolute top-4 right-4 flex gap-2">
                <button onClick={(e) => { e.stopPropagation(); handleOpenModal(item); }} className="p-2 bg-white/90 backdrop-blur-sm hover:bg-white text-blue-600 rounded-lg shadow-sm transition-colors" title="Edit Berita">
                  <Edit2 className="w-4 h-4" />
                </button>
                <button onClick={(e) => { e.stopPropagation(); setItemToDelete(item); }} className="p-2 bg-white/90 backdrop-blur-sm hover:bg-white text-red-600 rounded-lg shadow-sm transition-colors" title="Hapus Berita">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="p-5 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-gray-900 dark:text-white line-clamp-2 text-lg mb-2">{item.title}</h3>
                <p className="text-gray-500 dark:text-slate-400 text-sm line-clamp-2">{item.excerpt}</p>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-100 dark:border-slate-800 flex items-center justify-between text-xs text-gray-500 dark:text-slate-400">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> {item.date}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1"><Heart className="w-3.5 h-3.5 text-emerald-600" /> {item.likes}</span>
                  <span className="flex items-center gap-1"><MessageSquare className="w-3.5 h-3.5 text-blue-600" /> {item.comments.length}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
        {filteredNews.length === 0 && (
          <div className="col-span-full py-12 text-center text-gray-500 dark:text-slate-400 bg-white dark:bg-slate-900 rounded-2xl border border-gray-100 dark:border-slate-800 shadow-sm">
            <Newspaper className="w-12 h-12 mx-auto text-gray-300 dark:text-slate-600 mb-3" />
            <p>Tidak ada berita ditemukan</p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col border border-gray-100 dark:border-slate-800 relative z-50">
            <div className="p-5 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-800/50">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                {editingNews ? 'Edit Berita' : 'Tambah Berita Baru'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-xl transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1">
              <form id="newsForm" onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-sm font-semibold text-gray-700 dark:text-slate-300">Judul Berita *</label>
                    <input 
                      type="text" 
                      required
                      value={formData.title}
                      onChange={e => setFormData({...formData, title: e.target.value})}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      placeholder="Contoh: Pembangunan Jembatan Tani..."
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-sm font-semibold text-gray-700 dark:text-slate-300">Kategori *</label>
                    <select 
                      value={formData.tag}
                      onChange={e => setFormData({...formData, tag: e.target.value})}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    >
                      {CATEGORIES.map(c => <option key={c.label} value={c.label}>{c.label}</option>)}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-sm font-semibold text-gray-700 dark:text-slate-300">Penulis (Opsional)</label>
                    <input 
                      type="text" 
                      value={formData.author}
                      onChange={e => setFormData({...formData, author: e.target.value})}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      placeholder="Contoh: Admin Desa"
                    />
                  </div>

                  {/* Dokumentasi 3 Tahapan Dana Desa & Cover Selection */}
                  <div className="space-y-4 md:col-span-2 p-5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-3xl">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <h4 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                          <ImageIcon className="w-5 h-5 text-emerald-600" />
                          Dokumentasi 3 Tahapan Progress Dana Desa
                        </h4>
                        <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">
                          Unggah foto 3 persentase tahapan (0%, 50%, 100%). Klik <strong className="text-amber-600">Pilih Cover</strong> pada foto untuk menjadikannya Sampul Utama Berita.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={addCustomProgressSlot}
                        className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shrink-0 shadow-sm"
                      >
                        + Tambah Tahap
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                      {formData.progressPhotos.map((photo, idx) => {
                        const isCover = (formData.image && formData.image === photo.imageUrl) || (!formData.image && idx === 0 && photo.imageUrl !== '');
                        return (
                          <div key={photo.id || idx} className={`p-4 rounded-2xl border transition-all flex flex-col justify-between space-y-3 bg-white dark:bg-slate-900 relative ${isCover ? 'border-amber-500 ring-2 ring-amber-500/20 shadow-md' : 'border-gray-200 dark:border-slate-700'}`}>
                            {/* Header: Stage Badge + Star Cover Button */}
                            <div className="flex items-center justify-between">
                              <select
                                value={photo.stage}
                                onChange={e => {
                                  const val = e.target.value;
                                  setFormData(prev => {
                                    const updated = [...prev.progressPhotos];
                                    updated[idx] = { ...updated[idx], stage: val };
                                    return { ...prev, progressPhotos: updated };
                                  });
                                }}
                                className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-xs font-black text-emerald-700 dark:text-emerald-400 outline-none cursor-pointer"
                              >
                                <option value="0%">TAHAP 0%</option>
                                <option value="40%">TAHAP 40%</option>
                                <option value="50%">TAHAP 50%</option>
                                <option value="80%">TAHAP 80%</option>
                                <option value="100%">TAHAP 100%</option>
                              </select>

                              {photo.imageUrl && (
                                <button
                                  type="button"
                                  onClick={() => setFormData(prev => ({ ...prev, image: photo.imageUrl }))}
                                  className={`px-2 py-1 rounded-lg text-[10px] font-extrabold flex items-center gap-1 transition-all cursor-pointer ${
                                    isCover
                                      ? 'bg-amber-500 text-white shadow-sm'
                                      : 'bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-slate-400 hover:bg-amber-100 hover:text-amber-700'
                                  }`}
                                  title="Jadikan Gambar Cover Utama Berita"
                                >
                                  <Star className={`w-3 h-3 ${isCover ? 'fill-white' : ''}`} />
                                  {isCover ? 'Cover Utama' : 'Pilih Cover'}
                                </button>
                              )}
                            </div>

                            {/* Center: Image Upload Dropzone */}
                            <div className="relative h-36 rounded-xl overflow-hidden border border-gray-100 dark:border-slate-800 bg-gray-50 dark:bg-slate-800 flex items-center justify-center group">
                              {photo.imageUrl ? (
                                <>
                                  <img src={photo.imageUrl} alt={photo.title} className="w-full h-full object-cover" />
                                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 p-2">
                                    <label className="p-2 bg-white text-gray-800 rounded-xl cursor-pointer shadow hover:bg-emerald-50 hover:text-emerald-700 transition-colors text-xs font-bold flex items-center gap-1">
                                      <Upload className="w-3.5 h-3.5" /> Ganti
                                      <input
                                        type="file"
                                        accept="image/*"
                                        onChange={e => e.target.files?.[0] && handleProgressPhotoUpload(idx, e.target.files[0])}
                                        disabled={uploadingStageIndex === idx}
                                        className="hidden"
                                      />
                                    </label>
                                    <button
                                      type="button"
                                      onClick={() => removeProgressSlot(idx)}
                                      className="p-2 bg-white text-red-600 rounded-xl shadow hover:bg-red-50 transition-colors"
                                      title="Hapus Slot Tahap Ini"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </>
                              ) : (
                                <label className="w-full h-full flex flex-col items-center justify-center p-3 cursor-pointer text-center hover:bg-emerald-50/50 dark:hover:bg-slate-700/50 transition-colors">
                                  {uploadingStageIndex === idx ? (
                                    <div className="w-6 h-6 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin mb-1" />
                                  ) : (
                                    <Upload className="w-6 h-6 text-emerald-600 mb-1" />
                                  )}
                                  <span className="text-xs font-bold text-gray-700 dark:text-slate-300">
                                    {uploadingStageIndex === idx ? 'Mengunggah...' : `Unggah Foto (${photo.stage})`}
                                  </span>
                                  <span className="text-[10px] text-gray-400 mt-0.5">Format JPG / PNG</span>
                                  <input
                                    type="file"
                                    accept="image/*"
                                    onChange={e => e.target.files?.[0] && handleProgressPhotoUpload(idx, e.target.files[0])}
                                    disabled={uploadingStageIndex === idx}
                                    className="hidden"
                                  />
                                </label>
                              )}
                            </div>

                            {/* Caption Input */}
                            <div>
                              <input
                                type="text"
                                value={photo.title}
                                onChange={e => {
                                  const val = e.target.value;
                                  setFormData(prev => {
                                    const updated = [...prev.progressPhotos];
                                    updated[idx] = { ...updated[idx], title: val };
                                    return { ...prev, progressPhotos: updated };
                                  });
                                }}
                                placeholder="Keterangan foto..."
                                className="w-full px-3 py-1.5 rounded-xl border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 text-xs text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-sm font-semibold text-gray-700 dark:text-slate-300">Ringkasan (Excerpt) *</label>
                    <textarea 
                      required
                      rows={2}
                      value={formData.excerpt}
                      onChange={e => setFormData({...formData, excerpt: e.target.value})}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
                      placeholder="Ringkasan singkat berita untuk ditampilkan di kartu..."
                    />
                  </div>

                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-sm font-semibold text-gray-700 dark:text-slate-300">Isi Berita Lengkap *</label>
                    <textarea 
                      required
                      rows={8}
                      value={formData.fullContent}
                      onChange={e => setFormData({...formData, fullContent: e.target.value})}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      placeholder="Tuliskan isi berita lengkap di sini..."
                    />
                  </div>
                </div>
              </form>
            </div>

            <div className="p-5 border-t border-gray-100 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-800/50 flex justify-end gap-3 shrink-0">
              <button 
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-5 py-2.5 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-xl font-medium transition-colors"
              >
                Batal
              </button>
              <button 
                type="submit"
                form="newsForm"
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium transition-colors shadow-sm"
              >
                {editingNews ? 'Simpan Perubahan' : 'Terbitkan Berita'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modern Confirmation Delete Modal */}
      {itemToDelete && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-md">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl max-w-md w-full p-6 border border-gray-100 dark:border-slate-800 transform transition-all text-center">
            <div className="w-16 h-16 bg-red-50 dark:bg-red-950/50 text-red-600 dark:text-red-400 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-red-100 dark:border-red-900/50 shadow-inner">
              <AlertTriangle className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Hapus Berita Ini?</h3>
            <p className="text-sm text-gray-500 dark:text-slate-400 mb-6 leading-relaxed">
              Apakah Anda yakin ingin menghapus berita <strong className="text-gray-800 dark:text-slate-200">"{itemToDelete.title}"</strong>? Berita yang dihapus akan hilang dari Portal Warga.
            </p>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setItemToDelete(null)}
                className="flex-1 py-3 px-4 rounded-xl border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-slate-300 font-semibold hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors text-sm"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-semibold shadow-lg shadow-red-500/25 transition-all text-sm flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
