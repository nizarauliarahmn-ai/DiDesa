import { useState, useEffect, useMemo, useRef } from 'react';
import { 
  UserPlus, 
  Banknote, 
  Users, 
  ShoppingBasket, 
  AlertTriangle,
  Save,
  Download,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Search,
  X,
  Trash2,
  Database,
  CheckCircle2,
  Check,
  FileText,
  ArrowUpDown,
  CheckSquare,
  Calendar,
  Ban,
  RefreshCw,
  DollarSign,
  Award,
  Printer,
  ExternalLink
} from 'lucide-react';
import { showToast } from '../../utils/toast';
import ConfirmModal from '../common/ConfirmModal';
import { supabase } from '../../utils/supabase';
import { resolveCurrentTenant } from '../../utils/tenantResolver';
import AdminBantuanImport from './bantuan/AdminBantuanImport';
import AdminBantuanTambahPenerima from './bantuan/AdminBantuanTambahPenerima';

// Helper to auto capitalize first letter of each word
const toTitleCase = (str: string) => {
  if (!str) return str;
  return str.replace(/\b[a-z]/g, (char) => char.toUpperCase());
};

export default function AdminBantuan({
  searchQuery: externalSearchQuery,
  setSearchQuery: externalSetSearchQuery,
  debouncedSearchQuery: externalDebouncedSearchQuery,
  onNavigateToTab,
  onSetPresetResidentNik
}: {
  searchQuery?: string;
  setSearchQuery?: (val: string) => void;
  debouncedSearchQuery?: string;
  onNavigateToTab?: (tab: string) => void;
  onSetPresetResidentNik?: (nik: string) => void;
} = {}) {
  const [residents, setResidents] = useState<any[]>([]);
  const [dbEngine, setDbEngine] = useState<string>("Loading...");
  const [loading, setLoading] = useState(true);
  const [tenantId, setTenantId] = useState<string | null>(null);
  const [selectedProgram, setSelectedProgram] = useState<string>("BLT Dana Desa");
  
  // Custom confirm state
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  const showConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmState({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmState(prev => ({ ...prev, isOpen: false }));
      }
    });
  };
  const [showOverlapOnly, setShowOverlapOnly] = useState<boolean>(false);
  const [localSearchQuery, setLocalSearchQuery] = useState("");
  const [localDebouncedSearchQuery, setLocalDebouncedSearchQuery] = useState("");
  
  const searchQuery = externalSearchQuery !== undefined ? externalSearchQuery : localSearchQuery;
  const setSearchQuery = externalSetSearchQuery !== undefined ? externalSetSearchQuery : setLocalSearchQuery;

  // Handle local debouncing if no external debounced query is provided
  useEffect(() => {
    if (externalDebouncedSearchQuery !== undefined) return;
    const timer = setTimeout(() => {
      setLocalDebouncedSearchQuery(localSearchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [localSearchQuery, externalDebouncedSearchQuery]);

  const debouncedSearchQuery = externalDebouncedSearchQuery !== undefined ? externalDebouncedSearchQuery : localDebouncedSearchQuery;
  
  // Modal states
  const [showModal, setShowModal] = useState(false);
  const [showBaModal, setShowBaModal] = useState(false);
  const [showTambahPenerima, setShowTambahPenerima] = useState(false);
const MONTHS_LIST = [
  { id: 'Jan', label: 'Jan', fullName: 'Januari' },
  { id: 'Feb', label: 'Feb', fullName: 'Februari' },
  { id: 'Mar', label: 'Mar', fullName: 'Maret' },
  { id: 'Apr', label: 'Apr', fullName: 'April' },
  { id: 'Mei', label: 'Mei', fullName: 'Mei' },
  { id: 'Jun', label: 'Jun', fullName: 'Juni' },
  { id: 'Jul', label: 'Jul', fullName: 'Juli' },
  { id: 'Ags', label: 'Ags', fullName: 'Agustus' },
  { id: 'Sep', label: 'Sep', fullName: 'September' },
  { id: 'Okt', label: 'Okt', fullName: 'Oktober' },
  { id: 'Nov', label: 'Nov', fullName: 'November' },
  { id: 'Des', label: 'Des', fullName: 'Desember' }
];

const MONTHLY_PROGRAMS = ['BLT Dana Desa', 'Bantuan Rastrada'];

  // Monthly Disbursement State (Nik -> Array of Month IDs e.g. ['Jan', 'Feb', 'Mar'])
  const [disbursedMonths, setDisbursedMonths] = useState<Record<string, string[]>>(() => {
    try {
      const stored = localStorage.getItem(`disbursed_months_${selectedProgram}`);
      return stored ? JSON.parse(stored) : {};
    } catch (e) { return {}; }
  });

  // Sync when selectedProgram changes
  useEffect(() => {
    try {
      const stored = localStorage.getItem(`disbursed_months_${selectedProgram}`);
      setDisbursedMonths(stored ? JSON.parse(stored) : {});
    } catch (e) {
      setDisbursedMonths({});
    }
  }, [selectedProgram]);

  // Persist to localStorage & Supabase Cloud
  useEffect(() => {
    if (!selectedProgram) return;
    try {
      localStorage.setItem(`disbursed_months_${selectedProgram}`, JSON.stringify(disbursedMonths));
      if (tenantId) {
        supabase.from('saas_settings').upsert({
          tenant_id: tenantId,
          key: `disbursed_months_${selectedProgram}`,
          value: JSON.stringify(disbursedMonths),
          updated_at: new Date().toISOString()
        }, { onConflict: 'tenant_id,key' }).then();
      }
    } catch (e) {}
  }, [disbursedMonths, selectedProgram, tenantId]);

  const handleToggleMonth = (nik: string, monthId: string) => {
    setDisbursedMonths(prev => {
      const current = prev[nik] || [];
      const updated = current.includes(monthId) ? current.filter(m => m !== monthId) : [...current, monthId];
      return { ...prev, [nik]: updated };
    });
  };

  const handleSetMonthsUntil = (nik: string, maxIdx: number) => {
    const monthsToSet = MONTHS_LIST.slice(0, maxIdx + 1).map(m => m.id);
    setDisbursedMonths(prev => ({ ...prev, [nik]: monthsToSet }));
  };

  const handleSetAll12Months = (nik: string) => {
    const allMonths = MONTHS_LIST.map(m => m.id);
    setDisbursedMonths(prev => ({ ...prev, [nik]: allMonths }));
  };

  const handleResetMonths = (nik: string) => {
    setDisbursedMonths(prev => {
      const copy = { ...prev };
      delete copy[nik];
      return copy;
    });
  };
  const [searchResidentQuery, setSearchResidentQuery] = useState("");
  const [selectedResidentNik, setSelectedResidentNik] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // Dedicated view states for "Tambah Penerima Bantuan"
  const [showAddView, setShowAddView] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [formProgram, setFormProgram] = useState("");
  const [formAmount, setFormAmount] = useState("300000");
  const [formFunding, setFormFunding] = useState("");
  const [criteriaChecked, setCriteriaChecked] = useState<Record<string, boolean>>({});
  const [showRecommendations, setShowRecommendations] = useState(false);
  const [formYear, setFormYear] = useState(new Date().getFullYear().toString());
  const [filterYear, setFilterYear] = useState(new Date().getFullYear().toString());
  const searchContainerRef = useRef<HTMLDivElement>(null);
  const [selectedResidentDetailModal, setSelectedResidentDetailModal] = useState<any | null>(null);

  // Bantuan Status System: usulan / aktif / pernah_mendapat
  const [activeStatusTab, setActiveStatusTab] = useState<'usulan' | 'aktif' | 'pernah_mendapat'>('aktif');
  const [bansosData, setBansosData] = useState<any[]>([]);
  const [removingNiks, setRemovingNiks] = useState<Set<string>>(new Set());

  // New Table Optimization States
  const [salurFilter] = useState<'all'>('all');
  const [selectedNiks, setSelectedNiks] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [sortField, setSortField] = useState<'name' | 'nik' | 'rtRw' | 'status'>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Comprehensive Print Suite States
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [printDocType, setPrintDocType] = useState<'rekap_12bln' | 'tanda_terima' | 'ba_musdes' | 'slip_warga'>('rekap_12bln');
  const [selectedPrintResident, setSelectedPrintResident] = useState<any | null>(null);
  const [selectedPrintMonth, setSelectedPrintMonth] = useState<string>(MONTHS_LIST[new Date().getMonth()].id);

  // Bulk Stop Modal State
  const [showBulkStopModal, setShowBulkStopModal] = useState(false);
  const [bulkStopDate, setBulkStopDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [bulkStopReason, setBulkStopReason] = useState('Meninggal Dunia');
  const [bulkStopNote, setBulkStopNote] = useState('');

  // Aparatur Desa Data (for print signatures)
  const [namaKades, setNamaKades] = useState(() => localStorage.getItem('kop_kades') || '');
  const [villageName, setVillageName] = useState(() => localStorage.getItem('village_name') || localStorage.getItem('kop_desa') || '');
  const [bpdList, setBpdList] = useState<any[]>(() => {
    try { return JSON.parse(localStorage.getItem('village_bpd') || '[]'); } catch { return []; }
  });
  const [officers, setOfficers] = useState<any[]>(() => {
    try { return JSON.parse(localStorage.getItem('village_officers') || '[]'); } catch { return []; }
  });

  // KOP Surat Data (for print headers)
  const [kopKabupaten, setKopKabupaten] = useState(() => localStorage.getItem('kop_kabupaten') || 'Pemerintah Kabupaten Hulu Sungai Selatan');
  const [kopKecamatan, setKopKecamatan] = useState(() => localStorage.getItem('kop_kecamatan') || 'Kecamatan Simpur');
  const [kopDesa, setKopDesa] = useState(() => localStorage.getItem('kop_desa') || 'Desa Wasah Hilir');
  const [kopAlamat, setKopAlamat] = useState(() => localStorage.getItem('kop_alamat') || '');
  const [kopKontak, setKopKontak] = useState(() => localStorage.getItem('kop_kontak') || '');
  const [kopLogoUrl, setKopLogoUrl] = useState(() => localStorage.getItem('kop_logo_url') || 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Lambang_Kabupaten_Hulu_Sungai_Selatan.svg/200px-Lambang_Kabupaten_Hulu_Sungai_Selatan.svg.png');

  // Load aparatur data from Supabase when tenantId is available
  useEffect(() => {
    if (!tenantId) return;
    const loadAparatur = async () => {
      try {
        const { data } = await supabase.from('saas_settings').select('key, value').eq('tenant_id', tenantId);
        if (!data) return;
        data.forEach(item => {
          if (item.key === 'village_bpd' && item.value) {
            try { const v = JSON.parse(item.value); setBpdList(v); localStorage.setItem('village_bpd', item.value); } catch {}
          }
          if (item.key === 'village_officers' && item.value) {
            try { const v = JSON.parse(item.value); setOfficers(v); localStorage.setItem('village_officers', item.value); } catch {}
          }
          if (item.key === 'kop_kades' && item.value) {
            setNamaKades(item.value); localStorage.setItem('kop_kades', item.value);
          }
          if (item.key === 'village_name' && item.value) {
            setVillageName(item.value); localStorage.setItem('village_name', item.value);
          }
          if (item.key === 'kop_kabupaten' && item.value) {
            setKopKabupaten(item.value); localStorage.setItem('kop_kabupaten', item.value);
          }
          if (item.key === 'kop_kecamatan' && item.value) {
            setKopKecamatan(item.value); localStorage.setItem('kop_kecamatan', item.value);
          }
          if (item.key === 'kop_desa' && item.value) {
            setKopDesa(item.value); localStorage.setItem('kop_desa', item.value);
          }
          if (item.key === 'kop_alamat' && item.value) {
            setKopAlamat(item.value); localStorage.setItem('kop_alamat', item.value);
          }
          if (item.key === 'kop_kontak' && item.value) {
            setKopKontak(item.value); localStorage.setItem('kop_kontak', item.value);
          }
          if (item.key === 'kop_logo_url' && item.value) {
            setKopLogoUrl(item.value); localStorage.setItem('kop_logo_url', item.value);
          }
        });
      } catch {}
    };
    loadAparatur();
  }, [tenantId]);

  // Resolve signature names from aparatur data
  const ketuaBpdName = useMemo(() => {
    const found = bpdList.find((b: any) => String(b.role || '').toLowerCase().includes('ketua'));
    return found?.name || '( ................................ )';
  }, [bpdList]);

  const kasiKesraName = useMemo(() => {
    const found = officers.find((o: any) => {
      const role = String(o.role || '').toLowerCase();
      return role.includes('kasi') && (role.includes('kesejahteraan') || role.includes('kesra') || role.includes('sosial'));
    });
    return found?.name || '( ................................ )';
  }, [officers]);

  const kadesName = useMemo(() => namaKades || '( ................................ )', [namaKades]);

  // Manual Resident Entry States
  const [isManualResident, setIsManualResident] = useState(false);
  const [manualResidentData, setManualResidentData] = useState({
    name: '',
    nik: '',
    address: '',
    rt: '001',
    rw: '001',
    desa: 'Sukamaju'
  });

  // Custom Criteria States
  const [customCriteriaList, setCustomCriteriaList] = useState<string[]>([]);
  const [newCriteriaText, setNewCriteriaText] = useState('');
  const [showAddCriteriaForm, setShowAddCriteriaForm] = useState(false);

  // Close recommendations dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setShowRecommendations(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Helper for scoring & Lansia Tunggal Detection
  const isLansiaTunggal = (r: any) => {
    const birthYear = r.birthDate ? new Date(r.birthDate).getFullYear() : (r.age ? new Date().getFullYear() - Number(r.age) : 0);
    const age = birthYear > 0 ? new Date().getFullYear() - birthYear : (Number(r.age) || 0);
    if (age < 60) return false;

    if (!r.noKk) return true;
    const sameKkMembers = residents.filter(item => item.noKk === r.noKk && item.is_deleted !== 1);
    return sameKkMembers.length <= 1;
  };

  const calculateVulnerabilityScore = (r: any) => {
    let score = 0;
    
    // Age calculation
    const birthYear = r.birthDate ? new Date(r.birthDate).getFullYear() : (r.age ? new Date().getFullYear() - Number(r.age) : 0);
    const age = birthYear > 0 ? new Date().getFullYear() - birthYear : (Number(r.age) || 0);
    
    if (age >= 60) score += 40;
    else if (age >= 50) score += 20;

    // Single Elderly (Lansia Tunggal) HUGE Priority Boost (+60)
    if (isLansiaTunggal(r)) {
      score += 60;
    }
    
    // Job scoring
    const job = (r.job || '').toLowerCase();
    if (job.includes('belum') || job.includes('tidak bekerja')) score += 40;
    if (job.includes('mengurus rumah tangga')) score += 20;
    if (job.includes('buruh harian lepas') || job.includes('buruh tani')) score += 30;
    if (job.includes('pensiunan')) score += 10;
    
    // Already receiving aids (Penalty)
    if (r.activeAids && r.activeAids.length > 0) score -= 50;

    return score;
  };

  // Filter residents for search in the dedicated Add Recipient view
  const searchResultsForAddView = useMemo(() => {
    if (!formProgram) return [];
    let list = [...residents];
    
    if (searchResidentQuery.trim() !== "") {
      const q = searchResidentQuery.toLowerCase();
      list = list.filter(r => 
        r.name?.toLowerCase().includes(q) || 
        r.nik?.includes(q)
      );
      return list.slice(0, 5); // Limit search results to 5
    } else if (showRecommendations) {
      // Smart Recommendation Mode (when toggled on)
      // Filter out people who already have THIS program for THIS year
      list = list.filter(r => !(r.activeAids || []).includes(`${formProgram} (${formYear})`));
      
      // Calculate scores & flag Lansia Tunggal
      const scoredList = list.map(r => ({
        ...r,
        isSingleElderly: isLansiaTunggal(r),
        vulnerabilityScore: calculateVulnerabilityScore(r)
      }));
      
      // Sort by highest score
      scoredList.sort((a, b) => b.vulnerabilityScore - a.vulnerabilityScore);
      
      // Return top 6
      return scoredList.slice(0, 6);
    }
    
    return [];
  }, [residents, formProgram, searchResidentQuery, showRecommendations]);

  // Fetch residents and DB status
  const fetchData = async () => {
    try {
      setLoading(true);
      const resolvedTenant = await resolveCurrentTenant();
      setTenantId(resolvedTenant);

      if (resolvedTenant) {
        const { data, error } = await supabase
          .from('residents')
          .select('*')
          .eq('tenant_id', resolvedTenant)
          .order('name', { ascending: true });

        if (data && !error) {
           const formatted = data.map(r => ({
             ...r,
             noKk: r.no_kk,
             rtRw: r.rt_rw,
             birthPlace: r.birth_place,
             birthDate: r.birth_date,
             bloodType: r.blood_type,
             domicileStatus: r.domicile_status,
             familyRelation: r.family_relation,
             fatherName: r.father_name,
             motherName: r.mother_name,
             activeAids: typeof r.active_aids === 'string' ? JSON.parse(r.active_aids) : (r.active_aids || []),
             genderColor: r.gender_color,
             statusColor: r.status_color
           }));
           setResidents(formatted.filter(r => r.is_deleted !== 1));
         }

         // Load bansos_recipients for status tracking
         const { data: bansos } = await supabase
           .from('bansos_recipients')
           .select('*')
           .eq('tenant_id', resolvedTenant)
           .order('created_at', { ascending: false });
         if (bansos) setBansosData(bansos);
       }
       setDbEngine("Supabase (Multi-Tenant)");
    } catch (err) {
      console.error("Failed to fetch data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Helper function to extract genuine active aid programs (excluding STOPPED entries & deceased residents)
  const getActiveAidPrograms = (resident: any, targetYear: string = filterYear) => {
    const statusStr = (resident.status || '').toLowerCase();
    if (statusStr.includes('meninggal') || statusStr === 'mati' || statusStr === 'wafat' || statusStr === 'archived') {
      return [];
    }

    const rawAids = Array.isArray(resident.activeAids)
      ? resident.activeAids
      : (typeof resident.active_aids === 'string' ? JSON.parse(resident.active_aids || '[]') : (resident.active_aids || []));

    const validActive = rawAids.filter((a: string) => 
      typeof a === 'string' && 
      !a.startsWith('STOPPED') && 
      a !== 'DTSEN_VERIFIED'
    );

    if (targetYear === "Semua Tahun") {
      return validActive;
    }
    return validActive.filter((a: string) => a.includes(`(${targetYear})`));
  };

  // Compute stats dynamically
  const stats = useMemo(() => {
    const isAllYears = filterYear === "Semua Tahun";
    const yearFilter = isAllYears ? null : Number(filterYear);
    
    // uniquePrograms: all programs from all statuses (for dropdown)
    const programCounts: Record<string, number> = {};
    bansosData
      .filter(b => isAllYears || b.tahun === yearFilter)
      .forEach(b => {
        programCounts[b.program_id] = (programCounts[b.program_id] || 0) + 1;
      });

    const yearStr = yearFilter?.toString();
    residents.forEach(r => {
      const aids = getActiveAidPrograms(r, filterYear);
      aids.forEach((aid: string) => {
        const match = aid.match(/^(.+?)\s*\(\d{4}\)$/);
        const progName = match ? match[1].trim() : aid.trim();
        if (!yearStr || aid.includes(`(${yearStr})`) || !aid.match(/\(\d{4}\)$/)) {
          programCounts[progName] = (programCounts[progName] || 0) + 1;
        }
      });
    });

    const uniquePrograms = Object.keys(programCounts).sort();

    // selectedCount: only from bansos_recipients filtered by active status tab
    const selectedCount = bansosData
      .filter(b => b.program_id === selectedProgram && b.status === activeStatusTab && (isAllYears || b.tahun === yearFilter))
      .length;

    const overlapResidents = residents.filter(r => getActiveAidPrograms(r, filterYear).length > 1);
    
    return {
      selectedCount,
      uniquePrograms,
      programCounts,
      overlaps: overlapResidents
    };
  }, [residents, filterYear, bansosData, selectedProgram, activeStatusTab]);

  // Filtered list of residents based on search, selected program, salurFilter, and sort
  const filteredResidents = useMemo(() => {
    let list = residents;

    const isAllYears = filterYear === "Semua Tahun";
    const yearFilter = isAllYears ? null : Number(filterYear);

    // Status Tab Filter (Usulan / Aktif / Pernah Mendapat)
    const niksByStatus = bansosData
      .filter(b => b.program_id === selectedProgram && b.status === activeStatusTab && (isAllYears || b.tahun === yearFilter))
      .map(b => b.resident_id);
    const uniqueNiksByStatus = new Set(niksByStatus);

    if (activeStatusTab === 'usulan' || activeStatusTab === 'pernah_mendapat') {
      // Gabungkan: residents yang ada di bansos + bansos yang NIK-nya belum ada di residents
      const matched = residents.filter(r => uniqueNiksByStatus.has(r.nik));
      const matchedNiks = new Set(matched.map(r => r.nik));
      // Buat synthetic resident untuk NIK yang ada di bansos tapi belum di residents
      const orphanEntries = bansosData
        .filter(b => b.program_id === selectedProgram && b.status === activeStatusTab && (isAllYears || b.tahun === yearFilter) && !matchedNiks.has(b.resident_id))
        .map(b => ({
          nik: b.resident_id,
          name: b.nama || 'Data Usulan',
          rt: '',
          rw: '',
          activeAids: [],
          is_deleted: 0,
          isOrphan: true,
          keterangan: b.keterangan || '',
          photo_url: b.photo_url || '',
          bansosId: b.id,
          bansosStatus: b.status,
          bansosTahun: b.tahun
        }));
      list = [...matched, ...orphanEntries];
    } else {
      // For aktif: use bansosData as primary, fallback to residents.active_aids for legacy
      if (showOverlapOnly) {
        list = stats.overlaps;
      } else {
        const niksFromBansos = new Set(
          bansosData
            .filter(b => b.program_id === selectedProgram && b.status === 'aktif' && (isAllYears || b.tahun === yearFilter))
            .map(b => b.resident_id)
        );
        const niksFromActiveAids = new Set(
          residents
            .filter(r => getActiveAidPrograms(r, filterYear).some((a: string) => a.startsWith(selectedProgram)))
            .map(r => r.nik)
        );
        const allNiks = new Set([...niksFromBansos, ...niksFromActiveAids]);
        list = residents.filter(r => allNiks.has(r.nik));
      }
    }

    // Status Salur Filter
    const currentMonthId = MONTHS_LIST[new Date().getMonth()].id; // e.g. 'Ags'
    if (salurFilter === 'pending_month') {
      list = list.filter(r => !(disbursedMonths[r.nik] || []).includes(currentMonthId));
    } else if (salurFilter === 'disbursed_month') {
      list = list.filter(r => (disbursedMonths[r.nik] || []).includes(currentMonthId));
    } else if (salurFilter === 'lunas') {
      list = list.filter(r => (disbursedMonths[r.nik] || []).length === 12);
    }

    // Search query filter
    if (debouncedSearchQuery.trim() !== "") {
      const q = debouncedSearchQuery.toLowerCase();
      list = list.filter(r => 
        r.name?.toLowerCase().includes(q) || 
        r.nik?.includes(q) || 
        r.rtRw?.includes(q) ||
        r.desa?.toLowerCase().includes(q)
      );
    }

    // Sorting
    list = [...list].sort((a, b) => {
      let valA = a[sortField] || '';
      let valB = b[sortField] || '';
      if (sortField === 'status') {
        const countA = (disbursedMonths[a.nik] || []).length;
        const countB = (disbursedMonths[b.nik] || []).length;
        valA = String(countA);
        valB = String(countB);
      }
      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

    return list;
  }, [residents, selectedProgram, showOverlapOnly, debouncedSearchQuery, stats.overlaps, salurFilter, disbursedMonths, sortField, sortDirection, filterYear, bansosData, activeStatusTab]);

  // Auto-select first program if selectedProgram is not in the list
  useEffect(() => {
    if (stats.uniquePrograms.length > 0 && !stats.uniquePrograms.includes(selectedProgram)) {
      setSelectedProgram(stats.uniquePrograms[0]);
    }
  }, [stats.uniquePrograms]);

  // Reset pagination & selection when primary filters change
  useEffect(() => {
    setCurrentPage(1);
    setSelectedNiks([]);
  }, [selectedProgram, showOverlapOnly, salurFilter, debouncedSearchQuery, filterYear, activeStatusTab]);

  // Paginated Residents Slice
  const paginatedResidents = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredResidents.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredResidents, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredResidents.length / itemsPerPage) || 1;

  // Print: ALL recipients for selected program (not filtered by tab)
  const printAllResidents = useMemo(() => {
    const isAllYears = filterYear === "Semua Tahun";
    const yearFilter = isAllYears ? null : Number(filterYear);
    const niksFromBansos = new Set(
      bansosData
        .filter(b => b.program_id === selectedProgram && (isAllYears || b.tahun === yearFilter))
        .map(b => b.resident_id)
    );
    const niksFromActiveAids = new Set(
      residents
        .filter(r => getActiveAidPrograms(r, filterYear).some((a: string) => a.startsWith(selectedProgram)))
        .map(r => r.nik)
    );
    const allNiks = new Set([...niksFromBansos, ...niksFromActiveAids]);
    const matched = residents.filter(r => allNiks.has(r.nik));
    const matchedNiks = new Set(matched.map(r => r.nik));
    const orphanEntries = bansosData
      .filter(b => b.program_id === selectedProgram && (isAllYears || b.tahun === yearFilter) && !matchedNiks.has(b.resident_id))
      .map(b => ({
        nik: b.resident_id,
        name: b.nama || 'Data Usulan',
        rt: '',
        rw: '',
        isOrphan: true
      }));
    return [...matched, ...orphanEntries];
  }, [residents, bansosData, selectedProgram, filterYear]);

  // Calculate Nominal Amount Disbursed
  const programAmountVal = useMemo(() => {
    if (selectedProgram === "BLT Dana Desa") return 300000;
    if (selectedProgram === "Program Keluarga Harapan (PKH)") return 600000;
    if (selectedProgram === "Bantuan Pangan Non-Tunai") return 200000;
    return 300000;
  }, [selectedProgram]);

  const totalNominalDisbursed = useMemo(() => {
    return filteredResidents.reduce((acc, r) => {
      const count = (disbursedMonths[r.nik] || []).length;
      return acc + (count * programAmountVal);
    }, 0);
  }, [filteredResidents, disbursedMonths, programAmountVal]);

  // Sort Toggle Handler
  const handleSort = (field: 'name' | 'nik' | 'rtRw' | 'status') => {
    if (sortField === field) {
      setSortDirection(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Bulk Actions
  const handleSelectAllOnPage = () => {
    const pageNiks = paginatedResidents.map(r => r.nik);
    const allSelected = pageNiks.every(nik => selectedNiks.includes(nik));
    if (allSelected) {
      setSelectedNiks(prev => prev.filter(nik => !pageNiks.includes(nik)));
    } else {
      setSelectedNiks(prev => Array.from(new Set([...prev, ...pageNiks])));
    }
  };

  const handleBulkDisburse = (shouldDisburse: boolean) => {
    if (selectedNiks.length === 0) return;
    const currentMonthId = MONTHS_LIST[new Date().getMonth()].id;
    setDisbursedMonths(prev => {
      const copy = { ...prev };
      selectedNiks.forEach(nik => {
        const current = copy[nik] || [];
        if (shouldDisburse) {
          if (!current.includes(currentMonthId)) {
            copy[nik] = [...current, currentMonthId];
          }
        } else {
          copy[nik] = current.filter(m => m !== currentMonthId);
        }
      });
      return copy;
    });
    if (shouldDisburse) {
      showToast(`Berhasil menandai ${selectedNiks.length} warga disalurkan untuk bulan ${MONTHS_LIST[new Date().getMonth()].fullName}`, "success");
    } else {
      showToast(`Status penyaluran bulan ${MONTHS_LIST[new Date().getMonth()].fullName} dibatalkan untuk ${selectedNiks.length} warga`, "info");
    }
    setSelectedNiks([]);
  };

  // Single Rollforward to Next Year
  const handleSingleRollforward = async (resident: any, nextYear: string) => {
    const newAidTag = `${selectedProgram} (${nextYear})`;
    showConfirm(
      `Teruskan Bantuan ke Tahun ${nextYear}`,
      `Apakah Anda yakin ingin mendaftarkan ${resident.name} untuk mendapatkan program "${selectedProgram}" pada Tahun ${nextYear}?`,
      async () => {
        setIsSaving(true);
        try {
          if (!tenantId) throw new Error("Tenant ID tidak ditemukan");
          const currentAids = resident.activeAids || [];
          if (currentAids.includes(newAidTag)) {
            showToast(`${resident.name} sudah terdaftar pada tahun ${nextYear}`, "info");
            return;
          }
          const updatedAids = [...currentAids, newAidTag];
          const { error } = await supabase
            .from('residents')
            .update({ active_aids: updatedAids })
            .eq('nik', resident.nik)
            .eq('tenant_id', tenantId);

          if (!error) {
            setResidents(prev => prev.map(r => r.nik === resident.nik ? { ...r, activeAids: updatedAids } : r));
            showToast(`Berhasil meneruskan ${resident.name} ke program tahun ${nextYear}!`, "success");
          } else {
            throw error;
          }
        } catch (err: any) {
          showToast(err.message || "Gagal memperpanjang bantuan", "error");
        } finally {
          setIsSaving(false);
        }
      }
    );
  };

  // Bulk Rollforward to Next Year
  const handleBulkRollforwardNextYear = async () => {
    if (selectedNiks.length === 0) return;
    
    const nextYear = filterYear !== "Semua Tahun" ? (parseInt(filterYear) + 1).toString() : (new Date().getFullYear() + 1).toString();
    const newAidTag = `${selectedProgram} (${nextYear})`;

    showConfirm(
      `Teruskan Bantuan ke Tahun ${nextYear}`,
      `Apakah Anda yakin ingin mendaftarkan ${selectedNiks.length} warga terpilih untuk mendapatkan program "${selectedProgram}" pada Tahun Anggaran ${nextYear}?`,
      async () => {
        setIsSaving(true);
        try {
          if (!tenantId) throw new Error("Tenant ID tidak ditemukan");

          let updatedCount = 0;
          const updatedResidents = [...residents];

          for (const nik of selectedNiks) {
            const target = updatedResidents.find(r => r.nik === nik);
            if (target) {
              const currentAids = target.activeAids || [];
              if (!currentAids.includes(newAidTag)) {
                const updatedAids = [...currentAids, newAidTag];
                const { error } = await supabase
                  .from('residents')
                  .update({ active_aids: updatedAids })
                  .eq('nik', nik)
                  .eq('tenant_id', tenantId);

                if (!error) {
                  target.activeAids = updatedAids;
                  updatedCount++;
                }
              }
            }
          }

          setResidents(updatedResidents);
          setSelectedNiks([]);
          showToast(`Berhasil meneruskan ${updatedCount} warga ke program tahun ${nextYear}!`, "success");
        } catch (err: any) {
          showToast(err.message || "Gagal memperpanjang bantuan massal", "error");
        } finally {
          setIsSaving(false);
        }
      }
    );
  };

  // Bulk Termination with Detailed Date & Month logging
  const handleConfirmBulkStopAid = async () => {
    if (selectedNiks.length === 0) return;
    if (!bulkStopReason || bulkStopReason.trim() === '') {
      showToast("Alasan penghentian wajib diisi", "error");
      return;
    }

    // Format date string for Indonesian readability e.g. "31 Juli 2026"
    let formattedDateStr = bulkStopDate;
    try {
      const d = new Date(bulkStopDate);
      if (!isNaN(d.getTime())) {
        formattedDateStr = d.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
      }
    } catch(e) {}

    const yearTag = filterYear !== "Semua Tahun" ? filterYear : new Date().getFullYear().toString();
    const programTarget = `${selectedProgram} (${yearTag})`;

    setIsSaving(true);
    try {
      if (!tenantId) throw new Error("Tenant ID tidak ditemukan");

      let stoppedCount = 0;
      const updatedResidents = [...residents];

      for (const nik of selectedNiks) {
        const target = updatedResidents.find(r => r.nik === nik);
        if (target) {
          const currentAids = target.activeAids || [];
          const updatedAids = currentAids.map((aid: string) => {
            if (aid.startsWith(selectedProgram)) {
              return `STOPPED: ${aid} | Tgl: ${formattedDateStr} | Alasan: ${bulkStopReason.trim()}${bulkStopNote.trim() ? ' | Catatan: ' + bulkStopNote.trim() : ''}`;
            }
            return aid;
          });

          const updatePayload: any = { active_aids: updatedAids };
          if (bulkStopReason.toLowerCase().includes('meninggal')) {
            updatePayload.status = 'Meninggal';
            target.status = 'Meninggal';
          }

          const { error } = await supabase
            .from('residents')
            .update(updatePayload)
            .eq('nik', nik)
            .eq('tenant_id', tenantId);

          if (!error) {
            target.activeAids = updatedAids;
            stoppedCount++;
          }
        }
      }

      setResidents(updatedResidents);
      setSelectedNiks([]);
      setShowBulkStopModal(false);
      showToast(`Berhasil menghentikan bantuan untuk ${stoppedCount} warga terpilih pada ${formattedDateStr}!`, "success");
    } catch (err: any) {
      showToast(err.message || "Gagal menghentikan bantuan massal", "error");
    } finally {
      setIsSaving(false);
    }
  };

  // === STATUS TRANSITION: Usulan → Aktif (Setujui) ===
  const handleApproveBansos = async (recordId: string, residentNik: string, programId: string, tahun: number) => {
    if (!tenantId) return;
    try {
      const yearTag = tahun?.toString() || new Date().getFullYear().toString();
      const aidTag = `${programId} (${yearTag})`;

      // Update bansos_recipients status
      const { error } = await supabase
        .from('bansos_recipients')
        .update({ status: 'aktif', tahun_mulai: tahun })
        .eq('id', recordId)
        .eq('tenant_id', tenantId);

      if (error) throw error;

      // Also add to residents.active_aids
      const target = residents.find(r => r.nik === residentNik);
      if (target) {
        const currentAids = target.activeAids || [];
        if (!currentAids.includes(aidTag)) {
          const updatedAids = [...currentAids, aidTag];
          await supabase
            .from('residents')
            .update({ active_aids: updatedAids })
            .eq('nik', residentNik)
            .eq('tenant_id', tenantId);
          setResidents(prev => prev.map(r => r.nik === residentNik ? { ...r, activeAids: updatedAids } : r));
        }
      }

      setBansosData(prev => prev.map(b => b.id === recordId ? { ...b, status: 'aktif' } : b));
      showToast(`Usulan ${programId} untuk warga ini telah disetujui!`, "success");
    } catch (err: any) {
      showToast(err.message || "Gagal menyetujui usulan", "error");
    }
  };

  // === STATUS TRANSITION: Aktif → Pernah Mendapat (Hentikan) ===
  const handleStopBansos = async (recordId: string, residentNik: string, programId: string, tahun: number, alasan: string, catatan?: string) => {
    if (!tenantId) return;
    if (!alasan || alasan.trim() === '') {
      showToast("Alasan penghentian wajib diisi", "error");
      return;
    }
    try {
      const today = new Date().toISOString().split('T')[0];
      const yearTag = tahun?.toString() || new Date().getFullYear().toString();
      const aidTag = `${programId} (${yearTag})`;

      // Update bansos_recipients
      const { error } = await supabase
        .from('bansos_recipients')
        .update({
          status: 'pernah_mendapat',
          tahun_akhir: tahun,
          alasan_berhenti: alasan.trim(),
          tanggal_berhenti: today
        })
        .eq('id', recordId)
        .eq('tenant_id', tenantId);

      if (error) throw error;

      // Also prefix STOPPED in residents.active_aids
      const target = residents.find(r => r.nik === residentNik);
      if (target) {
        const currentAids = target.activeAids || [];
        const formattedDate = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
        const updatedAids = currentAids.map((aid: string) => {
          if (aid === aidTag || aid.startsWith(selectedProgram)) {
            return `STOPPED: ${aid} | Tgl: ${formattedDate} | Alasan: ${alasan.trim()}${catatan ? ' | Catatan: ' + catatan : ''}`;
          }
          return aid;
        });

        const updatePayload: any = { active_aids: updatedAids };
        if (alasan.toLowerCase().includes('meninggal')) {
          updatePayload.status = 'Meninggal';
        }

        await supabase
          .from('residents')
          .update(updatePayload)
          .eq('nik', residentNik)
          .eq('tenant_id', tenantId);
        setResidents(prev => prev.map(r => r.nik === residentNik ? { ...r, activeAids: updatedAids } : r));
      }

      setBansosData(prev => prev.map(b => b.id === recordId ? { ...b, status: 'pernah_mendapat', alasan_berhenti: alasan, tanggal_berhenti: today } : b));
      showToast(`Bantuan ${programId} telah dihentikan.`, "success");
    } catch (err: any) {
      showToast(err.message || "Gagal menghentikan bantuan", "error");
    }
  };

  // === Bulk Approve: Usulan → Aktif ===
  const handleBulkApprove = async () => {
    if (selectedNiks.length === 0) return;
    setIsSaving(true);
    try {
      if (!tenantId) throw new Error("Tenant ID tidak ditemukan");
      const yearTag = filterYear !== "Semua Tahun" ? filterYear : new Date().getFullYear().toString();
      const aidTag = `${selectedProgram} (${yearTag})`;
      const year = Number(yearTag);

      let approvedCount = 0;
      // Find bansos records that are 'usulan' for selected NIKs
      for (const nik of selectedNiks) {
        const record = bansosData.find(b => b.resident_id === nik && b.program_id === selectedProgram && b.status === 'usulan' && b.tahun === year);
        if (!record) continue;

        const { error } = await supabase
          .from('bansos_recipients')
          .update({ status: 'aktif', tahun_mulai: year })
          .eq('id', record.id)
          .eq('tenant_id', tenantId);

        if (!error) {
          // Add to residents.active_aids
          const target = residents.find(r => r.nik === nik);
          if (target) {
            const currentAids = target.activeAids || [];
            if (!currentAids.includes(aidTag)) {
              const updatedAids = [...currentAids, aidTag];
              await supabase
                .from('residents')
                .update({ active_aids: updatedAids })
                .eq('nik', nik)
                .eq('tenant_id', tenantId);
              target.activeAids = updatedAids;
            }
          }
          approvedCount++;
        }
      }

      setBansosData(prev => prev.map(b => {
        if (selectedNiks.includes(b.resident_id) && b.program_id === selectedProgram && b.status === 'usulan' && b.tahun === year) {
          return { ...b, status: 'aktif' };
        }
        return b;
      }));

      setSelectedNiks([]);
      showToast(`Berhasil menyetujui ${approvedCount} usulan bantuan!`, "success");
    } catch (err: any) {
      showToast(err.message || "Gagal menyetujui usulan massal", "error");
    } finally {
      setIsSaving(false);
    }
  };

  // Remove aid program from a resident
  // === HAPUS DARI DAFTAR: Hapus dari bansos_recipients + bersihkan residents.active_aids ===
  const handleHapusDariDaftar = (nik: string, programName: string) => {
    const targetResident = residents.find(r => r.nik === nik);
    const orphanEntry = bansosData.find(b => b.resident_id === nik && b.program_id === programName);
    const displayName = targetResident?.name || orphanEntry?.nama || nik;

    showConfirm(
      "Hapus dari Daftar Bantuan",
      `Hapus ${displayName} dari daftar penerima "${programName}"?\n\nData penduduk TIDAK akan berubah. Ini hanya menghapus dari daftar bantuan saja.`,
      async () => {
        try {
          if (!tenantId) throw new Error("Tenant ID tidak ditemukan");

          setRemovingNiks(prev => new Set([...prev, nik]));

          await new Promise(resolve => setTimeout(resolve, 300));

          const yearNum = filterYear !== "Semua Tahun" ? Number(filterYear) : new Date().getFullYear();

          // 1. Hapus dari bansos_recipients
          const { error: delErr } = await supabase
            .from('bansos_recipients')
            .delete()
            .eq('resident_id', nik)
            .eq('program_id', programName)
            .eq('tenant_id', tenantId)
            .eq('tahun', yearNum);

          if (delErr) throw delErr;

          // 2. Bersihkan dari residents.active_aids (hanya jika resident ada di residents)
          if (targetResident) {
            const yearStr = yearNum.toString();
            const currentAids = targetResident.activeAids || [];
            const updatedAids = currentAids.filter((aid: string) => {
              const match = aid.match(/^(.+?)\s*\(\d{4}\)$/);
              const aidProgName = match ? match[1].trim() : aid.trim();
              const aidYear = match ? match[2] : null;
              if (aidProgName === programName) {
                if (aidYear === yearStr || !aidYear) return false;
              }
              return true;
            });

            if (updatedAids.length !== currentAids.length) {
              await supabase
                .from('residents')
                .update({ active_aids: updatedAids })
                .eq('nik', nik)
                .eq('tenant_id', tenantId);

              setResidents(prev => prev.map(r => r.nik === nik ? { ...r, activeAids: updatedAids } : r));
            }
          }

          // 4. Update local bansosData
          setBansosData(prev => prev.filter(b => !(b.resident_id === nik && b.program_id === programName && b.tahun === yearNum)));

          // 5. Hapus dari removingNiks
          setRemovingNiks(prev => { const next = new Set(prev); next.delete(nik); return next; });

          showToast(`${displayName} berhasil dihapus dari daftar "${programName}".`, "success");
        } catch (err: any) {
          // Rollback animasi jika gagal
          setRemovingNiks(prev => { const next = new Set(prev); next.delete(nik); return next; });
          showToast(`Gagal menghapus: ${err.message}`, "error");
        }
      }
    );
  };

  // === HENTIKAN BANTUAN: Ubah status di residents.active_aids (dengan alasan: meninggal/pindah/mampu) ===
  const handleRemoveAid = (nik: string, programToRemove: string) => {
    const targetResident = residents.find(r => r.nik === nik);
    if (!targetResident) return;

    showConfirm(
      "Hentikan Bantuan Sosial",
      `Apakah Anda yakin ingin menghentikan bantuan "${programToRemove}" dari warga ${targetResident.name}?`,
      async () => {
        const reason = window.prompt(`Masukkan alasan penghentian bantuan untuk ${targetResident.name} (wajib diisi):`, "Meninggal Dunia / Pindah / Mampu");
        if (!reason || reason.trim() === "") {
          showToast("Penghentian dibatalkan: Alasan wajib diisi.", "error");
          return;
        }

        const currentAids = targetResident.activeAids || [];
        const updatedAids = currentAids.map((aid: string) => {
          if (aid === programToRemove) {
            return `STOPPED: ${programToRemove} | Alasan: ${reason.trim()}`;
          }
          return aid;
        });

        try {
          if (!tenantId) throw new Error("Tenant ID tidak ditemukan");
          
          const { error } = await supabase
            .from('residents')
            .update({ active_aids: updatedAids })
            .eq('nik', nik)
            .eq('tenant_id', tenantId);

          if (!error) {
            // Update local state directly
            setResidents(prev => prev.map(r => r.nik === nik ? { ...r, activeAids: updatedAids } : r));
            showToast(`Berhasil menghentikan ${targetResident.name} dari program ${programToRemove}`, "success");
          } else {
            throw error;
          }
        } catch (err: any) {
          showToast(err.message || "Gagal menghentikan warga dari program bantuan", "error");
        }
      }
    );
  };

  // Add aid program to a resident
  const handleAddAid = async () => {
    if (!selectedResidentNik) return;
    const targetResident = residents.find(r => r.nik === selectedResidentNik);
    if (!targetResident) return;

    const aidToSave = `${selectedProgram} (${formYear})`;
    const currentAids = targetResident.activeAids || [];
    if (currentAids.includes(aidToSave)) {
      showToast(`Warga ini sudah menerima bantuan program ini untuk tahun ${formYear}.`, "error");
      return;
    }

    const updatedAids = [...currentAids, aidToSave];

    // Poin 1: Validasi Anti-Bantuan Ganda
    if (selectedProgram === "BLT Dana Desa") {
      const hasPKH = currentAids.some((a: string) => a.startsWith("Program Keluarga Harapan (PKH)"));
      const hasBPNT = currentAids.some((a: string) => a.startsWith("Bantuan Pangan Non-Tunai"));
      
      if (hasPKH || hasBPNT) {
        showToast("Penyaluran ditolak: Warga sudah terdaftar sebagai penerima PKH/BPNT yang tidak boleh menerima BLT Dana Desa (Tumpang Tindih Terlarang).", "error");
        return;
      }
    }

    setIsSaving(true);

    try {
      if (!tenantId) throw new Error("Tenant ID tidak ditemukan");
      
      const { error } = await supabase
        .from('residents')
        .update({ active_aids: updatedAids })
        .eq('nik', selectedResidentNik)
        .eq('tenant_id', tenantId);

      if (!error) {
        setResidents(prev => prev.map(r => r.nik === selectedResidentNik ? { ...r, activeAids: updatedAids } : r));
        setShowModal(false);
        setSelectedResidentNik("");
        setSearchResidentQuery("");
        showToast(`Berhasil menambahkan ${targetResident.name} ke program ${selectedProgram}`, "success");
      } else {
        throw error;
      }
    } catch (err: any) {
      showToast(err.message || "Gagal menambahkan warga ke program bantuan", "error");
    } finally {
      setIsSaving(false);
    }
  };

  // Save aid program to selected resident or create new resident from dedicated view
  const handleSaveAddForm = async () => {
    if (!formProgram) {
      showToast("Silakan pilih program bantuan terlebih dahulu", "error");
      return;
    }

    const aidTag = `${formProgram} (${formYear})`;

    // FLOW A: Manual New Resident Creation (Auto-saved to Master Penduduk DB)
    if (isManualResident) {
      if (!manualResidentData.name.trim() || !manualResidentData.nik.trim()) {
        showToast("Nama Warga dan NIK (16 Digit) wajib diisi", "error");
        return;
      }

      setIsSaving(true);
      try {
        if (!tenantId) throw new Error("Tenant ID tidak ditemukan");

        const newResidentRecord = {
          tenant_id: tenantId,
          name: manualResidentData.name.trim(),
          nik: manualResidentData.nik.trim(),
          address: manualResidentData.address.trim() || 'Jl. Utama Desa',
          rt: manualResidentData.rt.trim() || '001',
          rw: manualResidentData.rw.trim() || '001',
          desa: manualResidentData.desa.trim() || 'Sukamaju',
          active_aids: [aidTag],
          is_deleted: 0
        };

        const { data, error } = await supabase
          .from('residents')
          .insert([newResidentRecord])
          .select()
          .single();

        if (error) throw error;

        // Format for local state
        const formattedNewResident = {
          ...data,
          noKk: data?.no_kk || '-',
          rtRw: `${data?.rt || '001'}/${data?.rw || '001'}`,
          birthPlace: data?.birth_place || '-',
          birthDate: data?.birth_date || '-',
          activeAids: [aidTag]
        };

        setResidents(prev => [formattedNewResident, ...prev]);
        showToast(`Warga baru ${manualResidentData.name} berhasil disimpan ke data penduduk web & didaftarkan ke ${formProgram}!`, "success");

        // Reset
        setIsManualResident(false);
        setManualResidentData({ name: '', nik: '', address: '', rt: '001', rw: '001', desa: 'Sukamaju' });
        setSelectedResidentNik("");
        setSearchResidentQuery("");
        setFormProgram("");
        setFormAmount("300000");
        setFormFunding("");
        setCriteriaChecked({});
        setShowAddView(false);
      } catch (err: any) {
        showToast(err.message || "Gagal menyimpan penduduk baru ke database", "error");
      } finally {
        setIsSaving(false);
      }
      return;
    }

    // FLOW B: Existing Resident Selection
    if (!selectedResidentNik) {
      showToast("Silakan pilih penduduk terlebih dahulu", "error");
      return;
    }

    const targetResident = residents.find(r => r.nik === selectedResidentNik);
    if (!targetResident) return;

    const currentAids = targetResident.activeAids || [];
    const updatedAids = currentAids.includes(aidTag) ? currentAids : [...currentAids, aidTag];
    setIsSaving(true);

    try {
      if (!tenantId) throw new Error("Tenant ID tidak ditemukan");
      
      const { error } = await supabase
        .from('residents')
        .update({ active_aids: updatedAids })
        .eq('nik', selectedResidentNik)
        .eq('tenant_id', tenantId);

      if (!error) {
        setResidents(prev => prev.map(r => r.nik === selectedResidentNik ? { ...r, activeAids: updatedAids } : r));
        
        // Reset form
        setSelectedResidentNik("");
        setSearchResidentQuery("");
        setFormProgram("");
        setFormAmount("300000");
        setFormFunding("");
        setCriteriaChecked({});
        setShowAddView(false);
        
        showToast(`Berhasil menambahkan ${targetResident.name} ke program ${formProgram}`, "success");
      } else {
        throw error;
      }
    } catch (err: any) {
      showToast(err.message || "Gagal menyimpan data", "error");
    } finally {
      setIsSaving(false);
    }
  };

  // Filter residents available to be added (who aren't already in the selected program)
  const availableResidentsForModal = useMemo(() => {
    let list = residents.filter(r => !r.activeAids?.includes(selectedProgram));
    
    if (searchResidentQuery.trim() !== "") {
      const q = searchResidentQuery.toLowerCase();
      list = list.filter(r => 
        r.name?.toLowerCase().includes(q) || 
        r.nik?.includes(q)
      );
    }
    return list.slice(0, 5); // Limit search results to 5
  }, [residents, selectedProgram, searchResidentQuery]);

  const selectedResidentDetail = useMemo(() => {
    return residents.find(r => r.nik === selectedResidentNik) || null;
  }, [residents, selectedResidentNik]);

  if (showAddView) {
    return (
      <div className="pb-24 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
        {/* Header Section */}
        <div className="sticky top-16 z-40 bg-slate-50/60 dark:bg-slate-900/80 backdrop-blur-xl pb-4 -mx-4 -mt-4 px-4 pt-4 md:-mx-6 md:-mt-6 md:px-6 md:pt-6 lg:-mx-8 lg:-mt-8 lg:px-8 lg:pt-8 border-b border-slate-200/50 dark:border-slate-700/50 flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-4">
            <button 
              type="button"
              onClick={() => {
                setShowAddView(false);
                setSelectedResidentNik("");
                setSearchResidentQuery("");
                setFormProgram("");
                setCriteriaChecked({});
              }}
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-white dark:bg-slate-900 shadow-sm dark:shadow-none border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-slate-300 hover:text-emerald-700 hover:border-emerald-200 transition-all active:scale-95"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Tambah Penerima Bantuan</h2>
              <p className="text-sm text-gray-500 dark:text-slate-400 mt-0.5">Input data warga baru untuk program bantuan sosial desa.</p>
            </div>
          </div>
          <div className="flex gap-3 w-full sm:w-auto">
            <button
              onClick={() => setShowImport(true)}
              className="flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-blue-700 active:scale-95 transition-all shadow-sm dark:shadow-none"
            >
              <Database className="w-5 h-5" />
              Import Massal
            </button>
            <button 
              onClick={() => {
                setShowAddView(false);
                setSelectedResidentNik("");
                setSearchResidentQuery("");
                setFormProgram("");
                setCriteriaChecked({});
              }}
              className="flex-1 sm:flex-none px-6 py-2.5 border border-gray-300 dark:border-slate-600 text-gray-700 dark:text-slate-300 font-bold text-sm rounded-xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-all active:scale-95 bg-white dark:bg-slate-900"
            >
              Batal
            </button>
            <button 
              onClick={handleSaveAddForm}
              disabled={isSaving || (!selectedResidentNik && !isManualResident) || !formProgram}
              className="flex-1 sm:flex-none px-6 py-2.5 bg-emerald-700 text-white font-bold text-sm rounded-xl shadow-sm dark:shadow-none hover:bg-emerald-800 transition-all active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {isSaving ? 'Menyimpan...' : 'Simpan Data'}
            </button>
          </div>
        </div>

        {/* Main Form Bento Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Form Fields */}
          <div className="lg:col-span-8 space-y-6">
            {/* Section 1: Pilih Penduduk */}
            <section className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                  <Search className="w-4 h-4" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">1. Pilih Penduduk</h3>
              </div>

              <div className="space-y-4">
                <div ref={searchContainerRef} className="space-y-1.5 relative">
                  <div className="flex items-center justify-between ml-1 mb-1">
                    <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                      Cari Berdasarkan NIK atau Nama
                    </label>
                    <button 
                      onClick={() => setShowRecommendations(!showRecommendations)}
                      className={`text-[10px] font-bold px-2.5 py-1 rounded-full transition-colors flex items-center gap-1 ${
                        showRecommendations 
                          ? 'bg-amber-100 text-amber-800 border border-amber-200' 
                          : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-100'
                      }`}
                    >
                      ✨ {showRecommendations ? 'Tutup Rekomendasi' : 'Rekomendasi AI'} <span className="bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 text-[8px] font-black px-1 py-px rounded">[DEV]</span>
                    </button>
                  </div>
                  <div className="relative group">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-emerald-700 transition-colors w-5 h-5" />
                    <input 
                      type="text" 
                      placeholder="Masukkan NIK 16 digit atau nama warga..."
                      value={searchResidentQuery}
                      onChange={(e) => {
                        setSearchResidentQuery(e.target.value);
                        if (selectedResidentNik) {
                          setSelectedResidentNik(""); // Clear selection if user types again
                        }
                      }}
                      className="w-full h-12 pl-11 pr-4 border border-gray-200 dark:border-slate-700 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10 outline-none text-sm font-semibold text-gray-800 dark:text-slate-100 bg-white dark:bg-slate-900 transition-all"
                    />
                  </div>
                  <p className="text-[11px] text-gray-400 italic ml-1">Ketik nama/NIK, atau klik tombol Rekomendasi AI di atas.</p>

                  {/* Suggestion Dropdown */}
                  {(searchResidentQuery.trim() !== "" || showRecommendations) && !selectedResidentNik && !isManualResident && (
                    <div className="absolute left-0 right-0 z-50 mt-1 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl shadow-xl overflow-hidden divide-y divide-gray-100 max-h-[300px] overflow-y-auto">
                      {searchResidentQuery.trim() === "" && searchResultsForAddView.length > 0 && (
                        <div className="bg-emerald-50 text-emerald-800 text-[10px] font-bold px-3 py-1.5 uppercase tracking-wider flex items-center gap-1.5">
                          ✨ Rekomendasi Cerdas AI
                        </div>
                      )}
                      {searchResultsForAddView.length === 0 ? (
                        <div className="p-4 text-center space-y-3">
                          <p className="text-xs text-gray-500 dark:text-slate-400 font-medium">Data warga tidak ditemukan dalam database penduduk.</p>
                          <button
                            type="button"
                            onClick={() => {
                              setIsManualResident(true);
                              setManualResidentData(prev => ({ ...prev, name: searchResidentQuery }));
                              setShowRecommendations(false);
                            }}
                            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 mx-auto active:scale-95"
                          >
                            <UserPlus className="w-4 h-4" />
                            + Tambah Warga Baru Secara Manual
                          </button>
                        </div>
                      ) : (
                        <>
                          {searchResultsForAddView.map(r => (
                            <button 
                              key={r.nik}
                              type="button"
                              onClick={() => {
                                setSelectedResidentNik(r.nik);
                                setSearchResidentQuery(r.name);
                                setShowRecommendations(false);
                              }}
                              className="w-full p-3.5 text-left hover:bg-emerald-50/40 cursor-pointer transition-colors flex justify-between items-center"
                            >
                              <div className="text-left">
                                <div className="flex items-center gap-2">
                                  <p className="text-sm font-extrabold text-gray-800 dark:text-slate-100">{r.name}</p>
                                  {r.vulnerabilityScore !== undefined && searchResidentQuery.trim() === "" && (
                                    <span className="text-[9px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">
                                      Skor: {r.vulnerabilityScore}
                                    </span>
                                  )}
                                </div>
                                <p className="text-[11px] font-bold text-gray-500 dark:text-slate-400 font-mono">NIK: {r.nik}</p>
                                {r.status?.toLowerCase().includes('meninggal') && (
                                  <span className="inline-flex items-center gap-1 mt-1 px-1.5 py-0.5 bg-red-100 text-red-700 text-[9px] font-bold rounded">
                                    <AlertCircle className="w-3 h-3" />
                                    {r.status}
                                  </span>
                                )}
                              </div>
                              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-100">Pilih</span>
                            </button>
                          ))}

                          <div className="p-3 bg-gray-50 dark:bg-slate-800/60 text-center">
                            <button
                              type="button"
                              onClick={() => {
                                setIsManualResident(true);
                                setManualResidentData(prev => ({ ...prev, name: searchResidentQuery }));
                                setShowRecommendations(false);
                              }}
                              className="text-xs font-extrabold text-emerald-700 dark:text-emerald-400 hover:underline inline-flex items-center gap-1"
                            >
                              + Warga tidak ada? Tambah Manual Baru ke Master Penduduk Web
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </div>

                {/* Manual Resident Form (Triggered when user toggles manual mode) */}
                {isManualResident ? (
                  <div className="p-5 rounded-2xl bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/60 space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
                    <div className="flex items-center justify-between border-b border-emerald-200/60 dark:border-emerald-800/60 pb-3">
                      <div className="flex items-center gap-2 text-emerald-900 dark:text-emerald-200 font-extrabold text-sm">
                        <UserPlus className="w-4 h-4 text-emerald-600" />
                        Form Tambah Warga Baru (Otomatis Masuk Master Penduduk)
                      </div>
                      <button
                        type="button"
                        onClick={() => setIsManualResident(false)}
                        className="text-xs text-rose-600 font-bold hover:underline"
                      >
                        Batal Manual
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-700 dark:text-slate-300 mb-1">Nama Lengkap Warga *</label>
                        <input
                          type="text"
                          value={manualResidentData.name}
                          onChange={(e) => setManualResidentData({ ...manualResidentData, name: toTitleCase(e.target.value) })}
                          placeholder="Masukkan nama sesuai KTP..."
                          className="w-full h-11 px-4 border border-emerald-200 dark:border-slate-700 rounded-xl outline-none text-sm font-semibold bg-white dark:bg-slate-900 focus:ring-2 focus:ring-emerald-500 capitalize"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-gray-700 dark:text-slate-300 mb-1">NIK (16 Digit) *</label>
                        <input
                          type="text"
                          maxLength={16}
                          value={manualResidentData.nik}
                          onChange={(e) => setManualResidentData({ ...manualResidentData, nik: e.target.value.replace(/\D/g, '') })}
                          placeholder="6306..."
                          className="w-full h-11 px-4 border border-emerald-200 dark:border-slate-700 rounded-xl outline-none text-sm font-mono font-semibold bg-white dark:bg-slate-900 focus:ring-2 focus:ring-emerald-500"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-gray-700 dark:text-slate-300 mb-1">Dusun / Alamat Jalan</label>
                        <input
                          type="text"
                          value={manualResidentData.address}
                          onChange={(e) => setManualResidentData({ ...manualResidentData, address: toTitleCase(e.target.value) })}
                          placeholder="Jl. Keramat RT 02..."
                          className="w-full h-11 px-4 border border-emerald-200 dark:border-slate-700 rounded-xl outline-none text-sm font-semibold bg-white dark:bg-slate-900 focus:ring-2 focus:ring-emerald-500 capitalize"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-xs font-bold text-gray-700 dark:text-slate-300 mb-1">RT</label>
                          <input
                            type="text"
                            value={manualResidentData.rt}
                            onChange={(e) => setManualResidentData({ ...manualResidentData, rt: e.target.value })}
                            placeholder="001"
                            className="w-full h-11 px-3 border border-emerald-200 dark:border-slate-700 rounded-xl outline-none text-sm font-semibold bg-white dark:bg-slate-900 focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-gray-700 dark:text-slate-300 mb-1">RW</label>
                          <input
                            type="text"
                            value={manualResidentData.rw}
                            onChange={(e) => setManualResidentData({ ...manualResidentData, rw: e.target.value })}
                            placeholder="001"
                            className="w-full h-11 px-3 border border-emerald-200 dark:border-slate-700 rounded-xl outline-none text-sm font-semibold bg-white dark:bg-slate-900 focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                      </div>
                    </div>

                    <p className="text-[11px] text-emerald-700 dark:text-emerald-300 font-medium italic">
                      * Data warga ini akan otomatis tersimpan permanen ke master database penduduk desa & langsung dapat diakses di menu Penduduk.
                    </p>
                  </div>
                ) : (
                  /* Resident Info Preview Card for existing residents */
                  <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-gray-200/60 flex gap-4 items-start shadow-inner">
                    <div className="w-14 h-14 rounded-xl bg-gray-200 flex items-center justify-center text-gray-400 shrink-0">
                      <Users className="w-8 h-8" />
                    </div>
                    <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <p className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider">Nama Lengkap</p>
                        <p className="font-bold text-gray-800 dark:text-slate-100 text-sm">{selectedResidentDetail ? selectedResidentDetail.name : "-"}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider">NIK</p>
                        <p className="font-bold text-gray-800 dark:text-slate-100 text-sm font-mono">{selectedResidentDetail ? selectedResidentDetail.nik : "-"}</p>
                      </div>
                      <div className="sm:col-span-2">
                        <p className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider">Alamat</p>
                        <p className="text-xs text-gray-600 dark:text-slate-400 font-semibold leading-relaxed">
                          {selectedResidentDetail 
                            ? `RT ${selectedResidentDetail.rt || "-"} / RW ${selectedResidentDetail.rw || "-"}, Desa ${selectedResidentDetail.desa || "Sukamaju"}, ${selectedResidentDetail.address || ""}`
                            : "Pilih warga terlebih dahulu..."}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Overlap Info inside Card */}
                {selectedResidentDetail && selectedResidentDetail.activeAids && selectedResidentDetail.activeAids.length > 0 && (
                  <div className="p-4 bg-blue-50/60 border border-blue-100 rounded-xl flex items-start gap-3 animate-in fade-in slide-in-from-top-2">
                    <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-blue-800 text-sm">Penerima Beberapa Program Bantuan</p>
                      <p className="text-xs text-blue-600 mt-1 leading-relaxed">
                        Warga ini tercatat memiliki beberapa bantuan aktif: <strong className="font-extrabold">{selectedResidentDetail.activeAids.join(", ")}</strong>. Program baru akan ditambahkan dan diarsipkan secara aman ke dalam data penerima bantuan warga tsb.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* Section 2: Detail Bantuan */}
            <section className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                  <Banknote className="w-4 h-4" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">2. Detail Program Bantuan</h3>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider ml-1">Program Bantuan</label>
                  <select 
                    value={[
                      "BLT Dana Desa",
                      "Program Keluarga Harapan (PKH)",
                      "Bantuan Pangan Non-Tunai (BPNT)",
                      "Bansos Tunai Kemensos",
                      "Bantuan Cadangan Beras Pemerintah (CBP)",
                      "BLT El Nino / Cuaca Ekstrem",
                      "Bantuan Rumah Tidak Layak Huni (RTLH)",
                      "Asistensi Sosial Disabilitas (ASPD)",
                      "Asistensi Sosial Lansia Terlantar (ASLUT)",
                      "Bantuan Pelaku Usaha Mikro (BPUM / BLT UMKM)",
                      "Bantuan Subsidi Upah (BSU)",
                      "Beasiswa Pendidikan Desa (KIP Desa)",
                      "Jaminan Kesehatan PBI-JK (BPJS Gratis)",
                      "Bantuan Semen / Material Bangunan Desa",
                      "Bantuan Alat / Pupuk Pertanian Desa",
                      "Bantuan Bibit & Pakan Peternakan/Perikanan"
                    ].includes(formProgram) ? formProgram : (formProgram ? "Lainnya (Ketik Manual...)" : "")}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === "Lainnya (Ketik Manual...)") {
                        setFormProgram("");
                      } else {
                        setFormProgram(val);
                        // Set dynamic defaults for amount and funding
                        if (val === "BLT Dana Desa") {
                          setFormAmount("300000");
                          setFormFunding("Dana Desa");
                        } else if (val.includes("BPNT") || val.includes("Bantuan Pangan")) {
                          setFormAmount("200000");
                          setFormFunding("APBN");
                        } else if (val.includes("PKH") || val.includes("Keluarga Harapan")) {
                          setFormAmount("600000");
                          setFormFunding("APBN");
                        } else if (val.includes("RTLH") || val.includes("Rumah")) {
                          setFormAmount("20000000");
                          setFormFunding("Dana Desa");
                        } else if (val.includes("Kemensos") || val.includes("BSU") || val.includes("BPUM")) {
                          setFormAmount("300000");
                          setFormFunding("APBN");
                        }
                      }
                    }}
                    className="w-full h-12 px-4 border border-gray-200 dark:border-slate-700 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10 outline-none text-sm font-semibold text-gray-800 dark:text-slate-100 bg-white dark:bg-slate-900"
                  >
                    <option value="" disabled>-- Pilih Program Bantuan --</option>
                    <option value="BLT Dana Desa">BLT Dana Desa</option>
                    <option value="Program Keluarga Harapan (PKH)">PKH (Program Keluarga Harapan)</option>
                    <option value="Bantuan Pangan Non-Tunai (BPNT)">BPNT (Bantuan Pangan Non-Tunai / Kartu Sembako)</option>
                    <option value="Bansos Tunai Kemensos">Bansos Tunai Kemensos (BST)</option>
                    <option value="Bantuan Cadangan Beras Pemerintah (CBP)">Bantuan Cadangan Beras Pemerintah (CBP)</option>
                    <option value="BLT El Nino / Cuaca Ekstrem">BLT El Nino / Cuaca Ekstrem</option>
                    <option value="Bantuan Rumah Tidak Layak Huni (RTLH)">Bantuan Rumah Tidak Layak Huni (RTLH / Bedah Rumah)</option>
                    <option value="Asistensi Sosial Disabilitas (ASPD)">Asistensi Sosial Disabilitas (ASPD)</option>
                    <option value="Asistensi Sosial Lansia Terlantar (ASLUT)">Asistensi Sosial Lansia Terlantar (ASLUT)</option>
                    <option value="Bantuan Pelaku Usaha Mikro (BPUM / BLT UMKM)">Bantuan Pelaku Usaha Mikro (BPUM / BLT UMKM)</option>
                    <option value="Bantuan Subsidi Upah (BSU)">Bantuan Subsidi Upah (BSU)</option>
                    <option value="Beasiswa Pendidikan Desa (KIP Desa)">Beasiswa Pendidikan Desa (KIP Desa)</option>
                    <option value="Jaminan Kesehatan PBI-JK (BPJS Gratis)">Jaminan Kesehatan PBI-JK (BPJS Gratis)</option>
                    <option value="Bantuan Semen / Material Bangunan Desa">Bantuan Semen / Material Bangunan Desa</option>
                    <option value="Bantuan Alat / Pupuk Pertanian Desa">Bantuan Alat / Pupuk Pertanian Desa</option>
                    <option value="Bantuan Bibit & Pakan Peternakan/Perikanan">Bantuan Bibit & Pakan Peternakan / Perikanan</option>
                    <option value="Lainnya (Ketik Manual...)">✨ Lainnya (Ketik Manual...)</option>
                  </select>

                  {(![
                    "BLT Dana Desa",
                    "Program Keluarga Harapan (PKH)",
                    "Bantuan Pangan Non-Tunai (BPNT)",
                    "Bansos Tunai Kemensos",
                    "Bantuan Cadangan Beras Pemerintah (CBP)",
                    "BLT El Nino / Cuaca Ekstrem",
                    "Bantuan Rumah Tidak Layak Huni (RTLH)",
                    "Asistensi Sosial Disabilitas (ASPD)",
                    "Asistensi Sosial Lansia Terlantar (ASLUT)",
                    "Bantuan Pelaku Usaha Mikro (BPUM / BLT UMKM)",
                    "Bantuan Subsidi Upah (BSU)",
                    "Beasiswa Pendidikan Desa (KIP Desa)",
                    "Jaminan Kesehatan PBI-JK (BPJS Gratis)",
                    "Bantuan Semen / Material Bangunan Desa",
                    "Bantuan Alat / Pupuk Pertanian Desa",
                    "Bantuan Bibit & Pakan Peternakan/Perikanan"
                  ].includes(formProgram) || formProgram === '') && (
                    <div className="mt-2 animate-in fade-in slide-in-from-top-1">
                      <input
                        type="text"
                        placeholder="Ketik nama program bantuan sosial kustom di sini..."
                        value={formProgram}
                        onChange={(e) => setFormProgram(toTitleCase(e.target.value))}
                        className="w-full h-11 px-4 border border-emerald-300 dark:border-emerald-700 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 outline-none text-sm font-bold text-emerald-950 dark:text-emerald-100 bg-emerald-50/40 dark:bg-emerald-950/40 shadow-inner capitalize"
                        required
                      />
                      <p className="mt-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">Tuliskan nama resmi program bantuan sosial yang sesuai.</p>
                    </div>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider ml-1">Tahun Anggaran</label>
                  <select 
                    value={
                      Array.from({ length: 16 }, (_, i) => (2020 + i).toString()).includes(formYear)
                        ? formYear
                        : "Lainnya"
                    }
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === "Lainnya") {
                        setFormYear("");
                      } else {
                        setFormYear(val);
                      }
                    }}
                    className="w-full h-12 px-4 border border-gray-200 dark:border-slate-700 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10 outline-none text-sm font-semibold text-gray-800 dark:text-slate-100 bg-white dark:bg-slate-900"
                  >
                    {Array.from({ length: 16 }, (_, i) => {
                      const y = (2020 + i).toString();
                      return <option key={y} value={y}>{y}</option>;
                    })}
                    <option value="Lainnya">✨ Ketik Tahun Manual...</option>
                  </select>

                  {(!Array.from({ length: 16 }, (_, i) => (2020 + i).toString()).includes(formYear)) && (
                    <input
                      type="text"
                      maxLength={4}
                      placeholder="Ketik tahun (contoh: 2030)..."
                      value={formYear}
                      onChange={(e) => setFormYear(e.target.value.replace(/\D/g, ''))}
                      className="w-full h-11 px-4 mt-1 border border-emerald-300 rounded-xl text-sm font-mono font-bold outline-none focus:ring-2 focus:ring-emerald-500/20 bg-emerald-50/40 text-emerald-950 dark:text-emerald-100"
                    />
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider ml-1">Status Pengajuan</label>
                  <div className="w-full h-12 px-4 flex items-center bg-amber-50/50 border border-amber-100 rounded-xl text-amber-800">
                    <span className="w-2 h-2 rounded-full bg-amber-500 mr-2"></span>
                    <span className="text-sm font-bold">Proses Verifikasi</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider ml-1">Besaran Bantuan (Hanya Angka)</label>
                  <div className="relative group">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 dark:text-slate-400 font-bold text-sm">Rp</span>
                    <input 
                      type="text"
                      inputMode="numeric"
                      value={(() => {
                        const digits = formAmount.replace(/\D/g, '');
                        return digits ? parseInt(digits, 10).toLocaleString('id-ID') : '';
                      })()}
                      onChange={(e) => {
                        const raw = e.target.value.replace(/\D/g, '');
                        setFormAmount(raw);
                      }}
                      placeholder="300.000"
                      className="w-full h-12 pl-10 pr-4 border border-gray-200 dark:border-slate-700 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10 outline-none text-sm font-mono font-bold text-gray-800 dark:text-slate-100 bg-white dark:bg-slate-900"
                    />
                  </div>
                  <p className="text-[10px] text-gray-400 font-medium ml-1">Terformat otomatis Rupiah. Kunci hanya bisa diisi angka.</p>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider ml-1">Sumber Dana</label>
                  <select 
                    value={formFunding}
                    onChange={(e) => setFormFunding(e.target.value)}
                    className="w-full h-12 px-4 border border-gray-200 dark:border-slate-700 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/10 outline-none text-sm font-semibold text-gray-800 dark:text-slate-100 bg-white dark:bg-slate-900"
                  >
                    <option value="">Pilih Sumber Dana</option>
                    <option value="Dana Desa">Dana Desa</option>
                    <option value="APBD Kabupaten">APBD Kabupaten</option>
                    <option value="APBN">APBN</option>
                    <option value="Bantuan Provinsi">Bantuan Provinsi</option>
                  </select>
                </div>
              </div>
            </section>
          </div>

          {/* Right Column: Criteria & Actions */}
          <div className="lg:col-span-4">
            <section className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 flex flex-col justify-between space-y-6">
              <div>
                <div className="flex items-center justify-between gap-3 mb-6">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">3. Kriteria</h3>
                  </div>
                  <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full uppercase tracking-wider">
                    Dinamis
                  </span>
                </div>

                {/* Empty State */}
                {!formProgram ? (
                  <div className="flex mb-6 flex-col items-center justify-center py-12 text-center border border-dashed border-gray-200 dark:border-slate-700 rounded-2xl bg-gray-50/40 px-4">
                    <AlertCircle className="w-12 h-12 text-gray-300 mb-3 animate-pulse" />
                    <p className="text-xs text-gray-500 dark:text-slate-400 italic max-w-[200px] leading-relaxed">
                      Pilih program bantuan terlebih dahulu untuk melihat kriteria yang relevan.
                    </p>
                  </div>
                ) : (
                  /* Dynamic Criteria Checklists */
                  <div className="space-y-3">
                    {formProgram === "BLT Dana Desa" && (
                      <>
                        <label className="flex items-start gap-3.5 p-3.5 rounded-xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-all cursor-pointer group border border-transparent hover:border-gray-100">
                          <input 
                            type="checkbox"
                            checked={!!criteriaChecked["low_income"]}
                            onChange={(e) => setCriteriaChecked({ ...criteriaChecked, "low_income": e.target.checked })}
                            className="w-5 h-5 rounded border-gray-300 dark:border-slate-600 text-emerald-700 focus:ring-emerald-500 focus:ring-offset-0 mt-0.5" 
                          />
                          <div>
                            <p className="font-bold text-sm text-gray-800 dark:text-slate-100">Penghasilan Rendah</p>
                            <p className="text-xs text-gray-500 dark:text-slate-400 leading-normal mt-0.5 font-medium">Keluarga dengan pendapatan di bawah UMR desa.</p>
                          </div>
                        </label>
                        <label className="flex items-start gap-3.5 p-3.5 rounded-xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-all cursor-pointer group border border-transparent hover:border-gray-100">
                          <input 
                            type="checkbox"
                            checked={!!criteriaChecked["job_loss"]}
                            onChange={(e) => setCriteriaChecked({ ...criteriaChecked, "job_loss": e.target.checked })}
                            className="w-5 h-5 rounded border-gray-300 dark:border-slate-600 text-emerald-700 focus:ring-emerald-500 focus:ring-offset-0 mt-0.5" 
                          />
                          <div>
                            <p className="font-bold text-sm text-gray-800 dark:text-slate-100">Kehilangan Pekerjaan</p>
                            <p className="text-xs text-gray-500 dark:text-slate-400 leading-normal mt-0.5 font-medium">PHK atau usaha terhenti akibat kondisi darurat.</p>
                          </div>
                        </label>
                      </>
                    )}

                    {formProgram === "Program Keluarga Harapan (PKH)" && (
                      <>
                        <label className="flex items-start gap-3.5 p-3.5 rounded-xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-all cursor-pointer group border border-transparent hover:border-gray-100">
                          <input 
                            type="checkbox"
                            checked={!!criteriaChecked["elderly"]}
                            onChange={(e) => setCriteriaChecked({ ...criteriaChecked, "elderly": e.target.checked })}
                            className="w-5 h-5 rounded border-gray-300 dark:border-slate-600 text-emerald-700 focus:ring-emerald-500 focus:ring-offset-0 mt-0.5" 
                          />
                          <div>
                            <p className="font-bold text-sm text-gray-800 dark:text-slate-100">Lanjut Usia (Lansia)</p>
                            <p className="text-xs text-gray-500 dark:text-slate-400 leading-normal mt-0.5 font-medium">Berusia di atas 60 tahun & tidak produktif.</p>
                          </div>
                        </label>
                        <label className="flex items-start gap-3.5 p-3.5 rounded-xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-all cursor-pointer group border border-transparent hover:border-gray-100">
                          <input 
                            type="checkbox"
                            checked={!!criteriaChecked["disability"]}
                            onChange={(e) => setCriteriaChecked({ ...criteriaChecked, "disability": e.target.checked })}
                            className="w-5 h-5 rounded border-gray-300 dark:border-slate-600 text-emerald-700 focus:ring-emerald-500 focus:ring-offset-0 mt-0.5" 
                          />
                          <div>
                            <p className="font-bold text-sm text-gray-800 dark:text-slate-100">Disabilitas</p>
                            <p className="text-xs text-gray-500 dark:text-slate-400 leading-normal mt-0.5 font-medium">Memiliki keterbatasan fisik atau mental.</p>
                          </div>
                        </label>
                      </>
                    )}

                    {formProgram === "Bantuan Pangan Non-Tunai" && (
                      <>
                        <label className="flex items-start gap-3.5 p-3.5 rounded-xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-all cursor-pointer group border border-transparent hover:border-gray-100">
                          <input 
                            type="checkbox"
                            checked={!!criteriaChecked["disability"]}
                            onChange={(e) => setCriteriaChecked({ ...criteriaChecked, "disability": e.target.checked })}
                            className="w-5 h-5 rounded border-gray-300 dark:border-slate-600 text-emerald-700 focus:ring-emerald-500 focus:ring-offset-0 mt-0.5" 
                          />
                          <div>
                            <p className="font-bold text-sm text-gray-800 dark:text-slate-100">Disabilitas</p>
                            <p className="text-xs text-gray-500 dark:text-slate-400 leading-normal mt-0.5 font-medium">Memiliki keterbatasan fisik atau mental.</p>
                          </div>
                        </label>
                        <label className="flex items-start gap-3.5 p-3.5 rounded-xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-all cursor-pointer group border border-transparent hover:border-gray-100">
                          <input 
                            type="checkbox"
                            checked={!!criteriaChecked["low_income"]}
                            onChange={(e) => setCriteriaChecked({ ...criteriaChecked, "low_income": e.target.checked })}
                            className="w-5 h-5 rounded border-gray-300 dark:border-slate-600 text-emerald-700 focus:ring-emerald-500 focus:ring-offset-0 mt-0.5" 
                          />
                          <div>
                            <p className="font-bold text-sm text-gray-800 dark:text-slate-100">Penghasilan Rendah</p>
                            <p className="text-xs text-gray-500 dark:text-slate-400 leading-normal mt-0.5 font-medium">Keluarga dengan pendapatan di bawah UMR desa.</p>
                          </div>
                        </label>
                      </>
                    )}

                    {formProgram === "Bansos Tunai Kemensos" && (
                      <>
                        <label className="flex items-start gap-3.5 p-3.5 rounded-xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-all cursor-pointer group border border-transparent hover:border-gray-100">
                          <input 
                            type="checkbox"
                            checked={!!criteriaChecked["low_income"]}
                            onChange={(e) => setCriteriaChecked({ ...criteriaChecked, "low_income": e.target.checked })}
                            className="w-5 h-5 rounded border-gray-300 dark:border-slate-600 text-emerald-700 focus:ring-emerald-500 focus:ring-offset-0 mt-0.5" 
                          />
                          <div>
                            <p className="font-bold text-sm text-gray-800 dark:text-slate-100">Penghasilan Rendah</p>
                            <p className="text-xs text-gray-500 dark:text-slate-400 leading-normal mt-0.5 font-medium">Keluarga dengan pendapatan di bawah UMR desa.</p>
                          </div>
                        </label>
                        <label className="flex items-start gap-3.5 p-3.5 rounded-xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-all cursor-pointer group border border-transparent hover:border-gray-100">
                          <input 
                            type="checkbox"
                            checked={!!criteriaChecked["job_loss"]}
                            onChange={(e) => setCriteriaChecked({ ...criteriaChecked, "job_loss": e.target.checked })}
                            className="w-5 h-5 rounded border-gray-300 dark:border-slate-600 text-emerald-700 focus:ring-emerald-500 focus:ring-offset-0 mt-0.5" 
                          />
                          <div>
                            <p className="font-bold text-sm text-gray-800 dark:text-slate-100">Kehilangan Pekerjaan</p>
                            <p className="text-xs text-gray-500 dark:text-slate-400 leading-normal mt-0.5 font-medium">PHK atau usaha terhenti akibat kondisi darurat.</p>
                          </div>
                        </label>
                      </>
                    )}

                    {/* Custom Added Criteria List */}
                    {customCriteriaList.length > 0 && (
                      <div className="space-y-2 pt-2 border-t border-gray-100 dark:border-slate-800">
                        <p className="text-[10px] font-extrabold text-emerald-800 dark:text-emerald-400 uppercase tracking-wider">Kriteria Kustom Tambahan:</p>
                        {customCriteriaList.map((crit, idx) => (
                          <div key={idx} className="flex items-center justify-between gap-2 p-3 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-800/40">
                            <label className="flex items-start gap-3 cursor-pointer flex-1">
                              <input
                                type="checkbox"
                                checked={!!criteriaChecked[`custom_${crit}`]}
                                onChange={(e) => setCriteriaChecked({ ...criteriaChecked, [`custom_${crit}`]: e.target.checked })}
                                className="w-5 h-5 rounded border-gray-300 dark:border-slate-600 text-emerald-700 focus:ring-emerald-500 mt-0.5"
                              />
                              <span className="font-bold text-xs text-gray-800 dark:text-slate-100">{crit}</span>
                            </label>
                            <button
                              type="button"
                              onClick={() => setCustomCriteriaList(prev => prev.filter(c => c !== crit))}
                              className="text-red-500 hover:text-red-700 p-1 text-xs"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Add Custom Criteria Input Trigger */}
                    <div className="pt-3">
                      {showAddCriteriaForm ? (
                        <div className="space-y-2 p-3 bg-gray-50 dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 animate-in fade-in duration-200">
                          <input
                            type="text"
                            placeholder="Tulis kriteria kustom baru (misal: Rumah Dinding Kayu)..."
                            value={newCriteriaText}
                            onChange={(e) => setNewCriteriaText(toTitleCase(e.target.value))}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                if (newCriteriaText.trim()) {
                                  const text = toTitleCase(newCriteriaText.trim());
                                  setCustomCriteriaList(prev => [...prev, text]);
                                  setCriteriaChecked(prev => ({ ...prev, [`custom_${text}`]: true }));
                                  setNewCriteriaText('');
                                  setShowAddCriteriaForm(false);
                                }
                              }
                            }}
                            className="w-full px-3 py-2 text-xs border border-gray-300 dark:border-slate-600 rounded-lg outline-none font-semibold bg-white dark:bg-slate-900 capitalize"
                          />
                          <div className="flex justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => setShowAddCriteriaForm(false)}
                              className="px-2.5 py-1 text-[11px] font-bold text-gray-500 hover:text-gray-700"
                            >
                              Batal
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (newCriteriaText.trim()) {
                                  const text = newCriteriaText.trim();
                                  setCustomCriteriaList(prev => [...prev, text]);
                                  setCriteriaChecked(prev => ({ ...prev, [`custom_${text}`]: true }));
                                  setNewCriteriaText('');
                                  setShowAddCriteriaForm(false);
                                }
                              }}
                              className="px-3 py-1 bg-emerald-600 text-white text-[11px] font-bold rounded-lg hover:bg-emerald-700"
                            >
                              + Tambah Kriteria
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setShowAddCriteriaForm(true)}
                          className="w-full py-2.5 border border-dashed border-emerald-300 dark:border-emerald-700/80 rounded-xl text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 transition-all flex items-center justify-center gap-1.5"
                        >
                          + Tambah Kriteria Manual Baru
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>

            </section>
          </div>
        </div>

        {/* Info Alert Banner */}
        <div className="p-4 rounded-xl bg-emerald-50/40 border border-emerald-100/60 flex gap-3.5 items-center">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <p className="text-xs text-emerald-800 font-medium">
            Data yang disimpan akan melalui tahap verifikasi lanjutan oleh Tim Pengelola Bantuan Desa sebelum ditetapkan sebagai penerima sah.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-24 space-y-6">

      {/* Success Notification */}
      {message && (
        <div className={`p-4 rounded-xl border flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-300 ${
          message.type === 'success' 
            ? 'bg-emerald-50 border-emerald-100 text-emerald-800' 
            : 'bg-red-50 border-red-100 text-red-800'
        }`}>
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          <p className="text-sm font-semibold">{message.text}</p>
        </div>
      )}

      {/* Welcome Header */}
      <div className="sticky top-16 z-40 bg-slate-50/60 dark:bg-slate-900/80 backdrop-blur-xl pb-4 -mx-4 -mt-4 px-4 pt-4 md:-mx-6 md:-mt-6 md:px-6 md:pt-6 lg:-mx-8 lg:-mt-8 lg:px-8 lg:pt-8 border-b border-slate-200/50 dark:border-slate-700/50 flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
        <div>
          <h3 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">Program Bantuan Aktif</h3>
          <p className="text-gray-500 dark:text-slate-400 mt-1">Kelola dan validasi penerima bantuan sosial Desa Sukamaju secara langsung.</p>
        </div>
        <button 
          onClick={() => {
            setShowTambahPenerima(true);
          }}
          className="flex items-center justify-center gap-2 bg-emerald-700 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-800 active:scale-95 transition-all shadow-sm dark:shadow-none"
        >
          <UserPlus className="w-5 h-5" />
          Tambah Penerima
        </button>
      </div>

      {/* Program Overview Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: Pilih Program */}
        <div className="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 p-5 rounded-2xl flex flex-col gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 flex items-center justify-center">
              <Banknote className="w-4.5 h-4.5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <p className="text-[11px] font-extrabold text-gray-400 dark:text-slate-500 uppercase tracking-wider">Program</p>
          </div>
          <select
            value={selectedProgram}
            onChange={(e) => { setSelectedProgram(e.target.value); setShowOverlapOnly(false); }}
            className="w-full px-3 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 text-sm font-bold text-gray-800 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all cursor-pointer truncate"
          >
            {stats.uniquePrograms.length === 0 ? (
              <option value="">— Belum ada data —</option>
            ) : (
              stats.uniquePrograms.map(p => (
                <option key={p} value={p}>{p}</option>
              ))
            )}
          </select>
        </div>

        {/* Card 2: Pilih Tahun */}
        <div className="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 p-5 rounded-2xl flex flex-col gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/40 flex items-center justify-center">
              <Calendar className="w-4.5 h-4.5 text-blue-600 dark:text-blue-400" />
            </div>
            <p className="text-[11px] font-extrabold text-gray-400 dark:text-slate-500 uppercase tracking-wider">Tahun</p>
          </div>
          <select
            value={filterYear}
            onChange={(e) => setFilterYear(e.target.value)}
            className="w-full px-3 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800 text-sm font-bold text-gray-800 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all cursor-pointer"
          >
            <option value="Semua Tahun">Semua Tahun</option>
            {Array.from({ length: 7 }, (_, i) => new Date().getFullYear() - 3 + i).map(y => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
        </div>

        {/* Card 3: Ringkasan */}
        <div className="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 p-5 rounded-2xl flex flex-col justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/40 flex items-center justify-center">
              <Users className="w-4.5 h-4.5 text-amber-600 dark:text-amber-400" />
            </div>
            <p className="text-[11px] font-extrabold text-gray-400 dark:text-slate-500 uppercase tracking-wider">Ringkasan</p>
          </div>
          <div className="mt-2">
            <h4 className="text-2xl font-extrabold text-gray-900 dark:text-white">{stats.selectedCount} <span className="text-xs font-semibold text-gray-500 dark:text-slate-400">Penerima</span></h4>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold mt-0.5">Rp {(stats.selectedCount * programAmountVal).toLocaleString('id-ID')}</p>
          </div>
        </div>
      </div>

      {/* Warning Bar (Overlap Detection) */}
      {stats.overlaps.length > 0 && (
        <div className={`p-5 rounded-2xl border flex flex-col md:flex-row items-start md:items-center gap-5 transition-all ${
          showOverlapOnly 
            ? 'bg-red-100 border-red-300 text-red-900' 
            : 'bg-red-50 border-red-100 text-red-800'
        }`}>
          <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center text-red-600 flex-shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <h5 className="font-bold text-base text-red-800">Tumpang Tindih Penerima Terdeteksi</h5>
            <p className="text-xs text-red-700/90 mt-0.5">Sistem mendeteksi <strong>{stats.overlaps.length} warga</strong> menerima lebih dari satu jenis bantuan sosial aktif.</p>
          </div>
          <button 
            onClick={() => setShowOverlapOnly(prev => !prev)}
            className={`px-5 py-2 rounded-xl text-xs font-bold transition-all shadow-sm dark:shadow-none w-full md:w-auto mt-3 md:mt-0 ${
              showOverlapOnly 
                ? 'bg-red-800 text-white hover:bg-red-950' 
                : 'bg-red-600 text-white hover:bg-red-700'
            }`}
          >
            {showOverlapOnly ? "Tampilkan Semua" : "Lihat Penerima Ganda"}
          </button>
        </div>
      )}

      {/* Status Tabs: Usulan / Penerima Aktif / Pernah Mendapat */}
      <div className="flex items-center gap-2 p-1 bg-gray-100 dark:bg-slate-800 rounded-2xl">
        {([
          { key: 'aktif' as const, label: 'Penerima Aktif', icon: <CheckCircle2 size={14} />, color: 'emerald' },
          { key: 'usulan' as const, label: 'Usulan', icon: <Award size={14} />, color: 'amber' },
          { key: 'pernah_mendapat' as const, label: 'Pernah Mendapat', icon: <Calendar size={14} />, color: 'gray' },
        ]).map(tab => {
          const count = bansosData.filter(b => b.program_id === selectedProgram && b.status === tab.key && (filterYear === "Semua Tahun" || b.tahun === Number(filterYear))).length;
          const isActive = activeStatusTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => { setActiveStatusTab(tab.key); setShowOverlapOnly(false); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex-1 justify-center ${
                isActive
                  ? `bg-white dark:bg-slate-900 text-gray-900 dark:text-white shadow-sm`
                  : 'text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300'
              }`}
            >
              {tab.icon}
              {tab.label}
              <span className={`ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                isActive ? 'bg-gray-900 text-white dark:bg-white dark:text-gray-900' : 'bg-gray-200 dark:bg-slate-700 text-gray-600 dark:text-slate-400'
              }`}>{count}</span>
            </button>
          );
        })}
      </div>

      {/* Table Section */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm dark:shadow-none border border-gray-100 dark:border-slate-800 overflow-hidden relative">
        
        {/* Table Top Controls & Quick Filter Bar */}
        <div className="p-6 border-b border-gray-100 dark:border-slate-800 space-y-4 bg-gray-50/20">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center gap-3">
              <h4 className="font-extrabold text-lg text-gray-900 dark:text-white">
                {showOverlapOnly ? "Tumpang Tindih (Penerima Ganda)" : `Penerima ${selectedProgram} — ${filterYear === "Semua Tahun" ? "Semua Tahun" : filterYear}`}
              </h4>
            </div>
            
            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
              <button
                onClick={() => {
                  setSelectedPrintResident(null);
                  setPrintDocType('rekap_12bln');
                  setShowPrintModal(true);
                }}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow-sm transition-all flex items-center gap-1.5 whitespace-nowrap active:scale-95 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                Cetak & Laporan
              </button>

              <div className="relative flex-1 sm:w-[220px]">
                <input 
                  type="text" 
                  placeholder="Cari NIK / Nama / RT..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 border border-gray-200 dark:border-slate-700 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-emerald-500 outline-none bg-white dark:bg-slate-900 text-gray-800 dark:text-slate-100 shadow-sm"
                />
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          </div>
        </div>

        {/* Floating Bulk Actions Bar (Shown when checkboxes are selected) */}
        {selectedNiks.length > 0 && (
          <div className="sticky top-20 z-30 bg-emerald-900 text-white px-6 py-3 border-y border-emerald-700 flex flex-wrap items-center justify-between gap-4 shadow-xl animate-in slide-in-from-top-2 duration-200">
            <div className="flex items-center gap-3">
              <CheckSquare className="w-5 h-5 text-emerald-300" />
              <span className="font-bold text-sm">
                <strong className="font-extrabold text-emerald-300">{selectedNiks.length}</strong> Warga Dicentang
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => handleBulkDisburse(true)}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Tandai Sudah Salur
              </button>
              
              <button
                onClick={() => handleBulkDisburse(false)}
                className="px-3.5 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Batalkan Salur
              </button>

              <button
                onClick={handleBulkRollforwardNextYear}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
              >
                <Calendar className="w-3.5 h-3.5" />
                Teruskan ke Tahun Depan
              </button>

              <button
                onClick={() => setShowBulkStopModal(true)}
                className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
              >
                <Ban className="w-3.5 h-3.5" />
                Hentikan Bantuan (Massal)
              </button>

              {activeStatusTab === 'usulan' && (
                <button
                  onClick={handleBulkApprove}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Setujui Usulan ({selectedNiks.length})
                </button>
              )}

              <button
                onClick={() => setSelectedNiks([])}
                className="px-2.5 py-1.5 text-emerald-200 hover:text-white text-xs font-bold transition-colors ml-2"
              >
                Batal
              </button>
            </div>
          </div>
        )}
        
        {/* Table Main View */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-gray-50/90 dark:bg-slate-800/90 border-b border-gray-100 dark:border-slate-800 text-xs font-extrabold text-gray-500 dark:text-slate-400 uppercase tracking-wider whitespace-nowrap">
              <tr>
                <th className="px-3 py-2 text-center w-10">
                  <input
                    type="checkbox"
                    checked={paginatedResidents.length > 0 && paginatedResidents.every(r => selectedNiks.includes(r.nik))}
                    onChange={handleSelectAllOnPage}
                    className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                  />
                </th>
                <th className="px-3 py-2 cursor-pointer hover:text-emerald-700 transition-colors" onClick={() => handleSort('nik')}>
                  <div className="flex items-center gap-1.5">
                    NIK / WARGA
                    <ArrowUpDown className="w-3.5 h-3.5 text-gray-400" />
                  </div>
                </th>
                <th className="px-3 py-2 cursor-pointer hover:text-emerald-700 transition-colors" onClick={() => handleSort('rtRw')}>
                  <div className="flex items-center gap-1.5">
                    RT / RW
                    <ArrowUpDown className="w-3.5 h-3.5 text-gray-400" />
                  </div>
                </th>
                <th className="px-3 py-2 text-center">TAHUN</th>
                <th className="px-3 py-2">BANTUAN LAINNYA</th>
                <th className="px-3 py-2 cursor-pointer hover:text-emerald-700 transition-colors" onClick={() => handleSort('status')}>
                  <div className="flex items-center gap-1.5">
                    STATUS & PENYALURAN
                    <ArrowUpDown className="w-3.5 h-3.5 text-gray-400" />
                  </div>
                </th>
                <th className="px-3 py-2 text-center">AKSI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-sm text-gray-400">
                    <span className="inline-block animate-spin mr-2">⏳</span> Mengambil data penerima dari server...
                  </td>
                </tr>
              ) : filteredResidents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-sm text-gray-400">
                    Tidak ada data penerima bantuan yang cocok dengan filter.
                  </td>
                </tr>
              ) : (
                paginatedResidents.map((resident) => {
                  const isSelected = selectedNiks.includes(resident.nik);
                  const activeAidList = getActiveAidPrograms(resident, filterYear);
                  const otherAids = activeAidList.filter((aid: string) => 
                    showOverlapOnly ? true : !aid.startsWith(selectedProgram)
                  );
                  const isOverlap = activeAidList.length > 1;

                  // Extract aid year
                  let aidYear = filterYear !== "Semua Tahun" ? filterYear : new Date().getFullYear().toString();
                  const matchedAid = (resident.activeAids || []).find((a: string) => a.startsWith(selectedProgram));
                  if (matchedAid) {
                    const match = matchedAid.match(/\((\d{4})\)/);
                    if (match) aidYear = match[1];
                  }

                  return (
                    <tr 
                      key={resident.nik} 
                      onClick={() => setSelectedResidentDetailModal(resident)}
                      className={`hover:bg-emerald-50/30 dark:hover:bg-slate-800/80 cursor-pointer transition-all duration-300 group ${
                        isSelected ? 'bg-emerald-50/60 dark:bg-emerald-950/30' : ''
                      } ${removingNiks.has(resident.nik) ? 'opacity-0 scale-95 -translate-x-4 bg-red-50/50' : ''}`}
                    >
                      {/* Checkbox Column */}
                      <td className="px-3 py-2 text-center" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedNiks(prev => [...prev, resident.nik]);
                            } else {
                              setSelectedNiks(prev => prev.filter(n => n !== resident.nik));
                            }
                          }}
                          className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                        />
                      </td>

                      {/* Resident Info Column */}
                      <td className="px-3 py-2 whitespace-nowrap">
                        <div>
                          <p className="font-extrabold text-sm text-gray-900 dark:text-white group-hover:text-emerald-700 transition-colors flex items-center gap-2">
                            {resident.name}
                            {resident.gender_color && (
                              <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${resident.gender_color}`}>
                                {resident.gender_color.includes('blue') ? 'L' : 'P'}
                              </span>
                            )}
                          </p>
                          <p className="text-xs font-mono font-semibold text-gray-500 dark:text-slate-400 mt-0.5">NIK: {resident.nik}</p>
                          {resident.status?.toLowerCase().includes('meninggal') && (
                            <span className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 bg-red-100 text-red-700 text-[10px] font-bold rounded-md">
                              <AlertCircle className="w-3 h-3" />
                              {resident.status}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Address Column */}
                      <td className="px-3 py-2 text-xs font-semibold text-gray-600 dark:text-slate-300 whitespace-nowrap">
                        <span className="bg-gray-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg border border-gray-200 dark:border-slate-700 whitespace-nowrap inline-block font-mono text-[11px]">
                          RT {resident.rt || "-"} / RW {resident.rw || "-"}
                        </span>
                      </td>

                      {/* Year Column */}
                      <td className="px-3 py-2 text-xs font-bold font-mono text-center whitespace-nowrap">
                        <span className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200/80 dark:border-amber-800/80 rounded-lg">
                          {aidYear}
                        </span>
                      </td>

                      {/* Other Aids Column */}
                      <td className="px-3 py-2 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                        <div className="flex flex-col gap-1.5 items-start">
                          {otherAids.length > 0 ? (
                            <div className="flex flex-wrap gap-1 max-w-[200px]">
                              {otherAids.map((aid: string) => (
                                <span key={aid} className={`px-2 py-0.5 text-[10px] font-bold rounded-md border ${
                                  aid.startsWith('STOPPED') 
                                    ? 'bg-gray-100 text-gray-500 border-gray-200 dark:bg-slate-800 dark:text-slate-400' 
                                    : 'bg-red-50 text-red-700 border-red-100 dark:bg-red-950 dark:text-red-300'
                                }`}>
                                  {aid}
                                </span>
                              ))}
                            </div>
                          ) : (
                            <span className="text-[10px] text-gray-400 font-medium italic">Bantuan Tunggal</span>
                          )}
                        </div>
                      </td>

                      {/* Status & Disburse Toggle Column */}
                      <td className="px-3 py-2 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                        <div className="flex flex-col gap-1.5 items-start">
                          {isOverlap && (
                            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-red-100 text-red-700 rounded-full font-bold text-[10px] border border-red-200 whitespace-nowrap">
                              <span className="w-1.5 h-1.5 bg-red-600 rounded-full animate-pulse"></span>
                              Tumpang Tindih
                            </div>
                          )}

                          {/* Salur Status */}
                          <div className="flex flex-col gap-1">
                            {MONTHLY_PROGRAMS.includes(selectedProgram) ? (
                              <>
                                <div className="flex items-center gap-1.5">
                                  <span className={`px-2 py-0.5 rounded-md font-extrabold text-[10px] border shadow-2xs ${
                                    (disbursedMonths[resident.nik] || []).length === 12
                                      ? 'bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-950 dark:text-blue-200'
                                      : (disbursedMonths[resident.nik] || []).length > 0
                                      ? 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-200'
                                      : 'bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950 dark:text-amber-200'
                                  }`}>
                                    {(disbursedMonths[resident.nik] || []).length} / 12 Bln
                                  </span>
                                  <span className="text-[10px] font-bold text-gray-500 font-mono">
                                    Rp {(((disbursedMonths[resident.nik] || []).length * programAmountVal)).toLocaleString('id-ID')}
                                  </span>
                                </div>
                                <div className="flex flex-wrap gap-[1px]">
                                  {MONTHS_LIST.map((m, idx) => {
                                    const isDisbursed = (disbursedMonths[resident.nik] || []).includes(m.id);
                                    const isCurrentMonth = idx === new Date().getMonth();
                                    return (
                                      <button
                                        key={m.id}
                                        type="button"
                                        onClick={() => handleToggleMonth(resident.nik, m.id)}
                                        title={`${m.fullName}: ${isDisbursed ? 'Sudah Salur ✓' : 'Belum Salur'}`}
                                        className={`w-4 h-3.5 rounded text-[7px] font-black transition-all border flex items-center justify-center cursor-pointer active:scale-90 ${
                                          isDisbursed
                                            ? 'bg-emerald-600 text-white border-emerald-700 hover:bg-emerald-700'
                                            : isCurrentMonth
                                            ? 'bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-200'
                                            : 'bg-gray-100 dark:bg-slate-800 text-gray-400 dark:text-slate-500 border-gray-200 dark:border-slate-700 hover:bg-emerald-100 hover:text-emerald-700'
                                        }`}
                                      >
                                        {m.label}
                                      </button>
                                    );
                                  })}
                                </div>
                              </>
                            ) : (
                              <span className={`px-2.5 py-1 rounded-md font-bold text-[10px] border whitespace-nowrap ${
                                activeStatusTab === 'usulan'
                                  ? 'bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950 dark:text-amber-200'
                                  : activeStatusTab === 'pernah_mendapat'
                                  ? 'bg-gray-100 text-gray-600 border-gray-200 dark:bg-slate-800 dark:text-slate-400'
                                  : 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-200'
                              }`}>
                                {activeStatusTab === 'usulan' ? 'Menunggu' : activeStatusTab === 'pernah_mendapat' ? 'Selesai' : 'Aktif'}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Single Action Column */}
                      <td className="px-3 py-2 text-center whitespace-nowrap">
                        {showOverlapOnly ? (
                          <p className="text-[10px] font-bold text-red-500 uppercase tracking-wider whitespace-nowrap">Kelola via Tab Utama</p>
                        ) : activeStatusTab === 'usulan' ? (
                          <div className="flex items-center justify-center gap-1.5 whitespace-nowrap">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const yearNum = filterYear !== "Semua Tahun" ? Number(filterYear) : new Date().getFullYear();
                                const record = bansosData.find(b => b.resident_id === resident.nik && b.program_id === selectedProgram && b.status === 'usulan' && b.tahun === yearNum);
                                if (record) handleApproveBansos(record.id, resident.nik, selectedProgram, yearNum);
                                else showToast("Data usulan tidak ditemukan", "error");
                              }}
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs active:scale-95 transition-all shadow-sm inline-flex items-center gap-1"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" /> Setujui
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleHapusDariDaftar(resident.nik, selectedProgram);
                              }}
                              className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg border border-gray-200/60 transition-colors active:scale-95"
                              title="Hapus Usulan dari Daftar"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : activeStatusTab === 'pernah_mendapat' ? (
                          <div className="flex items-center justify-center gap-1.5 whitespace-nowrap">
                            <span className="text-[10px] font-bold text-gray-400 uppercase">
                              {bansosData.find(b => b.resident_id === resident.nik && b.program_id === selectedProgram && b.status === 'pernah_mendapat')?.alasan_berhenti || 'Tidak aktif'}
                            </span>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center gap-1.5 whitespace-nowrap">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const nextYr = filterYear !== "Semua Tahun" ? (parseInt(filterYear) + 1).toString() : (new Date().getFullYear() + 1).toString();
                                handleSingleRollforward(resident, nextYr);
                              }}
                              className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 rounded-lg border border-blue-200/80 dark:border-blue-800/80 transition-all inline-flex items-center gap-1 font-bold text-xs active:scale-95 whitespace-nowrap shadow-2xs"
                              title="Teruskan Bantuan ke Tahun Depan"
                            >
                              <Calendar className="w-3.5 h-3.5 text-blue-600" />
                              <span>Ke {filterYear !== "Semua Tahun" ? parseInt(filterYear) + 1 : new Date().getFullYear() + 1}</span>
                            </button>

                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedNiks([resident.nik]);
                                setShowBulkStopModal(true);
                              }}
                              className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 rounded-lg border border-rose-200/80 dark:border-rose-800/80 transition-all inline-flex items-center gap-1 font-bold text-xs active:scale-95 whitespace-nowrap shadow-2xs"
                              title="Hentikan Bantuan (Dengan Tanggal & Alasan Rinci)"
                            >
                              <Ban className="w-3.5 h-3.5 text-rose-600" />
                              <span>Hentikan</span>
                            </button>

                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedPrintResident(resident);
                                setPrintDocType('slip_warga');
                                setShowPrintModal(true);
                              }}
                              className="p-1.5 text-emerald-700 hover:text-emerald-900 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg border border-emerald-200/80 dark:border-emerald-800/80 transition-colors inline-flex items-center justify-center active:scale-95"
                              title="Cetak Slip Bukti Penerimaan Warga"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>

                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                handleHapusDariDaftar(resident.nik, selectedProgram);
                              }}
                              className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg border border-gray-200/60 dark:border-slate-700/60 transition-colors inline-flex items-center justify-center active:scale-95"
                              title="Hapus dari Daftar (Tidak ubah data penduduk)"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 border-t border-gray-100 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-800/50 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-semibold text-gray-600 dark:text-slate-400">
          <div className="flex items-center gap-3">
            <span>Tampilkan</span>
            <select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg font-bold text-gray-800 dark:text-slate-200 outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value={10}>10 Baris</option>
              <option value={25}>25 Baris</option>
              <option value={50}>50 Baris</option>
              <option value={100}>100 Baris</option>
            </select>
            <span>
              Menampilkan {filteredResidents.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0} - {Math.min(currentPage * itemsPerPage, filteredResidents.length)} dari {filteredResidents.length} data
            </span>
          </div>

          {/* Pagination Page Controls */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="p-2 rounded-lg border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900 disabled:opacity-40 hover:bg-gray-50 dark:hover:bg-slate-800 transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-3 py-1 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg font-bold">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="p-2 rounded-lg border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900 disabled:opacity-40 hover:bg-gray-50 dark:hover:bg-slate-800 transition-all"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

      {/* Modal Hentikan Bantuan Massal / Rinci */}
      {showBulkStopModal && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden border border-gray-100 dark:border-slate-800 animate-in zoom-in-95 duration-200 my-8">
            <div className="p-6 border-b border-gray-100 dark:border-slate-800 bg-rose-50/50 dark:bg-rose-950/30 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center">
                  <Ban className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-rose-900 dark:text-rose-200">Hentikan Bantuan Resmi</h3>
                  <p className="text-xs text-rose-700 dark:text-rose-400">{selectedNiks.length} Warga Terpilih</p>
                </div>
              </div>
              <button 
                onClick={() => setShowBulkStopModal(false)}
                className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 font-sans">
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-gray-700 dark:text-slate-300">
                  Tanggal Penghentian Resmi (Rinci)
                </label>
                <input
                  type="date"
                  value={bulkStopDate}
                  onChange={(e) => setBulkStopDate(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-gray-700 dark:text-slate-300">
                  Alasan Utama Penghentian
                </label>
                <select
                  value={bulkStopReason}
                  onChange={(e) => setBulkStopReason(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold outline-none focus:ring-2 focus:ring-rose-500"
                >
                  <option value="Meninggal Dunia">Meninggal Dunia</option>
                  <option value="Pindah Domisili Keluar Desa">Pindah Domisili Keluar Desa</option>
                  <option value="Telah Mampu / Sejahtera secara Ekonomi">Telah Mampu / Sejahtera secara Ekonomi</option>
                  <option value="Penerima Ganda Terlarang">Penerima Ganda Terlarang</option>
                  <option value="Hasil Evaluasi Musdes">Hasil Evaluasi Musdes</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-gray-700 dark:text-slate-300">
                  Catatan / Keterangan Rinci Tambahan Admin (Opsional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Tuliskan keterangan rinci admin (misal: Hasil Musdes 15 Juli, ybs telah diangkat PNS / pindah ke Kota Bandung)..."
                  value={bulkStopNote}
                  onChange={(e) => setBulkStopNote(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-100 dark:border-rose-900/60 rounded-xl text-xs text-rose-800 dark:text-rose-300 space-y-1">
                <p className="font-bold">Format Catatan Riwayat:</p>
                <p className="font-mono text-[11px] bg-white dark:bg-slate-900 p-2 rounded border border-rose-200 dark:border-rose-900 leading-snug">
                  STOPPED: {selectedProgram} | Tgl: {new Date(bulkStopDate).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })} | Alasan: {bulkStopReason}{bulkStopNote.trim() ? ` | Catatan: ${bulkStopNote.trim()}` : ''}
                </p>
              </div>
            </div>

            <div className="p-4 bg-gray-50 dark:bg-slate-800/50 border-t border-gray-100 dark:border-slate-800 flex justify-end gap-3">
              <button
                onClick={() => setShowBulkStopModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-800"
              >
                Batal
              </button>
              <button
                onClick={handleConfirmBulkStopAid}
                disabled={isSaving}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-2 active:scale-95 disabled:opacity-50"
              >
                <Ban className="w-4 h-4" />
                {isSaving ? "Proses..." : "Konfirmasi Hentikan"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Tambah Penerima */}
      {showModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-in fade-in zoom-in-95 slide-in-from-bottom-4 duration-300 ease-out">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-6 flex justify-between items-center border-b border-gray-100 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-800/50">
              <h3 className="font-bold text-xl text-emerald-800">Tambah Penerima Bantuan</h3>
              <button 
                onClick={() => setShowModal(false)}
                className="p-2 hover:bg-gray-200 rounded-full text-gray-500 dark:text-slate-400 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Program Name Badge */}
              <div className="p-3 bg-emerald-50 text-emerald-800 rounded-xl flex justify-between items-center border border-emerald-100">
                <span className="text-xs font-bold uppercase tracking-wider">Program Sasaran:</span>
                <span className="text-sm font-extrabold">{selectedProgram}</span>
              </div>

              {/* Search Section */}
              <div>
                <label className="block text-xs font-extrabold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">CARI NAMA / NIK WARGA</label>
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="Masukkan nama atau NIK warga..."
                    value={searchResidentQuery}
                    onChange={(e) => {
                      setSearchResidentQuery(e.target.value);
                      setSelectedResidentNik(""); // Reset selection if typing
                    }}
                    className="w-full pl-10 pr-4 py-3 border border-gray-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all text-sm font-semibold text-gray-800 dark:text-slate-100"
                  />
                  <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>

                {/* Live Search Suggestion Box */}
                {searchResidentQuery.trim() !== "" && !selectedResidentNik && (
                  <div className="mt-2 border border-gray-100 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 shadow-lg dark:shadow-none overflow-hidden divide-y divide-gray-50 max-h-[180px] overflow-y-auto">
                    {availableResidentsForModal.length === 0 ? (
                      <p className="p-3.5 text-xs text-gray-400 text-center font-medium">Warga tidak ditemukan atau sudah terdaftar di program ini</p>
                    ) : (
                      availableResidentsForModal.map(r => (
                        <div 
                          key={r.nik}
                          onClick={() => {
                            setSelectedResidentNik(r.nik);
                            setSearchResidentQuery(r.name);
                          }}
                          className="p-3.5 hover:bg-emerald-50/40 cursor-pointer transition-colors text-left flex justify-between items-center"
                        >
                          <div>
                            <p className="text-sm font-extrabold text-gray-800 dark:text-slate-100">{r.name}</p>
                            <p className="text-[11px] font-bold text-gray-500 dark:text-slate-400">NIK: {r.nik}</p>
                          </div>
                          <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md">Pilih</span>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>

              {/* Resident Info Box & Overlap Check (Visible only when resident selected) */}
              {selectedResidentDetail && (
                <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-200">
                  {/* Overlap Check Banner */}
                  {selectedResidentDetail.activeAids && selectedResidentDetail.activeAids.length > 0 ? (
                    <div className="p-4 bg-red-50 border border-red-100 rounded-xl flex items-start gap-4">
                      <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-bold text-red-800 text-sm">Peringatan Penerimaan Ganda</p>
                        <p className="text-xs text-red-600 mt-1 leading-relaxed">
                          Warga ini sudah menerima program aktif: <strong className="font-bold">{selectedResidentDetail.activeAids.join(", ")}</strong>. Pastikan aturan program membolehkan akumulasi bantuan.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl flex items-start gap-4">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-bold text-emerald-800 text-sm">Warga Layak Bantuan</p>
                        <p className="text-xs text-emerald-600 mt-1">Warga ini tidak sedang menerima program bantuan sosial aktif lainnya.</p>
                      </div>
                    </div>
                  )}

                  {/* Details Form (Disabled until NIK verified) */}
                  <div className="space-y-4 border border-gray-100 dark:border-slate-800 p-4 rounded-xl bg-gray-50/30">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">NAMA LENGKAP</label>
                      <p className="text-sm font-bold text-gray-800 dark:text-slate-100">{selectedResidentDetail.name}</p>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">ALAMAT RT / RW</label>
                      <p className="text-sm font-semibold text-gray-700 dark:text-slate-300">
                        RT {selectedResidentDetail.rt || "-"} / RW {selectedResidentDetail.rw || "-"}, {selectedResidentDetail.desa || "Sukamaju"}, {selectedResidentDetail.address || ""}
                      </p>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">STATUS HUBUNGAN / PEKERJAAN</label>
                      <p className="text-xs font-semibold text-gray-600 dark:text-slate-400">
                        {selectedResidentDetail.familyRelation || "Kepala Keluarga"} — {selectedResidentDetail.job || "-"}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="p-6 bg-gray-50/50 dark:bg-slate-800/50 border-t border-gray-100 dark:border-slate-800 flex justify-end gap-3">
              <button 
                onClick={() => setShowModal(false)}
                className="px-6 py-2.5 font-bold text-gray-600 dark:text-slate-400 hover:bg-gray-200 rounded-xl transition-all text-sm"
              >
                Batal
              </button>
              <button 
                onClick={handleAddAid}
                disabled={!selectedResidentNik || isSaving}
                className="bg-emerald-700 text-white px-6 py-2.5 rounded-xl font-bold hover:bg-emerald-800 shadow-sm dark:shadow-none transition-all text-sm disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {isSaving ? "Menyimpan..." : "Simpan Penerima"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Berita Acara Musdes */}
      {showBaModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto print:p-0 print:bg-white print:static">
          <div className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden border border-gray-100 dark:border-slate-800 my-8 animate-in fade-in zoom-in-95 duration-200 print:shadow-none print:border-none print:w-full print:max-w-none print:rounded-none">
            <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50/50 dark:bg-slate-800/50 print:hidden">
              <div className="flex items-center gap-2">
                <FileText className="w-6 h-6 text-indigo-600" />
                <h3 className="font-bold text-xl text-gray-900 dark:text-white">Dokumen Berita Acara Musdes</h3>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => window.print()}
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm rounded-xl flex items-center gap-2 shadow-sm transition-all active:scale-95"
                >
                  <Download className="w-4 h-4" /> Cetak Dokumen (PDF)
                </button>
                <button 
                  onClick={() => setShowBaModal(false)}
                  className="p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-full text-gray-500 dark:text-slate-400 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="printable-area p-8 md:p-12 space-y-8 bg-white dark:bg-slate-900 text-gray-900 dark:text-slate-100 font-serif leading-relaxed text-sm print:p-0 print:text-black">
              {/* KOP Desa Header */}
              <div className="text-center border-b-4 border-double border-gray-900 dark:border-white pb-6 space-y-1">
                <h2 className="text-xl font-bold uppercase tracking-wider">PEMERINTAH KABUPATEN BOGOR</h2>
                <h1 className="text-2xl font-black uppercase tracking-wide">KECAMATAN CIBINONG — DESA SUKAMAJU</h1>
                <p className="text-xs font-sans text-gray-600 dark:text-slate-400 italic">Jl. Raya Sukamaju No. 01, Kode Pos 16910 • Website: sukamaju.desa.id</p>
              </div>

              {/* Document Title */}
              <div className="text-center space-y-1">
                <h3 className="text-lg font-bold uppercase underline tracking-wide">BERITA ACARA MUSYAWARAH DESA</h3>
                <p className="text-xs font-sans font-bold text-gray-700 dark:text-slate-300">
                  PENETAPAN KELUARGA PENERIMA MANFAAT (KPM) PROGRAM {selectedProgram.toUpperCase()} TAHUN 2026
                </p>
                <p className="text-xs font-sans text-gray-500">Nomor: 140 / BA-MUSDES / {new Date().getFullYear()}</p>
              </div>

              {/* Preamble */}
              <div className="space-y-3 text-justify font-sans text-xs md:text-sm">
                <p>
                  Pada hari ini <strong>{new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</strong>, bertempat di Balai Desa Sukamaju, telah diselenggarakan Musyawarah Desa (Musdes) penetapan usulan calon Keluarga Penerima Manfaat (KPM) program bantuan sosial <strong>{selectedProgram}</strong>.
                </p>
                <p>
                  Berdasarkan verifikasi kriteria kelayakan dan ketersediaan anggaran desa, disepakati bahwa nama-nama warga masyarakat di bawah ini dinyatakan <strong>SAH dan LAYAK</strong> sebagai penerima bantuan:
                </p>
              </div>

              {/* Recipients Table */}
              <div className="overflow-x-auto font-sans">
                <table className="w-full border-collapse border border-gray-400 text-xs">
                  <thead>
                    <tr className="bg-gray-100 dark:bg-slate-800 text-center font-bold">
                      <th className="border border-gray-400 px-3 py-2 w-10">NO</th>
                      <th className="border border-gray-400 px-3 py-2">NIK</th>
                      <th className="border border-gray-400 px-3 py-2">NAMA LENGKAP</th>
                      <th className="border border-gray-400 px-3 py-2">ALAMAT / RT / RW</th>
                      <th className="border border-gray-400 px-3 py-2">STATUS KRITERIA</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredResidents.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="border border-gray-400 px-3 py-4 text-center text-gray-500 italic">Belum ada penerima bantuan yang ditetapkan dalam program ini.</td>
                      </tr>
                    ) : (
                      filteredResidents.map((res, index) => (
                        <tr key={res.nik} className="hover:bg-gray-50">
                          <td className="border border-gray-400 px-3 py-2 text-center font-bold">{index + 1}</td>
                          <td className="border border-gray-400 px-3 py-2 font-mono font-semibold">{res.nik}</td>
                          <td className="border border-gray-400 px-3 py-2 font-bold">{res.name}</td>
                          <td className="border border-gray-400 px-3 py-2">RT {res.rt || "-"} / RW {res.rw || "-"}, Desa Sukamaju</td>
                          <td className="border border-gray-400 px-3 py-2 text-center font-semibold text-emerald-700">Terverifikasi Layak</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* Closing */}
              <p className="font-sans text-xs md:text-sm text-justify">
                Demikian Berita Acara ini dibuat dan disahkan dengan penuh tanggung jawab untuk dipergunakan sebagaimana mestinya.
              </p>

              {/* Signatures Grid */}
              <div className="pt-8 font-sans text-xs grid grid-cols-3 gap-6 text-center">
                <div className="space-y-16">
                  <p className="font-bold">Ketua BPD Sukamaju</p>
                  <p className="font-bold underline uppercase">( H. AHMYAD SODIK, S.IP )</p>
                </div>
                <div className="space-y-16">
                  <p className="font-bold">Sekretaris Desa</p>
                  <p className="font-bold underline uppercase">( MUHAMMAD RIFQI, S.KOM )</p>
                </div>
                <div className="space-y-16">
                  <p className="font-bold">Kepala Desa Sukamaju</p>
                  <p className="font-bold underline uppercase">( DRS. H. SUKIRMAN )</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Nice custom confirm modal */}
      <ConfirmModal
        isOpen={confirmState.isOpen}
        title={confirmState.title}
        message={confirmState.message}
        onConfirm={confirmState.onConfirm}
        onCancel={() => setConfirmState(prev => ({ ...prev, isOpen: false }))}
        type="danger"
        confirmText="Ya, Hapus"
        cancelText="Batal"
      />

      {/* Resident Detail Modal on Row Click */}
      {showImport && (
        <AdminBantuanImport 
          onClose={() => setShowImport(false)} 
          onRefresh={fetchData} 
          existingResidents={residents} 
        />
      )}

      {/* 3-Tab Tambah Penerima (Manual / Import File / Scan Kamera) */}
      {showTambahPenerima && (
        <AdminBantuanTambahPenerima
          onClose={() => setShowTambahPenerima(false)}
          onRefresh={fetchData}
          existingResidents={residents}
          initialProgram={selectedProgram}
        />
      )}

      {/* Detail & Edit Penerima Bantuan Modal */}
      {selectedResidentDetailModal && (
        <div className="fixed inset-0 z-[200] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden my-8 animate-in zoom-in-95 duration-200">

            {/* Header */}
            <div className="px-6 pt-5 pb-4 border-b border-gray-100 dark:border-slate-800">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-extrabold text-gray-900 dark:text-white">{selectedResidentDetailModal.name}</h3>
                  <div className="flex items-center gap-3 mt-1 text-[11px] text-gray-400 font-mono">
                    <span>{selectedResidentDetailModal.nik}</span>
                    <span>{selectedResidentDetailModal.gender_color?.includes('blue') ? 'L' : 'P'}</span>
                    <span>RT {selectedResidentDetailModal.rt || "-"} / RW {selectedResidentDetailModal.rw || "-"}</span>
                    {selectedResidentDetailModal.isLansiaTunggal && (
                      <span className="text-amber-600 font-bold">Lansia Tunggal</span>
                    )}
                    {onNavigateToTab && onSetPresetResidentNik && (
                      <button
                        onClick={() => {
                          onSetPresetResidentNik(selectedResidentDetailModal.nik);
                          setSelectedResidentDetailModal(null);
                          onNavigateToTab('penduduk');
                        }}
                        className="text-emerald-600 hover:text-emerald-700 hover:underline flex items-center gap-1 cursor-pointer font-bold"
                      >
                        <ExternalLink className="w-3 h-3" /> Profil
                      </button>
                    )}
                  </div>
                </div>
                <button onClick={() => setSelectedResidentDetailModal(null)} className="p-1.5 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg text-gray-400 transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">

              {/* Program Aktif & Pernah Mendapat */}
              {(() => {
                const nik = selectedResidentDetailModal.nik;
                const residentBansos = bansosData.filter(b => b.resident_id === nik);
                const aktifPrograms = residentBansos.filter(b => b.status === 'aktif');
                const pernahPrograms = residentBansos.filter(b => b.status === 'pernah_mendapat');
                const usulanPrograms = residentBansos.filter(b => b.status === 'usulan');
                return (
                  <div className="space-y-2">
                    {aktifPrograms.length > 0 && (
                      <div>
                        <label className="block text-[10px] font-bold text-emerald-600 uppercase tracking-wider mb-1">Aktif Diterima</label>
                        <div className="flex flex-wrap gap-1.5">
                          {aktifPrograms.map(b => (
                            <span
                              key={b.program_id}
                              onClick={() => setSelectedProgram(b.program_id)}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border cursor-pointer transition-all ${
                                selectedProgram === b.program_id
                                  ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm'
                                  : 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800 hover:bg-emerald-100'
                              }`}
                            >
                              {b.program_id}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    {pernahPrograms.length > 0 && (
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Pernah Menerima</label>
                        <div className="flex flex-wrap gap-1.5">
                          {pernahPrograms.map(b => (
                            <span
                              key={b.program_id}
                              className="px-2.5 py-1 rounded-lg text-[10px] font-bold border bg-gray-50 text-gray-400 border-gray-200 dark:bg-slate-800 dark:text-slate-500 dark:border-slate-700 line-through"
                            >
                              {b.program_id}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    {usulanPrograms.length > 0 && (
                      <div>
                        <label className="block text-[10px] font-bold text-amber-500 uppercase tracking-wider mb-1">Menunggu Persetujuan</label>
                        <div className="flex flex-wrap gap-1.5">
                          {usulanPrograms.map(b => (
                            <span
                              key={b.program_id}
                              onClick={() => setSelectedProgram(b.program_id)}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border cursor-pointer transition-all ${
                                selectedProgram === b.program_id
                                  ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                                  : 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800 hover:bg-amber-100'
                              }`}
                            >
                              {b.program_id}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    {aktifPrograms.length === 0 && pernahPrograms.length === 0 && usulanPrograms.length === 0 && (
                      <div className="text-[10px] text-gray-400 italic">Belum terdaftar di program bantuan apapun.</div>
                    )}
                  </div>
                );
              })()}

              {/* Info Usulan: Keterangan & Foto */}
              {(selectedResidentDetailModal.bansosStatus === 'usulan' || (!selectedResidentDetailModal.isOrphan && activeStatusTab === 'usulan')) && (() => {
                const bansosRecord = bansosData.find(b => 
                  b.resident_id === selectedResidentDetailModal.nik && 
                  b.program_id === selectedProgram && 
                  b.status === 'usulan'
                );
                const ket = selectedResidentDetailModal.keterangan || bansosRecord?.keterangan || '';
                const photo = selectedResidentDetailModal.photo_url || bansosRecord?.photo_url || '';
                if (!ket && !photo) return null;
                return (
                  <div className="flex gap-3 p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-xl">
                    {photo && (
                      <img src={photo} alt="Foto" className="w-16 h-16 rounded-lg object-cover border border-amber-200 flex-shrink-0" />
                    )}
                    {ket && (
                      <div>
                        <p className="text-[10px] font-bold text-amber-700 uppercase">Keterangan</p>
                        <p className="text-xs text-amber-800 dark:text-amber-200 mt-0.5">{ket}</p>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Status Penyaluran — Sembunyikan grid untuk usulan */}
              {activeStatusTab !== 'usulan' && MONTHLY_PROGRAMS.includes(selectedProgram) ? (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Penyaluran</label>
                    <span className="text-[10px] font-bold text-gray-500 font-mono">{(disbursedMonths[selectedResidentDetailModal.nik] || []).length}/12 bln</span>
                  </div>

                  <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5">
                    {MONTHS_LIST.map((m, idx) => {
                      const isDisbursed = (disbursedMonths[selectedResidentDetailModal.nik] || []).includes(m.id);
                      const isCurrentMonth = idx === new Date().getMonth();
                      return (
                        <button
                          key={m.id}
                          type="button"
                          onClick={() => handleToggleMonth(selectedResidentDetailModal.nik, m.id)}
                          className={`py-2 px-1 rounded-lg text-[10px] font-bold border transition-all flex flex-col items-center gap-0.5 cursor-pointer active:scale-95 ${
                            isDisbursed
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : isCurrentMonth
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-gray-50 text-gray-400 border-gray-200 dark:bg-slate-800 dark:text-slate-500 dark:border-slate-700 hover:bg-emerald-50 hover:text-emerald-600'
                          }`}
                        >
                          <span>{m.id}</span>
                          <span className="text-[8px] opacity-70">{isDisbursed ? '✓' : isCurrentMonth ? '•' : '–'}</span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-gray-100 dark:border-slate-800">
                    <span className="text-xs font-bold text-gray-500">
                      Rp {(((disbursedMonths[selectedResidentDetailModal.nik] || []).length * programAmountVal)).toLocaleString('id-ID')}
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleSetMonthsUntil(selectedResidentDetailModal.nik, new Date().getMonth())}
                        className="px-2 py-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-md transition-colors cursor-pointer"
                      >
                        Salur s.d. {MONTHS_LIST[new Date().getMonth()].id}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSetAll12Months(selectedResidentDetailModal.nik)}
                        className="px-2 py-1 text-[10px] font-bold text-emerald-700 bg-emerald-100 hover:bg-emerald-200 rounded-md transition-colors cursor-pointer"
                      >
                        Lunas
                      </button>
                      <button
                        type="button"
                        onClick={() => handleResetMonths(selectedResidentDetailModal.nik)}
                        className="px-2 py-1 text-[10px] font-bold text-gray-400 hover:bg-gray-100 rounded-md transition-colors cursor-pointer"
                      >
                        Reset
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Status</label>
                  <span className={`px-2.5 py-1 rounded-md font-bold text-[10px] border ${
                    activeStatusTab === 'usulan'
                      ? 'bg-amber-100 text-amber-800 border-amber-200'
                      : activeStatusTab === 'pernah_mendapat'
                      ? 'bg-gray-100 text-gray-600 border-gray-200'
                      : 'bg-emerald-100 text-emerald-800 border-emerald-200'
                  }`}>
                    {activeStatusTab === 'usulan' ? 'Menunggu' : activeStatusTab === 'pernah_mendapat' ? 'Selesai' : 'Aktif'}
                  </span>
                </div>
              )}

              {/* Aksi */}
              {activeStatusTab === 'usulan' ? (
                <div className="flex flex-wrap gap-1.5 pt-2 border-t border-gray-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      const yearNum = filterYear !== "Semua Tahun" ? Number(filterYear) : new Date().getFullYear();
                      const record = bansosData.find(b => b.resident_id === selectedResidentDetailModal.nik && b.program_id === selectedProgram && b.status === 'usulan' && b.tahun === yearNum);
                      if (record) handleApproveBansos(record.id, selectedResidentDetailModal.nik, selectedProgram, yearNum);
                      else showToast("Data usulan tidak ditemukan", "error");
                      setSelectedResidentDetailModal(null);
                    }}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs active:scale-95 transition-all shadow-sm inline-flex items-center gap-1 cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" /> Setujui
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleHapusDariDaftar(selectedResidentDetailModal.nik, selectedProgram);
                      setSelectedResidentDetailModal(null);
                    }}
                    className="px-3 py-1.5 text-red-500 border border-red-200 hover:bg-red-50 rounded-lg font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" /> Hapus
                  </button>
                </div>
              ) : (
                <div className="flex flex-wrap gap-1.5 pt-2 border-t border-gray-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedPrintResident(selectedResidentDetailModal);
                      setPrintDocType('slip_warga');
                      setShowPrintModal(true);
                    }}
                    className="px-3 py-1.5 text-[10px] font-bold text-gray-600 border border-gray-200 hover:bg-gray-50 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <Printer className="w-3 h-3" /> Cetak Slip
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const nextYr = filterYear !== "Semua Tahun" ? (parseInt(filterYear) + 1).toString() : (new Date().getFullYear() + 1).toString();
                      handleSingleRollforward(selectedResidentDetailModal, nextYr);
                    }}
                    className="px-3 py-1.5 text-[10px] font-bold text-gray-600 border border-gray-200 hover:bg-gray-50 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <Calendar className="w-3 h-3" /> Teruskan ke {filterYear !== "Semua Tahun" ? parseInt(filterYear) + 1 : new Date().getFullYear() + 1}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedNiks([selectedResidentDetailModal.nik]);
                      setSelectedResidentDetailModal(null);
                      setShowBulkStopModal(true);
                    }}
                    className="px-3 py-1.5 text-[10px] font-bold text-red-500 border border-red-200 hover:bg-red-50 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <Ban className="w-3 h-3" /> Hentikan
                  </button>
                </div>
              )}

            </div>

            {/* Footer */}
            <div className="px-6 py-3 border-t border-gray-100 dark:border-slate-800 flex justify-end gap-2">
              <button
                onClick={() => setSelectedResidentDetailModal(null)}
                className="px-4 py-1.5 text-[11px] font-bold text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
              >
                Batal
              </button>
              <button
                onClick={() => {
                  showToast(`Data ${selectedResidentDetailModal.name} diperbarui.`, "success");
                  setSelectedResidentDetailModal(null);
                }}
                className="px-5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
              >
                <Check className="w-3.5 h-3.5" /> Simpan
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Comprehensive Print & Reports Modal */}
      {showPrintModal && (
        <div className="fixed inset-0 z-[220] flex items-center justify-center bg-black/70 backdrop-blur-md p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static">
          <div className="bg-white dark:bg-slate-900 w-full max-w-5xl rounded-3xl shadow-2xl overflow-hidden border border-gray-100 dark:border-slate-800 my-4 sm:my-8 animate-in fade-in zoom-in-95 duration-200 print:shadow-none print:border-none print:w-full print:max-w-none print:rounded-none">
            
            {/* Modal Header & Options (Hidden when Printing) */}
            <div className="p-4 sm:p-6 border-b border-gray-100 dark:border-slate-800 bg-gray-50/90 dark:bg-slate-800/90 space-y-4 print:hidden">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold">
                    <Printer className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-lg text-gray-900 dark:text-white">Cetak Dokumen & Laporan Bantuan Sosial</h3>
                    <p className="text-xs text-gray-500 dark:text-slate-400">Pilih format laporan dan dokumen resmi desa untuk dicetak atau diunduh sebagai PDF.</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => window.print()}
                    className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs sm:text-sm rounded-xl flex items-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer whitespace-nowrap"
                  >
                    <Printer className="w-4 h-4" /> Cetak Dokumen (PDF)
                  </button>
                  <button 
                    onClick={() => setShowPrintModal(false)}
                    className="p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-full text-gray-500 dark:text-slate-400 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Mode Selector Tabs */}
              <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-gray-200/60 dark:border-slate-700/60">
                <button
                  type="button"
                  onClick={() => setPrintDocType('rekap_12bln')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    printDocType === 'rekap_12bln'
                      ? 'bg-emerald-700 text-white shadow-sm'
                      : 'bg-white dark:bg-slate-900 text-gray-700 dark:text-slate-300 border border-gray-200 dark:border-slate-700 hover:bg-gray-100'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  1. Rekapitulasi 12 Bulan (Tabel Jan-Des)
                </button>

                <button
                  type="button"
                  onClick={() => setPrintDocType('tanda_terima')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    printDocType === 'tanda_terima'
                      ? 'bg-emerald-700 text-white shadow-sm'
                      : 'bg-white dark:bg-slate-900 text-gray-700 dark:text-slate-300 border border-gray-200 dark:border-slate-700 hover:bg-gray-100'
                  }`}
                >
                  <CheckSquare className="w-3.5 h-3.5" />
                  2. Daftar Tanda Terima (Pencairan)
                </button>

                <button
                  type="button"
                  onClick={() => setPrintDocType('ba_musdes')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    printDocType === 'ba_musdes'
                      ? 'bg-emerald-700 text-white shadow-sm'
                      : 'bg-white dark:bg-slate-900 text-gray-700 dark:text-slate-300 border border-gray-200 dark:border-slate-700 hover:bg-gray-100'
                  }`}
                >
                  <Award className="w-3.5 h-3.5" />
                  3. Berita Acara Musdes
                </button>

                <button
                  type="button"
                  onClick={() => setPrintDocType('slip_warga')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    printDocType === 'slip_warga'
                      ? 'bg-emerald-700 text-white shadow-sm'
                      : 'bg-white dark:bg-slate-900 text-gray-700 dark:text-slate-300 border border-gray-200 dark:border-slate-700 hover:bg-gray-100'
                  }`}
                >
                  <DollarSign className="w-3.5 h-3.5" />
                  4. Slip / Kupon Penerima Warga
                </button>
              </div>

              {/* Dynamic Controls per Mode */}
              {printDocType === 'tanda_terima' && (
                <div className="flex items-center gap-2 bg-amber-50 dark:bg-amber-950/40 p-2.5 rounded-xl border border-amber-200 dark:border-amber-800 text-xs">
                  <span className="font-bold text-amber-900 dark:text-amber-200">Pilih Bulan Pencairan:</span>
                  <select
                    value={selectedPrintMonth}
                    onChange={(e) => setSelectedPrintMonth(e.target.value)}
                    className="px-3 py-1 bg-white dark:bg-slate-900 border border-amber-300 rounded-lg font-extrabold text-amber-900 dark:text-amber-100 outline-none"
                  >
                    {MONTHS_LIST.map(m => (
                      <option key={m.id} value={m.id}>Bulan {m.fullName}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* Printable Document Body Area */}
            <div className="printable-area p-6 md:p-10 bg-white text-gray-900 font-sans leading-relaxed text-xs md:text-sm max-h-[75vh] overflow-y-auto print:max-h-none print:overflow-visible print:p-0 print:text-black">
              
              {/* Document KOP Header */}
              <div style={{ borderBottom: '3px solid #000', marginBottom: '16px', paddingBottom: '8px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                  <div style={{ width: '90px', height: '100px', flex: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
                    <img src={kopLogoUrl} style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                  </div>
                  <div style={{ textAlign: 'center', flex: 1, paddingRight: '90px' }}>
                    <div style={{ fontWeight: 700, fontSize: '14px', textTransform: 'uppercase', letterSpacing: '1px', lineHeight: '1.1', margin: '0 0 2px 0' }}>
                      {kopKabupaten.toUpperCase()}
                    </div>
                    <div style={{ fontWeight: 700, fontSize: '14px', textTransform: 'uppercase', letterSpacing: '1px', lineHeight: '1.1', margin: '0 0 2px 0' }}>
                      {kopKecamatan.toUpperCase()}
                    </div>
                    <div style={{ fontWeight: 900, fontSize: '26px', textTransform: 'uppercase', letterSpacing: '2px', lineHeight: '1.1', margin: '2px 0 3px 0' }}>
                      {kopDesa.toUpperCase()}
                    </div>
                    {kopAlamat && (
                      <div style={{ fontSize: '10.5px', textTransform: 'capitalize', lineHeight: '1.15', margin: '2px 0 1px 0' }}>{kopAlamat}</div>
                    )}
                    {kopKontak && (
                      <div style={{ fontSize: '10.5px', lineHeight: '1.15', margin: '1px 0 0 0' }}>{kopKontak}</div>
                    )}
                  </div>
                </div>
              </div>

              {/* MODE 1: Rekapitulasi 12 Bulan (Jan - Des) */}
              {printDocType === 'rekap_12bln' && (
                <div className="space-y-6">
                  <div className="text-center space-y-1">
                    <h3 className="text-base md:text-lg font-black uppercase underline tracking-wide">
                      LAPORAN REKAPITULASI PENYALURAN {selectedProgram.toUpperCase()}
                    </h3>
                    <p className="text-xs font-bold text-gray-700">TAHUN ANGGARAN {filterYear !== "Semua Tahun" ? filterYear : new Date().getFullYear()}</p>
                    <p className="text-[11px] text-gray-500 font-mono">Dicetak pada: {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse border border-gray-900 text-[10px] sm:text-xs">
                      <thead>
                        <tr className="bg-gray-100 text-center font-black">
                          <th className="border border-gray-900 px-1 py-1.5 w-6">NO</th>
                          <th className="border border-gray-900 px-2 py-1.5">NIK</th>
                          <th className="border border-gray-900 px-2 py-1.5">NAMA PENERIMA (KPM)</th>
                          <th className="border border-gray-900 px-1.5 py-1.5">RT/RW</th>
                          {MONTHS_LIST.map(m => (
                            <th key={m.id} className="border border-gray-900 px-1 py-1.5 text-[9px] font-black">{m.label}</th>
                          ))}
                          <th className="border border-gray-900 px-1.5 py-1.5 text-center">TOTAL CAIR</th>
                          <th className="border border-gray-900 px-2 py-1.5 text-right">TOTAL NOMINAL</th>
                        </tr>
                      </thead>
                      <tbody>
                        {printAllResidents.length === 0 ? (
                          <tr>
                            <td colSpan={18} className="border border-gray-900 px-3 py-4 text-center text-gray-500 italic">Tidak ada data penerima bantuan.</td>
                          </tr>
                        ) : (
                          printAllResidents.map((res, index) => {
                            const resMonths = disbursedMonths[res.nik] || [];
                            const totalMonths = resMonths.length;
                            const totalNominal = totalMonths * programAmountVal;

                            return (
                              <tr key={res.nik} className="hover:bg-gray-50">
                                <td className="border border-gray-900 px-1 py-1 text-center font-bold">{index + 1}</td>
                                <td className="border border-gray-900 px-2 py-1 font-mono font-semibold">{res.nik}</td>
                                <td className="border border-gray-900 px-2 py-1 font-bold">{res.name}</td>
                                <td className="border border-gray-900 px-1.5 py-1 text-center">RT {res.rt || "-"}/RW {res.rw || "-"}</td>
                                {MONTHS_LIST.map(m => {
                                  const isDisbursed = resMonths.includes(m.id);
                                  return (
                                    <td key={m.id} className={`border border-gray-900 text-center font-extrabold text-[9px] ${isDisbursed ? 'bg-emerald-50 text-emerald-800' : 'text-gray-300'}`}>
                                      {isDisbursed ? '✓' : '-'}
                                    </td>
                                  );
                                })}
                                <td className="border border-gray-900 px-1.5 py-1 text-center font-extrabold">{totalMonths} Bln</td>
                                <td className="border border-gray-900 px-2 py-1 text-right font-mono font-bold">Rp {totalNominal.toLocaleString('id-ID')}</td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                      <tfoot>
                        <tr className="bg-gray-100 font-extrabold text-xs">
                          <td colSpan={16} className="border border-gray-900 px-3 py-2 text-right">TOTAL KESELURUHAN DANA SALUR:</td>
                          <td colSpan={2} className="border border-gray-900 px-3 py-2 text-right font-mono text-sm">
                            Rp {totalNominalDisbursed.toLocaleString('id-ID')}
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>

                  {/* Signatures Footer */}
                  <div className="pt-6 font-sans text-xs grid grid-cols-3 gap-6 text-center break-inside-avoid">
                    <div className="space-y-14">
                      <p className="font-bold">Mengetahui,<br />Ketua BPD {villageName || 'Desa'}</p>
                      <p className="font-bold underline uppercase">{ketuaBpdName}</p>
                    </div>
                    <div className="space-y-14">
                      <p className="font-bold">Verifikator,<br />Kasi Kesejahteraan Desa</p>
                      <p className="font-bold underline uppercase">{kasiKesraName}</p>
                    </div>
                    <div className="space-y-14">
                      <p className="font-bold">Disahkan Oleh,<br />Kepala Desa {villageName || 'Desa'}</p>
                      <p className="font-bold underline uppercase">{kadesName}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* MODE 2: Lembar Tanda Terima Pencairan per KPM */}
              {printDocType === 'tanda_terima' && (
                <div className="space-y-6">
                  <div className="text-center space-y-1">
                    <h3 className="text-base md:text-lg font-black uppercase underline tracking-wide">
                      DAFTAR HADIR & TANDA TERIMA PENCAIRAN {selectedProgram.toUpperCase()}
                    </h3>
                    <p className="text-xs font-bold text-gray-700">BULAN {MONTHS_LIST.find(m => m.id === selectedPrintMonth)?.fullName.toUpperCase()} {filterYear !== "Semua Tahun" ? filterYear : new Date().getFullYear()}</p>
                    <p className="text-[11px] text-gray-500 font-mono">Pagu per KPM: Rp {programAmountVal.toLocaleString('id-ID')}</p>
                  </div>

                  <table className="w-full border-collapse border border-gray-900 text-xs">
                    <thead>
                      <tr className="bg-gray-100 text-center font-black">
                        <th className="border border-gray-900 px-2 py-2 w-8">NO</th>
                        <th className="border border-gray-900 px-3 py-2">NIK</th>
                        <th className="border border-gray-900 px-3 py-2">NAMA PENERIMA (KPM)</th>
                        <th className="border border-gray-900 px-2 py-2">RT / RW</th>
                        <th className="border border-gray-900 px-3 py-2 text-right">NOMINAL (RP)</th>
                        <th className="border border-gray-900 px-4 py-2 text-center w-48">TANDA TANGAN / CAP JEMPOL</th>
                      </tr>
                    </thead>
                    <tbody>
                      {printAllResidents.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="border border-gray-900 px-3 py-4 text-center text-gray-500 italic">Tidak ada data KPM.</td>
                        </tr>
                      ) : (
                        printAllResidents.map((res, index) => (
                          <tr key={res.nik} className="hover:bg-gray-50">
                            <td className="border border-gray-900 px-2 py-2 text-center font-bold">{index + 1}</td>
                            <td className="border border-gray-900 px-3 py-2 font-mono font-semibold">{res.nik}</td>
                            <td className="border border-gray-900 px-3 py-2 font-bold">{res.name}</td>
                            <td className="border border-gray-900 px-2 py-2 text-center">RT {res.rt || "-"}/RW {res.rw || "-"}</td>
                            <td className="border border-gray-900 px-3 py-2 text-right font-mono font-bold">Rp {programAmountVal.toLocaleString('id-ID')}</td>
                            <td className="border border-gray-900 px-3 py-2 text-left h-10 relative">
                              <span className="text-[10px] text-gray-400 font-mono absolute top-1 left-2">{index + 1}.</span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>

                  <div className="pt-6 font-sans text-xs grid grid-cols-2 gap-6 text-center break-inside-avoid">
                    <div className="space-y-14">
                      <p className="font-bold">Bendahara Desa {villageName || 'Desa'}</p>
                      <p className="font-bold underline uppercase">( ................................ )</p>
                    </div>
                    <div className="space-y-14">
                      <p className="font-bold">Kepala Desa {villageName || 'Desa'}</p>
                      <p className="font-bold underline uppercase">{kadesName}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* MODE 3: Berita Acara Musdes */}
              {printDocType === 'ba_musdes' && (
                <div className="space-y-6">
                  <div className="text-center space-y-1">
                    <h3 className="text-base md:text-lg font-bold uppercase underline tracking-wide">BERITA ACARA MUSYAWARAH DESA</h3>
                    <p className="text-xs font-sans font-bold text-gray-700">
                      PENETAPAN KELUARGA PENERIMA MANFAAT (KPM) PROGRAM {selectedProgram.toUpperCase()} TAHUN {filterYear !== "Semua Tahun" ? filterYear : new Date().getFullYear()}
                    </p>
                    <p className="text-xs font-sans text-gray-500">Nomor: 140 / BA-MUSDES / {new Date().getFullYear()}</p>
                  </div>

                  <div className="space-y-3 text-justify font-sans text-xs md:text-sm leading-relaxed">
                    <p>
                      Pada hari ini <strong>{new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</strong>, bertempat di Balai Desa {villageName || 'Desa'}, {kopKecamatan}, Kabupaten {kopKabupaten.replace(/^(pemerintah\s+)?(kabupaten|kota)\s+/i, '').trim()}, telah diselenggarakan Musyawarah Desa (Musdes) penetapan usulan calon Keluarga Penerima Manfaat (KPM) program bantuan sosial <strong>{selectedProgram}</strong>.
                    </p>
                    <p>
                      Berdasarkan hasil verifikasi lapangan, verifikasi kriteria kelayakan kependudukan, dan alokasi APBDesa {villageName || 'Desa'} Tahun {filterYear !== "Semua Tahun" ? filterYear : new Date().getFullYear()}, disepakati bahwa nama-nama warga di bawah ini dinyatakan <strong>SAH dan LAYAK</strong> sebagai penerima manfaat:
                    </p>
                  </div>

                  <table className="w-full border-collapse border border-gray-900 text-xs">
                    <thead>
                      <tr className="bg-gray-100 text-center font-bold">
                        <th className="border border-gray-900 px-3 py-2 w-10">NO</th>
                        <th className="border border-gray-900 px-3 py-2">NIK</th>
                        <th className="border border-gray-900 px-3 py-2">NAMA LENGKAP</th>
                        <th className="border border-gray-900 px-3 py-2">ALAMAT / RT / RW</th>
                        <th className="border border-gray-900 px-3 py-2">STATUS HUKUM</th>
                      </tr>
                    </thead>
                    <tbody>
                      {printAllResidents.map((res, index) => (
                        <tr key={res.nik} className="hover:bg-gray-50">
                          <td className="border border-gray-900 px-3 py-2 text-center font-bold">{index + 1}</td>
                          <td className="border border-gray-900 px-3 py-2 font-mono font-semibold">{res.nik}</td>
                          <td className="border border-gray-900 px-3 py-2 font-bold">{res.name}</td>
                          <td className="border border-gray-900 px-3 py-2">RT {res.rt || "-"}/RW {res.rw || "-"}, Desa {villageName || 'Desa'}</td>
                          <td className="border border-gray-900 px-3 py-2 text-center font-semibold text-emerald-800">Ditetapkan Layak</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  <p className="font-sans text-xs md:text-sm text-justify">
                    Demikian Berita Acara Musdes ini dibuat dan disahkan secara terbuka untuk dipergunakan sebagaimana mestinya.
                  </p>

                  <div className="pt-6 font-sans text-xs grid grid-cols-3 gap-6 text-center break-inside-avoid">
                    <div className="space-y-14">
                      <p className="font-bold">Ketua BPD {villageName || 'Desa'}</p>
                      <p className="font-bold underline uppercase">{ketuaBpdName}</p>
                    </div>
                    <div className="space-y-14">
                      <p className="font-bold">Sekretaris Desa</p>
                      <p className="font-bold underline uppercase">( ................................ )</p>
                    </div>
                    <div className="space-y-14">
                      <p className="font-bold">Kepala Desa {villageName || 'Desa'}</p>
                      <p className="font-bold underline uppercase">{kadesName}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* MODE 4: Slip / Kupon Penerima Warga (Individual Receipt) */}
              {printDocType === 'slip_warga' && (
                <div className="space-y-6">
                  <div className="text-center space-y-1">
                    <h3 className="text-base md:text-lg font-black uppercase underline tracking-wide">
                      SLIP / KUPON RESMI BUKTI PENERIMAAN BANTUAN SOSIAL
                    </h3>
                    <p className="text-xs font-bold text-gray-700">PEMERINTAH DESA {villageName || 'DESA'} • TAHUN {filterYear !== "Semua Tahun" ? filterYear : new Date().getFullYear()}</p>
                  </div>

                  {(selectedPrintResident ? [selectedPrintResident] : printAllResidents).slice(0, 10).map((res) => {
                    const resMonths = disbursedMonths[res.nik] || [];
                    return (
                      <div key={res.nik} className="border-2 border-dashed border-gray-800 p-4 sm:p-6 rounded-2xl space-y-4 break-inside-avoid bg-gray-50/50">
                        <div className="flex justify-between items-start border-b pb-3">
                          <div>
                            <span className="text-[10px] font-black uppercase tracking-widest bg-emerald-800 text-white px-2 py-0.5 rounded">
                              KUPON PENCAIRAN RESMI
                            </span>
                            <h4 className="text-base font-extrabold mt-1 text-gray-900">{res.name}</h4>
                            <p className="text-xs font-mono font-semibold text-gray-600">NIK: {res.nik}</p>
                          </div>
                          <div className="text-right">
                            <span className="text-xs font-bold text-gray-500">Program:</span>
                            <p className="text-xs font-extrabold text-emerald-800">{selectedProgram}</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                          <div>
                            <span className="text-[10px] text-gray-500 font-bold">RT / RW:</span>
                            <p className="font-bold">RT {res.rt || "-"} / RW {res.rw || "-"}</p>
                          </div>
                          <div>
                            <span className="text-[10px] text-gray-500 font-bold">Total Bulan Cair:</span>
                            <p className="font-extrabold text-emerald-800">{resMonths.length} / 12 Bulan</p>
                          </div>
                          <div>
                            <span className="text-[10px] text-gray-500 font-bold">Total Dana Diterima:</span>
                            <p className="font-mono font-black text-sm text-emerald-900">Rp {(resMonths.length * programAmountVal).toLocaleString('id-ID')}</p>
                          </div>
                          <div>
                            <span className="text-[10px] text-gray-500 font-bold">Status Verifikasi:</span>
                            <p className="font-bold text-emerald-700">✓ Terverifikasi Desa</p>
                          </div>
                        </div>

                        <div className="pt-2 border-t flex justify-between items-center text-[10px] text-gray-500">
                          <span>Dokumen dicetak secara elektronik oleh Sistem DiDesa. Simpan sebagai bukti sah.</span>
                          <span className="font-mono font-bold">Ref: {res.nik.slice(0,6)}-{new Date().getFullYear()}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

            </div>
          </div>
        </div>
      )}
    </div>
  );
}
