import { useEffect, useState } from 'react';
import { supabase } from '../utils/supabase';
import { resolveCurrentTenant } from '../utils/tenantResolver';

export function SupabaseSync() {
  const [tenantId, setTenantId] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    // 1. Resolve Tenant ID First
    const initTenant = async () => {
      const resolvedId = await resolveCurrentTenant();
      if (isMounted) {
        setTenantId(resolvedId);
      }
    };
    initTenant();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    if (!tenantId) return;

    let isMounted = true;

    // 2. Initial Fetch (Sync from Cloud to Local, Scoped to Tenant)
    const fetchSettings = async () => {
      try {
        const { data, error } = await supabase
          .from('saas_settings')
          .select('*')
          .eq('tenant_id', tenantId);

        if (error) {
          console.error('Error fetching Supabase settings:', error);
          return;
        }

        if (data && data.length > 0 && isMounted) {
          let changed = false;
          data.forEach((row) => {
            if (localStorage.getItem(row.key) !== row.value) {
              localStorage.setItem(row.key, row.value);
              changed = true;
            }
          });

          if (changed) {
            // Trigger all known re-render events in the app
            window.dispatchEvent(new Event('village_settings_updated'));
            window.dispatchEvent(new Event('app_theme_updated'));
            window.dispatchEvent(new Event('settingsUpdated'));
            window.dispatchEvent(new Event('brandingUpdated'));
            window.dispatchEvent(new Event('didesa_news_updated'));
          }
        }
        
        // Sync Letter Classifications from Supabase
        const { data: classData, error: classError } = await supabase
          .from('letter_classifications')
          .select('*')
          .eq('tenant_id', tenantId);
          
        if (!classError && classData && classData.length > 0 && isMounted) {
          // Format them to match LetterClassification interface
          const mapped = classData.map(c => ({
            id: c.id,
            jenis: c.jenis,
            klasifikasi: c.klasifikasi,
            kodeKlasifikasi: c.kode_klasifikasi,
            deskripsi: c.deskripsi,
            noUrutTerakhir: c.no_urut_terakhir,
            isVisible: c.is_visible,
            isSaaSDisabled: c.is_saas_disabled,
            fields: c.fields
          }));
          localStorage.setItem('letter_classifications', JSON.stringify(mapped));
          window.dispatchEvent(new Event('letter_classifications_updated'));
        }

      } catch (e) {
        console.error('Failed to sync settings:', e);
      }
    };

    fetchSettings();

    // 3. Realtime Subscription (Scoped to Tenant)
    const channel = supabase
      .channel(`schema-db-changes-${tenantId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'saas_settings',
          filter: `tenant_id=eq.${tenantId}`
        },
        (payload) => {
          const newRow = payload.new as { key: string; value: string };
          if (newRow && newRow.key) {
            const currentVal = localStorage.getItem(newRow.key);
            if (currentVal !== newRow.value) {
              localStorage.setItem(newRow.key, newRow.value);
              // Trigger UI re-render on the fly
              window.dispatchEvent(new Event('village_settings_updated'));
              window.dispatchEvent(new Event('app_theme_updated'));
              window.dispatchEvent(new Event('settingsUpdated'));
              window.dispatchEvent(new Event('brandingUpdated'));
              window.dispatchEvent(new Event('didesa_news_updated'));
            }
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'letter_classifications',
          filter: `tenant_id=eq.${tenantId}`
        },
        () => {
          // Re-fetch on change
          fetchSettings();
        }
      )
      .subscribe();

    // 4. Global Broadcast Subscription (Cross-Tenant)
    const globalChannel = supabase
      .channel('global-broadcast')
      .on('broadcast', { event: 'force-reload' }, () => {
        window.dispatchEvent(new Event('force_reload_requested'));
      })
      .subscribe();

    // 5. Global Settings Realtime Subscription (SaaS Logs, Bug Reports)
    const globalSettingsChannel = supabase
      .channel('global-saas-settings')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'saas_settings',
          filter: `tenant_id=eq.00000000-0000-0000-0000-000000000000`
        },
        (payload) => {
          const newRow = payload.new as { key: string; value: string };
          if (newRow && newRow.key) {
            const currentVal = localStorage.getItem(newRow.key);
            if (currentVal !== newRow.value) {
              localStorage.setItem(newRow.key, newRow.value);
              // Trigger specific UI re-renders for global data
              if (newRow.key === 'saas_global_bug_reports') {
                window.dispatchEvent(new Event('bug_reports_updated'));
              }
              if (newRow.key === 'saas_global_activity_logs') {
                window.dispatchEvent(new Event('saas_logs_updated'));
              }
            }
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'saas_tenant_requests'
        },
        () => {
          window.dispatchEvent(new Event('tenant_requests_updated'));
        }
      )
      .subscribe();

    return () => {
      isMounted = false;
      supabase.removeChannel(channel);
      supabase.removeChannel(globalChannel);
      supabase.removeChannel(globalSettingsChannel);
    };
  }, [tenantId]);

  return null;
}
