import re

with open('C:/Users/ASUS/.gemini/antigravity/scratch/DiDesa/src/components/admin/surat/AdminSuratSKTM.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Pattern to match from first grid to end of second grid
old = r'<div className="grid grid-cols-2 gap-4">.*?<div className="grid grid-cols-1 md:grid-cols-3 gap-4">.*?</div>\s*</div>'
new = '''            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2 space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Alamat Lengkap</label>
                <textarea
                  rows={2}
                  placeholder="Contoh: Jl. Keramat, Desa Wasah Hilir"
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none resize-none"
                  value={formData.alamat}
                  onChange={(e) => setFormData(prev => ({ ...prev, alamat: e.target.value }))}
                  onBlur={(e) => handleAlamatBlur(e.target.value)}
                />
              </div>
              <div className="md:col-span-1 space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">RT</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
                  placeholder="Contoh: 001"
                  value={formData.rt}
                  onChange={(e) => setFormData(prev => ({ ...prev, rt: e.target.value }))}
                />
              </div>
              <div className="md:col-span-1 space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">RW</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
                  placeholder="Contoh: 002"
                  value={formData.rw}
                  onChange={(e) => setFormData(prev => ({ ...prev, rw: e.target.value }))}
                />
              </div>
            </div>'''

# Use DOTALL flag to match across newlines
new_content = re.sub(r'<div className="grid grid-cols-2 gap-4">.*?<div className="grid grid-cols-1 md:grid-cols-3 gap-4">.*?</div>\s*</div>', 
                     lambda m: '''            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2 space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Alamat Lengkap</label>
                <textarea
                  rows={2}
                  placeholder="Contoh: Jl. Keramat, Desa Wasah Hilir"
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none resize-none"
                  value={formData.alamat}
                  onChange={(e) => setFormData(prev => ({ ...prev, alamat: e.target.value }))}
                  onBlur={(e) => handleAlamatBlur(e.target.value)}
                />
              </div>
              <div className="md:col-span-1 space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">RT</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
                  placeholder="Contoh: 001"
                  value={formData.rt}
                  onChange={(e) => setFormData(prev => ({ ...prev, rt: e.target.value }))}
                />
              </div>
              <div className="md:col-span-1 space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">RW</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
                  placeholder="Contoh: 002"
                  value={formData.rw}
                  onChange={(e) => setFormData(prev => ({ ...prev, rw: e.target.value }))}
                />
              </div>
            </div>''', 
    content, flags=re.DOTALL, count=1)

with open('C:/Users/ASUS/.gemini/antigravity/scratch/DiDesa/src/components/admin/surat/AdminSuratSKTM.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("Done!")