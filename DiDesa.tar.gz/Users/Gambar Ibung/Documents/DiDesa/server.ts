import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

let aiClient: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

import { 
  getResidents, 
  insertResident, 
  updateResident, 
  deleteResident, 
  getArchivedResidents,
  restoreResident,
  hardDeleteResident,
  getActiveDbEngine,
  getNotifications,
  addNotification,
  markAllNotificationsAsRead,
  getTenants,
  addTenant,
  updateTenant,
  deleteTenant,
  getGlobalUpdates,
  addGlobalUpdate,
  getGlobalSettings,
  saveGlobalSetting,
  getAiUsageInfo,
  incrementAiUsage,
  getTodayDate
} from "./server/db";

// API Routes
app.get("/api/notifications", (req, res) => {
  try {
    const notifs = getNotifications();
    res.json(notifs);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/notifications", (req, res) => {
  const { title, message, category } = req.body;
  if (!title || !message) {
    return res.status(400).json({ error: "Title and message are required" });
  }
  try {
    const newNotif = addNotification(title, message, category || "System");
    res.json(newNotif);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/notifications/read-all", (req, res) => {
  try {
    const result = markAllNotificationsAsRead();
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/db-status", (req, res) => {
  res.json({
    engine: getActiveDbEngine(),
    isProduction: process.env.NODE_ENV === "production"
  });
});

// Backward compatibility check
app.get("/api/supabase-status", (req, res) => {
  res.json({
    configured: getActiveDbEngine() !== "Memory",
    supabaseUrl: process.env.SUPABASE_URL || null,
    connected: getActiveDbEngine() !== "Memory"
  });
});

// POST to parse village profile & officers documents using Gemini
app.post("/api/parse-profile-document", async (req, res) => {
  const { fileData, mimeType, fileName } = req.body;
  if (!fileData || !mimeType) {
    return res.status(400).json({ error: "fileData and mimeType are required" });
  }

  try {
    const ai = getGeminiClient();
    
    // Strip base64 data url prefix if present
    let cleanBase64 = fileData;
    if (fileData.includes(";base64,")) {
      cleanBase64 = fileData.split(";base64,")[1];
    }

    const documentPart = {
      inlineData: {
        mimeType: mimeType,
        data: cleanBase64,
      }
    };

    const textPart = {
      text: `Analyze this document which contains a village profile (Profil Desa) and/or a list of village officials/personnel (perangkat/pejabat desa). 
      Extract the following information as accurately as possible from the text, lists, and tables in the document.
      
      Respond in Indonesian and format your entire response as a valid JSON object matching this exact schema:
      {
        "villageName": "Name of the village (Desa / Kelurahan, e.g. Desa Wasah Hilir)",
        "kecamatan": "Kecamatan name (e.g. Kecamatan Simpur)",
        "kabupaten": "Kabupaten name (prefixed with Pemerintah Kabupaten if applicable, e.g. Pemerintah Kabupaten Hulu Sungai Selatan)",
        "provinsi": "Provinsi name (e.g. Kalimantan Selatan)",
        "alamat": "Kantor desa address if found, otherwise keep blank",
        "kontak": "No. HP / Email of the office if found, otherwise keep blank",
        "officers": [
          {
            "name": "Full name of the officer",
            "role": "Their role/jabatan (e.g. Kepala Desa, Sekretaris Desa, Pj. Kepala Desa, Kaur Umum, Kasi Pemerintahan, dll.)",
            "nip": "NIP (Nomor Induk Pegawai) if any, or '-'"
          }
        ]
      }
      
      Do not include any Markdown explanation or backticks in the response. Return raw JSON string only.`
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: {
        parts: [documentPart, textPart]
      },
      config: {
        responseMimeType: "application/json"
      }
    });

    const resultText = response.text || "{}";
    try {
      const parsedResult = JSON.parse(resultText.trim());
      res.json(parsedResult);
    } catch (parseErr) {
      console.error("Gemini raw text parse error. Raw text:", resultText);
      res.status(500).json({ error: "Failed to parse JSON response from Gemini", raw: resultText });
    }
  } catch (err: any) {
    console.error("Error parsing document with Gemini:", err);
    res.status(500).json({ error: err.message });
  }
});

// POST parse PDF surat undangan => data SPPD (Auto-Fill) via Gemini
// API key di-resolve di server: env GEMINI_API_KEY -> global_settings.master_gemini_api_key -> key dari klien.
app.post("/api/ai/parse-invitation", async (req, res) => {
  try {
    const { fileData, mimeType, fileName, apiKey, tenantId } = req.body || {};

    if (!fileData || typeof fileData !== "string" || !fileData.trim()) {
      return res.status(400).json({ error: "fileData wajib diisi (base64 PDF surat undangan)" });
    }
    const normalizedMime = String(mimeType || "").toLowerCase();
    if (normalizedMime !== "application/pdf" && normalizedMime !== "application/x-pdf") {
      return res.status(400).json({
        success: false,
        code: "INVALID_FILE",
        message: "Hanya file PDF yang didukung untuk surat undangan.",
      });
    }

    // Kuota harian per desa — sama dengan /api/ai/chat
    if (tenantId && typeof tenantId === "string" && tenantId.trim()) {
      const quota = await getAiUsageInfo(tenantId);
      if (!quota.hasQuota) {
        return res.status(429).json({
          success: false,
          error: `Kuota AI harian desa ini telah habis (${quota.usedQuota}/${quota.totalQuota}). Kuota direset otomatis besok.`,
          code: "QUOTA_EXCEEDED",
          usage: quota,
        });
      }
    }

    // Resolve API key
    let resolvedKey = (process.env.GEMINI_API_KEY || "").trim();
    if (!resolvedKey) {
      try {
        const settings = await getGlobalSettings();
        resolvedKey = (settings["master_gemini_api_key"] || "").trim();
      } catch {
        resolvedKey = "";
      }
    }
    if (!resolvedKey && typeof apiKey === "string" && apiKey.trim()) {
      resolvedKey = apiKey.trim();
    }
    if (!resolvedKey) {
      return res.status(422).json({
        success: false,
        code: "API_KEY_MISSING",
        message: "API Key AI belum dikonfigurasi oleh Admin.",
      });
    }

    let cleanBase64 = fileData;
    if (fileData.includes(";base64,")) {
      cleanBase64 = fileData.split(";base64,")[1];
    }

    const documentPart = {
      inlineData: {
        mimeType: "application/pdf",
        data: cleanBase64,
      },
    };

    const systemPrompt = `Anda adalah asisten administrasi pemerintah desa yang andal.
Baca seluruh isi PDF surat undangan di atas dan ekstrak data untuk mengisi formulir Surat Perjalanan Dinas (SPPD).
Balas HANYA dengan satu objek JSON valid. Jangan sertakan teks pembuka, markdown, atau backtick.
Wajib gunakan struktur persis ini dan jangan mengubah nama key:
{
  "nomorSuratUndangan": "nomor surat undangan, kosongkan jika tidak ada",
  "maksudPerjalanan": "tujuan/agenda/maksud kegiatan yang diundang, ringkas dan jelas",
  "tempatTujuan": "lokasi/tempat kegiatan (nama gedung dan kota), kosongkan jika tidak ada",
  "tanggalBerangkat": "tanggal mulai kegiatan dalam format YYYY-MM-DD",
  "tanggalKembali": "tanggal selesai kegiatan dalam format YYYY-MM-DD (sama dengan tanggalBerangkat jika kegiatan satu hari)",
  "instansiPengundang": "nama instansi/lembaga pengirim undangan"
}
Isi sebanyak mungkin field; jika informasi tidak ditemukan gunakan string kosong ("").
Pastikan setiap tanggal valid dengan format YYYY-MM-DD.`;

    const models = Array.from(new Set([
      (process.env.AI_MODEL || "").trim(),
      "gemini-2.0-flash",
      "gemini-2.5-flash",
      "gemini-2.0-flash-lite",
      "gemini-1.5-flash",
    ].filter(Boolean)));

    const ai = new GoogleGenAI({ apiKey: resolvedKey });
    let reply = "";
    let usedModel = "";
    let authOrQuotaError = false;
    const allErrors: string[] = [];

    const isGeminiAuthOrQuotaError = (err: any): boolean => {
      const raw = String((err && err.message) || err || "");
      return /api key|invalid key|401|403|429|permission denied|unauthori|unauthenticated|quota|daily limit|resource exhausted|rate limit/i.test(raw);
    };

    for (const model of models) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: {
            parts: [documentPart, { text: systemPrompt }],
          },
          config: {
            temperature: 0.2,
            maxOutputTokens: 4096,
            responseMimeType: "application/json",
          },
        });
        reply = (response.text || "").trim();
        usedModel = model;
        if (reply) break;
      } catch (err: any) {
        if (isGeminiAuthOrQuotaError(err)) authOrQuotaError = true;
        allErrors.push(`[${model}] ${(err && err.message) || err}`);
      }
    }

    if (!reply) {
      if (authOrQuotaError) {
        return res.status(403).json({
          success: false,
          code: "API_KEY_INVALID",
          message: "API Key AI tidak valid atau kuota Google AI telah habis.",
        });
      }
      return res.status(500).json({
        success: false,
        code: "PARSE_ERROR",
        message: "DiDesa AI gagal membaca isi PDF. Pastikan file adalah surat undangan yang jelas.",
        detail: allErrors.slice(0, 3).join("\n"),
      });
    }

    const jsonMatch = reply.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return res.status(500).json({
        success: false,
        code: "PARSE_ERROR",
        message: "DiDesa AI tidak dapat membaca isi dokumen. Pastikan file adalah surat undangan PDF yang jelas.",
        raw: reply.slice(0, 500),
      });
    }

    let parsed: any;
    try {
      parsed = JSON.parse(jsonMatch[0]);
    } catch (err) {
      return res.status(500).json({
        success: false,
        code: "PARSE_ERROR",
        message: "DiDesa AI tidak dapat membaca isi dokumen. Pastikan file adalah surat undangan PDF yang jelas.",
        raw: reply.slice(0, 500),
      });
    }

    if (tenantId && typeof tenantId === "string" && tenantId.trim()) {
      await incrementAiUsage(tenantId, getTodayDate());
    }

    res.json({ success: true, ...parsed, model: usedModel, fileName: fileName || "" });
  } catch (err: any) {
    console.error("[/api/ai/parse-invitation] error:", err);
    res.status(500).json({
      success: false,
      code: "PARSE_ERROR",
      message: "Terjadi kesalahan saat membaca dokumen PDF.",
      detail: err.message || "",
    });
  }
});

// GET remaining AI daily quota for a tenant (server-side truth)
app.get("/api/ai/usage", async (req, res) => {
  try {
    const tenantId = (req.query.tenantId as string) || "";
    if (!tenantId) {
      return res.status(400).json({ error: "tenantId wajib diisi" });
    }
    const info = await getAiUsageInfo(tenantId);
    res.json(info);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST AI chat — semua panggilan Gemini di-proxy lewat server agar API key aman.
// Menerapkan kuota harian per desa (tenant_id + usage_date) sebelum memanggil Gemini.
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { tenantId, messages, systemPrompt, apiKey, fileData, mimeType, requireJson } = req.body || {};

    if (!tenantId || typeof tenantId !== "string" || !tenantId.trim()) {
      return res.status(400).json({ error: "tenantId wajib diisi" });
    }
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "messages wajib diisi (array riwayat percakapan)" });
    }

    // 1. Cek kuota harian per desa — tolak jika habis (dicek sebelum resolve key)
    const quota = await getAiUsageInfo(tenantId);
    if (!quota.hasQuota) {
      return res.status(429).json({
        error: `Kuota AI harian desa ini telah habis (${quota.usedQuota}/${quota.totalQuota} chat). Kuota akan direset otomatis besok.`,
        code: "QUOTA_EXCEEDED",
        usage: quota,
      });
    }

    // 2. Resolve API key di server: env -> global_settings -> (opsional) custom key dari klien
    let resolvedKey = (process.env.GEMINI_API_KEY || "").trim();
    if (!resolvedKey) {
      try {
        const settings = await getGlobalSettings();
        resolvedKey = (settings["master_gemini_api_key"] || "").trim();
      } catch {
        resolvedKey = "";
      }
    }
    if (!resolvedKey && typeof apiKey === "string" && apiKey.trim()) {
      resolvedKey = apiKey.trim();
    }
    if (!resolvedKey) {
      return res.status(500).json({
        error: "GEMINI_API_KEY belum dikonfigurasi di server. Hubungi administrator DiDesa.",
      });
    }

    // 3. Siapkan payload; role 'ai'/'assistant' dipetakan ke 'model' untuk Gemini
    const geminiMessages: Array<{ role: string; parts: any[] }> = (messages as Array<{ role: string; content: string }>).map((m) => ({
      role: m.role === "ai" || m.role === "assistant" ? "model" : "user",
      parts: m.content && m.content.trim() ? [{ text: m.content }] : [],
    }));

    // Dukungan multimodal (PDF/gambar) untuk autofill surat — disisipkan ke pesan user terakhir
    if (fileData && mimeType && geminiMessages.length > 0) {
      geminiMessages[geminiMessages.length - 1].parts.push({
        inlineData: {
          mimeType,
          data: String(fileData).replace(/^data:[^;]+;base64,/, ""),
        },
      });
    }

    const config: any = {
      temperature: 0.7,
      maxOutputTokens: 1024,
    };
    if (requireJson) {
      config.responseMimeType = "application/json";
    }

    const models = Array.from(new Set([
      (process.env.AI_MODEL || "").trim(),
      "gemini-2.5-flash",
      "gemini-2.0-flash",
      "gemini-2.0-flash-lite",
      "gemini-1.5-flash",
    ].filter(Boolean)));

    const ai = new GoogleGenAI({ apiKey: resolvedKey });
    let reply = "";
    let usedModel = "";
    const allErrors: string[] = [];

    for (const model of models) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: geminiMessages,
          config: {
            ...config,
            ...(systemPrompt && systemPrompt.trim()
              ? { systemInstruction: { parts: [{ text: systemPrompt }] } }
              : {}),
          },
        });
        reply = (response.text || "").trim();
        usedModel = model;
        if (reply) break;
      } catch (err: any) {
        allErrors.push(`[${model}] ${(err && err.message) || err}`);
      }
    }

    if (!reply) {
      return res.status(500).json({
        error: `Semua model AI gagal merespons.${
          allErrors.length ? "\n" + allErrors.slice(0, 3).join("\n") : ""
        }`,
      });
    }

    // 4. Catat pemakaian dan kembalikan sisa kuota terbaru
    await incrementAiUsage(tenantId, getTodayDate());
    const updatedUsage = await getAiUsageInfo(tenantId);

    res.json({ reply, model: usedModel, usage: updatedUsage });
  } catch (err: any) {
    console.error("[/api/ai/chat] error:", err);
    res.status(500).json({ error: err.message || "Terjadi kesalahan pada AI chat" });
  }
});

// GET all tenants
app.get("/api/tenants", async (req, res) => {
  try {
    const tenants = await getTenants();
    res.json(tenants);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST new tenant
app.post("/api/tenants", async (req, res) => {
  try {
    const tenant = await addTenant(req.body);
    res.json({ success: true, tenant });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update tenant
app.put("/api/tenants/:id", async (req, res) => {
  try {
    const tenant = await updateTenant(req.params.id, req.body);
    res.json({ success: true, tenant });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE tenant
app.delete("/api/tenants/:id", async (req, res) => {
  try {
    const success = await deleteTenant(req.params.id);
    res.json({ success });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET all global updates
app.get("/api/global-updates", async (req, res) => {
  try {
    const updates = await getGlobalUpdates();
    res.json(updates);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST new global update
app.post("/api/global-updates", async (req, res) => {
  try {
    const update = await addGlobalUpdate(req.body);
    res.json(update);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET global settings
app.get("/api/global-settings", async (req, res) => {
  try {
    const settings = await getGlobalSettings();
    res.json(settings);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST update global settings
app.post("/api/global-settings", async (req, res) => {
  try {
    const payload = req.body || {};
    for (const [key, value] of Object.entries(payload)) {
      if (typeof value === "string") {
        await saveGlobalSetting(key, value);
      }
    }
    const settings = await getGlobalSettings();
    res.json({ success: true, settings });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

  // Migration route to fix old data
  app.get("/api/migrate-status", async (req, res) => {
    try {
      const residents = await getResidents();
      let migratedCount = 0;
      
      for (const r of residents) {
        let changed = false;
        let newStatus = r.status;
        let newMarital = r.maritalStatus || 'Belum Kawin';
        
        const lower = (r.status || '').toLowerCase();
        
        if (lower.includes('belum') || lower === 'single') {
          newStatus = 'Aktif';
          newMarital = 'Belum Kawin';
          changed = true;
        } else if (lower.includes('cerai mati')) {
          newStatus = 'Aktif';
          newMarital = 'Cerai Mati';
          changed = true;
        } else if (lower.includes('cerai')) {
          newStatus = 'Aktif';
          newMarital = 'Cerai Hidup';
          changed = true;
        } else if (lower.includes('kawin')) {
          newStatus = 'Aktif';
          newMarital = 'Kawin';
          changed = true;
        } else if (lower === 'hidup' || lower === 'mati' || lower.includes('wafat')) {
          newStatus = lower === 'hidup' ? 'Aktif' : 'Meninggal';
          changed = true;
        }
        
        if (changed) {
          await updateResident(r.nik, { status: newStatus, maritalStatus: newMarital, statusColor: newStatus === 'Aktif' ? 'emerald' : 'gray' }, true);
          migratedCount++;
        }
      }
      
      res.json({ success: true, message: `Successfully migrated ${migratedCount} residents.` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

// GET all residents
app.get("/api/residents", async (req, res) => {
  try {
    const tenant_id = req.query.tenant_id as string | undefined;
    const residents = await getResidents(tenant_id);
    res.json(residents);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST new resident
app.post("/api/residents", async (req, res) => {
  const newResident = req.body;
  if (!newResident.nik) {
    return res.status(400).json({ error: "NIK is required" });
  }

  try {
    const result = await insertResident(newResident);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST batch insert residents
app.post("/api/residents/batch", async (req, res) => {
  const residentsList = req.body;
  if (!Array.isArray(residentsList)) {
    return res.status(400).json({ error: "Data must be an array" });
  }

  try {
    const results = [];
    for (const resident of residentsList) {
      if (resident.nik && resident.name) {
        const result = await insertResident(resident);
        results.push(result);
      }
    }
    res.json({ success: true, count: results.length, data: results });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update resident
app.put("/api/residents/:nik", async (req, res) => {
  const { nik } = req.params;
  const updatedResident = req.body;

  try {
    const result = await updateResident(nik, updatedResident);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Memory store for pending approvals
interface PendingApproval {
  nik: string;
  name: string;
  actionType: "delete" | "move" | "edit" | "status_change";
  originalStatus: string;
  requestDate: string;
  details?: any;
}
const pendingApprovalsStore: Record<string, PendingApproval> = {};

// POST request approval
app.post("/api/residents/:nik/request-approval", async (req, res) => {
  const { nik } = req.params;
  const { actionType, originalStatus, details } = req.body;

  if (!actionType) {
    return res.status(400).json({ error: "Action type is required" });
  }

  try {
    const residents = await getResidents();
    const resident = residents.find((r) => r.nik === nik);
    if (!resident) {
      return res.status(404).json({ error: "Resident not found" });
    }

    // Set resident status to pending_approval in DB
    const updated = {
      ...resident,
      status: "pending_approval",
      statusColor: "yellow"
    };
    await updateResident(nik, updated, true);

    // Save pending approval metadata
    pendingApprovalsStore[nik] = {
      nik,
      name: resident.name,
      actionType,
      originalStatus: originalStatus || resident.status || "Belum Kawin",
      requestDate: new Date().toISOString(),
      details
    };

    addNotification(
      "Pengajuan Persetujuan",
      `Admin mengajukan permohonan ${actionType === 'delete' ? 'Hapus Data' : actionType === 'move' ? 'Pindah/Mutasi' : actionType === 'edit' ? 'Edit Data' : 'Perubahan Status'} warga ${resident.name} (NIK: ${nik}).`,
      "Residents"
    );

    res.json({ success: true, resident: updated });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET all approvals
app.get("/api/approvals", async (req, res) => {
  try {
    const residents = await getResidents();
    const pendingResidents = residents.filter((r) => r.status === "pending_approval");

    const approvals = pendingResidents.map((r) => {
      const meta = pendingApprovalsStore[r.nik] || {
        nik: r.nik,
        name: r.name,
        actionType: "delete" as const,
        originalStatus: "Belum Kawin",
        requestDate: new Date().toISOString()
      };
      return {
        ...r,
        pendingMeta: meta
      };
    });

    res.json(approvals);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST approve action
app.post("/api/residents/:nik/approve", async (req, res) => {
  const { nik } = req.params;

  try {
    const meta = pendingApprovalsStore[nik];
    const residents = await getResidents();
    const resident = residents.find((r) => r.nik === nik);
    const name = resident ? resident.name : (meta ? meta.name : "Penduduk");

    let success = false;
    if (meta) {
      if (meta.actionType === 'delete' || meta.actionType === 'move') {
        success = await deleteResident(nik, true);
      } else if (meta.actionType === 'edit' || meta.actionType === 'status_change') {
        await updateResident(nik, meta.details, true);
        success = true;
      }
    } else if (resident) {
      // Fallback if memory store was cleared but DB still says pending
      await updateResident(nik, { status: "Aktif", statusColor: "green" }, true);
      success = true;
    }

    // Clear from store
    delete pendingApprovalsStore[nik];

    addNotification(
      "Pengajuan Disetujui",
      `Super Admin menyetujui ${meta?.actionType === 'delete' ? 'penghapusan' : meta?.actionType === 'move' ? 'perpindahan' : meta?.actionType === 'edit' ? 'edit data' : 'perubahan status'} warga ${name}.`,
      "Residents"
    );

    res.json({ success, message: `Resident NIK ${nik} approved and processed` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST reject action
app.post("/api/residents/:nik/reject", async (req, res) => {
  const { nik } = req.params;

  try {
    const meta = pendingApprovalsStore[nik];
    const residents = await getResidents();
    const resident = residents.find((r) => r.nik === nik);

    if (!resident) {
      return res.status(404).json({ error: "Resident not found" });
    }

    const restoreStatus = meta ? meta.originalStatus : "Aktif";
    const restoreColor = restoreStatus === "Meninggal" ? "gray" : "green";

    const restored = {
      ...resident,
      status: restoreStatus,
      statusColor: restoreColor
    };

    await updateResident(nik, restored, true);

    // Clear from store
    delete pendingApprovalsStore[nik];

    addNotification(
      "Pengajuan Ditolak",
      `Super Admin menolak ${meta?.actionType === 'delete' ? 'penghapusan' : meta?.actionType === 'move' ? 'perpindahan' : meta?.actionType === 'edit' ? 'edit data' : 'perubahan status'} warga ${resident.name}.`,
      "Residents"
    );

    res.json({ success: true, resident: restored });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE resident
app.delete("/api/residents/:nik", async (req, res) => {
  const { nik } = req.params;

  try {
    const success = await deleteResident(nik);
    res.json({ success, message: `Resident with NIK ${nik} processed` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/residents/archived", async (req, res) => {
  try {
    const archived = await getArchivedResidents();
    res.json(archived);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/residents/:nik/restore", async (req, res) => {
  const { nik } = req.params;
  try {
    const success = await restoreResident(nik);
    addNotification("Penduduk Direstore", `Data penduduk dengan NIK ${nik} telah dikembalikan dari tong sampah.`, "Residents");
    res.json({ success, message: `Resident with NIK ${nik} restored` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete("/api/residents/:nik/hard-delete", async (req, res) => {
  const { nik } = req.params;
  try {
    const success = await hardDeleteResident(nik);
    addNotification("Penduduk Dihapus Permanen", `Data penduduk dengan NIK ${nik} telah dihapus permanen.`, "Residents");
    res.json({ success, message: `Resident with NIK ${nik} hard deleted` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});


// Mount Vite middleware or static files
async function setupVite() {
  // Shared index.html template (cached after first read)
  let indexHtmlCache: string | null = null;
  async function getIndexHtml(): Promise<string> {
    if (indexHtmlCache) return indexHtmlCache;
    const fs = await import("fs");
    const htmlPath = process.env.NODE_ENV === "production"
      ? path.join(process.cwd(), "dist", "index.html")
      : path.join(process.cwd(), "index.html");
    indexHtmlCache = fs.readFileSync(htmlPath, "utf-8");
    return indexHtmlCache;
  }

  // Middleware: server-side OG tag injection for shared news links (?id=n-xxx)
  app.get("*", async (req, res, next) => {
    const newsId = req.query.id as string | undefined;
    if (!newsId || !newsId.startsWith("n-")) return next();

    try {
      const supabaseUrl = (process.env.SUPABASE_URL || "").trim();
      const supabaseKey = (process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KE || "").trim();
      if (!supabaseUrl || !supabaseKey) return next();

      const { createClient } = await import("@supabase/supabase-js");
      const sb = createClient(supabaseUrl, supabaseKey);

      // Resolve tenant from subdomain
      const hostname = req.hostname;
      const parts = hostname.split(".");
      let targetDomain = "";
      if (parts.length >= 2 && parts[0] !== "www" && parts[0] !== "localhost") {
        targetDomain = parts[0];
      }

      let tenantId = "";
      if (targetDomain) {
        const { data: tenant } = await sb.from("tenants")
          .select("id").or(`domain.ilike.${targetDomain},domain.ilike.${targetDomain}.%`).maybeSingle();
        if (tenant?.id) tenantId = tenant.id;
      }
      if (!tenantId) return next();

      // Fetch news list
      const { data: setting } = await sb.from("saas_settings")
        .select("value").eq("tenant_id", tenantId).eq("key", "didesa_news_list").single();
      if (!setting?.value) return next();

      const newsList = JSON.parse(setting.value);
      const item = newsList.find((n: any) => n.id === newsId);
      if (!item) return next();

      // Fetch village name from settings
      let desaName = "Desa";
      const { data: nameSetting } = await sb.from("saas_settings")
        .select("value").eq("tenant_id", tenantId).eq("key", "kop_desa").single();
      if (nameSetting?.value) desaName = nameSetting.value;

      const baseUrl = `${req.protocol}://${req.get("host")}`;
      const shareUrl = `${baseUrl}/?id=${newsId}`;
      const title = item.title || "Berita Desa";
      const description = item.excerpt || item.fullContent?.substring(0, 160) || "";
      const image = item.image || "";

      const html = await getIndexHtml();
      const ogTags = `
    <meta property="og:type" content="article" />
    <meta property="og:title" content="${title.replace(/"/g, "&quot;")}" />
    <meta property="og:description" content="${description.replace(/"/g, "&quot;").replace(/\n/g, " ").substring(0, 200)}" />
    <meta property="og:url" content="${shareUrl}" />
    <meta property="og:site_name" content="${desaName}" />
    ${image ? `<meta property="og:image" content="${image}" />` : ""}
    <meta name="twitter:card" content="${image ? "summary_large_image" : "summary"}" />
    <meta name="twitter:title" content="${title.replace(/"/g, "&quot;")}" />
    <meta name="twitter:description" content="${description.replace(/"/g, "&quot;").replace(/\n/g, " ").substring(0, 200)}" />
    ${image ? `<meta name="twitter:image" content="${image}" />` : ""}
    <title>${title} - ${desaName}</title>`;

      const modifiedHtml = html.replace("</head>", `${ogTags}\n  </head>`);
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      return res.send(modifiedHtml);
    } catch (err: any) {
      console.error("[OG Middleware] Error:", err.message);
      return next();
    }
  });

  // Middleware: server-side OG tag injection for shared SK Kades links (?tab=sk_kades&sk_id=xxx)
  app.get("*", async (req, res, next) => {
    const tab = req.query.tab as string | undefined;
    const skId = req.query.sk_id as string | undefined;
    if (tab !== "sk_kades" || !skId) return next();

    try {
      const supabaseUrl = (process.env.SUPABASE_URL || "").trim();
      const supabaseKey = (process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KE || "").trim();
      if (!supabaseUrl || !supabaseKey) return next();

      const { createClient } = await import("@supabase/supabase-js");
      const sb = createClient(supabaseUrl, supabaseKey);

      const hostname = req.hostname;
      const parts = hostname.split(".");
      let targetDomain = "";
      if (parts.length >= 2 && parts[0] !== "www" && parts[0] !== "localhost") {
        targetDomain = parts[0];
      }

      let tenantId = "";
      if (targetDomain) {
        const { data: tenant } = await sb.from("tenants")
          .select("id, name").or(`domain.ilike.${targetDomain},domain.ilike.${targetDomain}.%`).maybeSingle();
        if (tenant?.id) { tenantId = tenant.id; }
      }
      if (!tenantId) return next();

      const { data: setting } = await sb.from("saas_settings")
        .select("value").eq("tenant_id", tenantId).eq("key", "produk_hukum_data").single();
      if (!setting?.value) return next();

      const all = JSON.parse(setting.value);
      const skItems = all["sk_kades"] || [];
      const skItem = skItems.find((i: any) => i.id === skId);
      if (!skItem) return next();

      const baseUrl = `${req.protocol}://${req.get("host")}`;
      const shareUrl = `${baseUrl}/?tenant=${req.query.tenant || targetDomain}&tab=sk_kades&sk_id=${skId}`;
      const title = `SK Kades - ${skItem.uraian || "Surat Keputusan"}`;
      const description = [
        skItem.no ? `Nomor: ${skItem.no}` : "",
        skItem.tahun ? `Tahun: ${skItem.tahun}` : "",
        skItem.jenisDokumen ? `Jenis: ${skItem.jenisDokumen}` : "",
      ].filter(Boolean).join(" • ");

      const html = await getIndexHtml();
      const ogTags = `
    <meta property="og:type" content="website" />
    <meta property="og:title" content="${title.replace(/"/g, "&quot;")}" />
    <meta property="og:description" content="${description.replace(/"/g, "&quot;").substring(0, 200)}" />
    <meta property="og:url" content="${shareUrl}" />
    <meta property="og:site_name" content="DiDesa" />
    <meta property="og:locale" content="id_ID" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:title" content="${title.replace(/"/g, "&quot;")}" />
    <meta name="twitter:description" content="${description.replace(/"/g, "&quot;").substring(0, 200)}" />
    <title>${title} - DiDesa</title>`;

      const modifiedHtml = html.replace("</head>", `${ogTags}\n  </head>`);
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      return res.send(modifiedHtml);
    } catch (err: any) {
      console.error("[OG SK Middleware] Error:", err.message);
      return next();
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

setupVite();
